

**[B2. Wonderful Coloring - 2](https://codeforces.com/problemset/problem/1551/B2)**

###### 题意

给定一个序列，给每个数染色（可以不染），要求：

1. 对于每个数要从$k$个颜色中选择一个染色，或者不染色（标记0）
2. 对于每种颜色，每个数只能出现一次，比如不能同时有两个1被染成颜色1
3. 对于所有的颜色，每种颜色包含的数个数都相等，比如有$x$个颜色被染成了颜色1，则对$2-k$每种颜色都有$x$个数被染成该颜色。
4. 构造的序列应该保证被染色的数最多

###### 分析

有启发性的一道简单贪心思维题

首先看题的时候分析假了，没有分析出k种颜色必须都被使用，所以没想好不要敲键盘。

其次如何分析呢，对于k种元素，每个数最多只会被使用k次，所以我们只需要考虑每个数的前k个位置。接下来对于每个数，我们依次给他染上1-k个颜色，如何保证它的正确性：每个数最多只会被使用k次，因为是连续考虑的，所以不会有同一个数被标记成同一个颜色。

**时间复杂度：$O(n)$**

虽然比较简单。感觉要通过题意，宏观上来想。

<details>
    <summary> <font face="Comic Sans MS" size="4" color="green">AC 代码</font> </summary>

```cpp
const int N = 200010;
int a[N], cnt[N];
map<int, vii> mp; // 新用法, 最大的收获
int n, k;
int ans[N];
void solve() {
	scanf("%d%d", &n, &k);
	mp.clear();
	memset(ans, 0, sizeof ans);
	for (int i = 1; i <= n; i++) {
		scanf("%d", &a[i]);
		if (SZ(mp[a[i]]) < k) mp[a[i]].pb(i);
	}
	int m = 0, col = 0, id = 0;
	for (auto c : mp) m += SZ(c.se);
	m -= m % k;
	for (auto c : mp) {
		for (int i = 0; i < SZ(c.se); i++) {
			ans[c.se[i]] = ++col;
			col %= k;
			m--;
			if (m == 0) {
				for (int x = 1; x <= n; x++) {
					printf("%d%c", ans[x], " \n"[x == n]);
				}
				return ;
			}
		}
	}
}
```
</details>

**[C. LIS or Reverse LIS?](https://codeforces.com/problemset/problem/1682/C)**脑筋急转弯

###### 题意

重排一个序列，求出最长上升子序列和最长下降子序列（均为严格）的取$min$的最大的最小值。
$$
min[LIS(a),LDS(a)]
$$

###### 分析

很容易想到要求出个数为1或者个数大于1的数的个数a、b, 答案很显然接近,但是仔细考虑，发现并不准确。

首先确定的是当a为偶数，那么答案就是$\frac{a}{2}+b$，因为每一个b都会使序列长度边长，同时每两个a可以成对使用。

当a为奇数时，那个多出来的a怎么考虑，直接舍去不对。我们将最大的a放到中间，其余遵守偶数规则。

例如（2,2,3,3,4,5,6,7,7）如下构造：（2,3,4,7,6,7,5,3,2）

这样我们发现答案是$\lceil \frac{a}{2} \rceil+b$

<details>
    <summary> <font face="Comic Sans MS" size="4" color="green">AC 代码</font> </summary>

```cpp
const int N = 200010;
int a[N], n;
void solve() {
	scanf("%d", &n);
	map<int, int> mp;
	lep(i, 1, n) {
		scanf("%d", &a[i]);
		mp[a[i]]++;
	}
	int a = 0, b = 0, t1 = -1, t2;
	for (auto c : mp) {
		if (c.se == 1) a++;
		else b++;
	}
	int ans = b + (a+1)/2;
	printf("%d\n", ans);
}
```
</details>
import java.util.Scanner;

class MyDate{
    public int year,month,day;
    public MyDate(int y,int m,int d)
    {
        this.year = y;this.month = m;this.day = d;
//          System.out.println("gouzao:"+);
    }
    public void set(int y,int m,int d)
    {
        this.year = y;this.month = m;this.day = d;
    }
}
class Person{
    public String name;           
    public MyDate birthday;  
    public Person(String name,MyDate a)
    {
        this.name = name;
        this.birthday = new MyDate(a.year,a.month,a.day);
        System.out.println("gouzao:"+name+" " + String.format("%d %d %d",this.birthday.year,this.birthday.month,this.birthday.day));
    }
    public void show()
    {
        System.out.println(this.name+" " + String.format("%d %d %d",this.birthday.year,this.birthday.month,this.birthday.day));
    }
    public Person(Person a)
    {
        this.name = a.name;
        this.birthday = new MyDate(a.birthday.year,a.birthday.month,a.birthday.day);
        System.out.println("gouzao:"+this.name+" " + String.format("%d %d %d",this.birthday.year,this.birthday.month,this.birthday.day));
    }
} //类Person 

public class EX{
public static void main(String args[]){
        String name; 
		int y,m,d;
        Scanner sc = new Scanner(System.in);
        name= sc.next();
        y= sc.nextInt();
        m= sc.nextInt();
        d= sc.nextInt();
        MyDate t=new MyDate(y,m,d);
        Person p1=new Person(name,t); 
        Person p2=new Person(p1);
	    p2.birthday.set(1987,2,27); 
		p1.show();
		p2.show();     
	    p2.birthday = new MyDate(2020,1,2);
		p1.show();
		p2.show(); 
}
}



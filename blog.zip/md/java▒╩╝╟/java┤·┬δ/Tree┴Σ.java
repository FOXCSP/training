package JavaCode.JavaSourse;

import java.util.Scanner;

public class test {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int a,b;
        a = scan.nextInt();
        b = scan.nextInt();
        Tree tree = new Tree(a);
        tree.grow(b);
        tree.age();
        // System.out.println(String.format("%.2f", rec.get_square()));
        scan.close();
    }
}
class Tree extends test 
{
    int ages;
    public Tree(int a)
    {
        this.ages = a;
    }
    public void grow(int years)
    {
        this.ages += years;
    }
    public void age()
    {
        System.out.println(ages);
    }
}
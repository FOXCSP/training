import java.util.Scanner;
abstract class ClosedFigure               //闭合图形抽象类
{
       String shape;
       public ClosedFigure(String s)
       {
           this.shape = s;
       }
   
       abstract double perimeter();
       abstract double area();

   public void print()                          //显示形状、属性、周长及面积
    {
        System.out.println("this is a "+this.shape+",perimeter:"+this.perimeter()+",area:"+this.area());
    }
}

 //定义椭圆类 
class Ellipse extends ClosedFigure
{
    int a,b;
    public Ellipse(int a,int b){
        super("Ellipse");
        this.a = a;
        this.b = b;
    }

    @Override
    double perimeter() {
        return Math.PI*(this.a+this.b);
    }
    double area()
    {
        return Math.PI * this.a * this.b;
    }
}

 //定义矩形类
class Rectangle extends ClosedFigure
{
    int a,b;
    public Rectangle(int a,int b){
        super("Rectangle");
        this.a = a;
        this.b = b;
    }
    @Override
    double perimeter() {
        return 2.0 * (a + b);
    }
    double area()
    {
        return a * b;
    }
}

public class ClosedFigure_ex  
{
public static void main(String args[]){
int a,b;
ClosedFigure d1;
ClosedFigure d2;
try{
Scanner sc = new Scanner(System.in);
String str1 = sc.next();
a=Integer.parseInt(str1);
str1 = sc.next();
b=Integer.parseInt(str1);
d1=new Ellipse(a,b);
d1.print();

String str2 = sc.next();
a=Integer.parseInt(str2);
str2 = sc.next();
b=Integer.parseInt(str2);
d2=new Rectangle(a,b);
d2.print();
}catch(Exception e){
System.out.println("error");
}

}
}




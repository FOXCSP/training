package JavaCode.JavaSourse;

import java.util.Scanner;

public class test {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        double a, b, c, d;
        a = scan.nextDouble();
        b = scan.nextDouble();
        c = scan.nextDouble();
        d = scan.nextDouble();
        Complex c1 = new Complex(a, b);
        if (d == 0) {
            Complex c2 = new Complex(c);
            String s = scan.next();
            if(s.compareTo("a") == 0) c1.add(c2);
            else c1.sub(c2);
        } else {
            Complex c2 = new Complex(c, d);
            String s = scan.next();
            if(s.compareTo("a") == 0) c1.add(c2);
            else c1.sub(c2);
        }
        c1.show();
        // System.out.println(String.format("%.2f", rec.get_square()));
        scan.close();
    }
}

class Complex extends test {
    double a, b; // a 是 实数部分 b 是复数部分

    public Complex(double a) {
        this.a = a;
    }

    public Complex(double a, double b) {
        this.a = a;
        this.b = b;
    }

    public void show() {
        System.out.print(String.format("%.1f", this.a));
        if(this.b < 0) System.out.println(String.format("%.1f", this.b) + "i");
        else {
            System.out.println("+" + String.format("%.1f",this.b) + "i");
        }
    }

    public void add(Complex c) {
        this.a += c.a;
        this.b += c.b;
    }

    public void sub(Complex c) {
        this.a -= c.a;
        this.b -= c.b;
    }
}

public  class  Circle{
    Point center;
    int r;
    public Circle(int r,Point p)
    {
        this.r = r;
        center = p;
//        this.center = new Point(p.x);
    }
    public  void  showInfo(){System.out.println("center=("+center.getx()+","+center.gety()+");r="+r+";");}

    public  static  void  main(String  args[]){
        Point  p=new  Point(10,20);
        Circle  c=new  Circle(5,p);
        p.showInfo();
        c.showInfo();
    }
}

class  Point{
    private  int  x,y;
    public Point(int x,int y)
    {
        this.x = x;
        this.y = y;
    }
    public int getx()
    {
        return x;
    }
    public int gety()
    {
        return y;
    }
    public void showInfo()
    {
        System.out.println("x="+this.x+";"+"y="+this.y+";");
    }
}
import java.util.Scanner;
public class Date{
 public int y,m,d;
    public Date(int a,int b,int c)
    {
        this.y = a;
        this.m = b;
        this.d = c;
    }
    public int getnum(int year2,int month2,int day2)
    {
        int days = 0;
        int year1,num2 = 0,num1 = 0,all = 0;
        year1=1920;
        for(year1=1920;year1<year2;year1++)
            if((year1%4==0&&year1%100!=0)||(year1%400==0))
                num2++;
            else
                num1++;
        all=366*num2+365*num1;//查询的那一年（xxxx-xx-1）到标准（1920-1-1）的天数
        switch(month2){
            case 1:days=day2;break;
            case 2:days=31+day2;break;
            case 3:days=31+28+day2;break;
            case 4:days=31+28+31+day2;break;
            case 5:days=31+28+31+30+day2;break;
            case 6:days=31+28+31+30+31+day2;break;
            case 7:days=31+28+31+30+31+30+day2;break;
            case 8:days=31+28+31+30+31+30+31+day2;break;
            case 9:days=31+28+31+30+31+30+31+31+day2;break;
            case 10:days=31+28+31+30+31+30+31+31+30+day2;break;
            case 11:days=31+28+31+30+31+30+31+31+30+31+day2;break;
            default :days=31+28+31+30+31+30+31+31+30+31+30+day2;break;
        }
        if(month2>2&&((year1%4==0&&year1%100!=0)||(year1%400==0)))
            days=days+1;/*如果查询年份是闰年则在天数加一*/
        return days + all;
}

int DiffDays(Date d){//计算两个日期之间的相距天数的成员方法
int a = getnum(this.y,this.m,this.d);
int b = getnum(d.y,d.m,d.d);
return b - a;
}

public static void main(String args[]){
int a,b,c;
Date d1,d2;
try{
Scanner sc = new Scanner(System.in);
String str1 = sc.next();
a=Integer.parseInt(str1);
str1 = sc.next();
b=Integer.parseInt(str1);
str1 = sc.next();
c=Integer.parseInt(str1);
d1=new Date(a,b,c);
String str2 = sc.next();
a=Integer.parseInt(str2);
str2 = sc.next();
b=Integer.parseInt(str2);
str2 = sc.next();
c=Integer.parseInt(str2);
d2=new Date(a,b,c);
System.out.println("Daynum:"+d1.DiffDays(d2));
}catch(Exception e){
System.out.println("error");
}
}
}


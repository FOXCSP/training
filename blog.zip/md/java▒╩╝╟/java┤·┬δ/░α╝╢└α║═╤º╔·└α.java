public class Class{
    Student mate[] = new Student[100];
    int n = 0;
    public Class(String s,int sc) {}
    public void append(Student p){
        mate[n ++] = p;
    }

public void totalAndaverage(){ 
  int sum = 0,count = 0;
        for(int i = 0;i < n;i ++){
            sum += mate[i].score;
        }
        count = n;
System.out.println("total score:"+sum);  
System.out.println("average score:"+sum/count);
}

public void maxAndmin(){ 
 int max = 0,min = 0;
        for(int i = 0;i < n;i ++){
            if(mate[i].score > mate[max].score) max = i;
        }
        for(int i = 0;i < n;i ++){
            if(mate[i].score < mate[min].score) min = i;
        }
System.out.println("max Info:"+mate[max].showInfo());
System.out.println("max Info:"+mate[min].showInfo());  
 }

public static void main(String args[]){
Class c=new Class("class1",3);
Student p=new Student("zhangsan","101",47);
c.append(p);
p=new Student("lisi","102",68);
c.append(p);
p=new Student("wanger","103",98);
c.append(p);
c.totalAndaverage();
c.maxAndmin();
}
}

class Student{
 int score;
    String num,name;

    public Student(String name,String num,int score) {
        this.name = name;
        this.num = num;
        this.score = score;
    }
    public String showInfo() {
        return "name=" + this.name + ";num=" + this.num + ";score=" + this.score + ";";
    }
}


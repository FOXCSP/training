package JavaCode.JavaSourse;

import java.util.Scanner;

public class test {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        String patname, breed;
        double age, weight;
        patname = scan.next();
        breed = scan.next();
        age = scan.nextDouble();
        weight = scan.nextDouble();
        if (patname.compareTo("x") == 0) {
            Dog dog = new Dog();
            dog.show();
            System.out.println(breed + " " + String.format("%.1f", age) + " "
                    + String.format("%.1f", weight));
        } else {
            Dog dog = new Dog(patname,breed,age,weight);
            dog.show();;
        }
        scan.close();
    }
}
class Dog extends test {
    String patname;
    String breed;
    double age, weight;

    public Dog(String patname, String breed, double age, double weight) {
        this.patname = patname;
        this.breed = breed;
        this.age = age;
        this.weight = weight;
    }

    public Dog() {
        this.patname = "xiaoxiao";
        this.breed = "sheepdog";
        this.age = 2.0;
        this.weight = 10.0;
    }

    public void show() {
        // String.for
        System.out.print(this.patname + " " + this.breed + " "
                + String.format("%.1f", this.age) + " " +
                String.format("%.1f", this.weight) + '\n');
    }
}
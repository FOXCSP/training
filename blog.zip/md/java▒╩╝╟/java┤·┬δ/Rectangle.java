package JavaCode.JavaSourse;

import java.util.Scanner;

public class test {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        double a,b,c,d;
        a = scan.nextDouble();
        b = scan.nextDouble();
        c = scan.nextDouble();
        d = scan.nextDouble();
        Rectangle rec = new Rectangle(a,b,c,d);
        System.out.println(String.format("%.2f", rec.get_square()));
        scan.close();
    }
}

class Rectangle extends test{
    double x1,y1,x2,y2;
    public Rectangle(double a,double b,double c,double d)
    {
        this.x1 = a;
        this.x2 = c;
        this.y1 = b;
        this.y2 = d;
    }
    public double get_square()
    {
        double square = abs(x2 - x1) * abs(y2 - y1);
        return square;
    }
    private double abs(double d) {
        if(d < 0) return -1 * d;
        else return d;
    }
}
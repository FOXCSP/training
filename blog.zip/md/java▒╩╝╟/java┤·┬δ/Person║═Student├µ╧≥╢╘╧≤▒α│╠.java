//请定义Person类
class Person {
        String name;
        int age;
        static int num = 0;
        String Nationality;
        public Person(String name,int age,String nat){
                this.name = name;
                this.age = age;
                this.Nationality = nat;
                this.num ++;
        }
        public Person(){}
        public void getName(){
                System.out.println("Name=" + this.name + ";");
//                return this.name;
        }
        public void getAge() {
                System.out.println("Age=" + this.age + ";");
        }
        public void growUp() {
                this.age ++;
        }

        public void getNationality() {
                System.out.println("Nationality=" + this.Nationality + ";");
        }
        public void show() {
                System.out.println("Person count:" + num + ";");
        }
}

//请定义Nationality接口
interface Nationality {
        public String Nationality = "";
        void custom();
        void policy();
}

//定义一个Student类继承Person类，实现Nationality接口
public class Student extends Person implements Nationality {
        public Student(String name,int age,String Nationality,String s) {
                super(name,age,Nationality);
        }
        public Student(String name,String s) {
                super(name,10,"han");
        }
        @Override
        public void custom() {
                System.out.println("Spring Festival, Dragon Boat Festival, Mid-Autumn Festival");
        }
        @Override
        public void policy() {
                if(super.Nationality == "han") {
                        System.out.println("No preferential policies;");
                }else{
                        System.out.println("Have preferential policies;");
                }
        }
        public void growUp() {
                super.growUp();
                if(super.age < 23) System.out.println("Undergraduate;");
                else System.out.println("Postgraduate;");
        }


//请参考main函数的内容编写以上内容
public static void main(String args[]){
Person a=new Person("zhangsan",19,"han");
a.getName();
a.getAge();
a.getNationality();
a.growUp();
a.getAge();
a.show();

Person b=new Person("lisi",39,"man");
b.getName();
b.getAge();
b.getNationality();
b.growUp();
b.getAge();
b.show();

Student c=new Student("wanger",33,"man","Postgraduate");
c.growUp();
c.custom();
c.policy();
c.show();

Student d=new Student("wanger","Undergraduate");
d.growUp();
d.custom();
d.policy();
d.show();
}
}




---
title : Java 学习之基本语法
categories : "Java学习"
---



# Java 学习之基本语法

### 基本数据类型

#### 数据类型分类

1.基本数据类型 (8种)

2.引用数据类型 **【数组（array）、类（ class）、接口（ interface）】**

```java
// 布尔型
boolean -> Boolean
// 整数类型 
byte -> Byte
short -> Short
int -> Integer
long -> Long
// 浮点数类型
float -> Float
double -> Double
// 字符型
char -> Character
```


#### 变量定义规则

**[修饰符] 类型 变量 [= 表达式]{,变量[= 表达式]}**

#### 运算符

算术运算符 ：+、-、*、/、…………与C++一致

关系运算符：==  、>= 、<=  …………

位运算符：~ 、&、 |、  ^、 <<、 >>、 <<<

```c++
// 位运算
n >> 1 等价于 n 除以 2
```

条件运算符：表达式 1 ？表达式2 ：表达式3

```java
if(表达式1 == true) 表达式2;
    else 表达式3;
```

对象运算符：instanceof

```
Data aday = new Data();
aday instanceof Data ==> true
```

### 语法基本原则

类型兼容原则

不同的数据类型有不同的赋值规则

int 可以赋值给 long

float 可以赋值给 double

注意 ： float a = 12.222 会报错 原因是 12.222默认为 double 型的

…………

### 数组

```java
/********************
* @ 一维数组 ：
********************/
int a[];
int[] a; // 不可以 int a[5] 开静态数组
int a[] = new int[100];// java 用 new 分配空间 类似于 C++

/*******************
* @ 二维数组
*******************/
int a[][] = new int[100][100];
int a[][] = {{1,2},{3,4}}; 
//不等长数组
int a[][];
a = new int[2];
a[0] = new int[10];
a[1] = new int[11];

/*******************
* @ 字符数组  * 和  C++ 类似
*******************/
String str = "abc";
String str1 = str; 
```

### 方法

String 类的主要方法

String.length();

String.charAt(n); // 获取第n个字符

String.substring(0,n)获得 0~n长度的字串




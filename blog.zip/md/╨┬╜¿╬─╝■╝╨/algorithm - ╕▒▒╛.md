

[TOC]

# 1. 基础算法

#### 1.1求逆序对数量

```cpp
long long m_sort(int l,int r)
{
    if(l>=r) return 0;
    int mid=l+r>>1;
    int i=l,j=mid+1;
    long long res=m_sort(l,mid)+m_sort(mid+1,r);
    int k=0;
    while(i<=mid&&j<=r)
    {
        if(q[i]<=q[j]) temp[k++]=q[i++];
        else {
            temp[k++]=q[j++];
            res+=mid-i+1;
        }
    }
    while(i<=mid)
    {
        temp[k++]=q[i++];
    }
    while(j<=r) temp[k++]=q[j++];
    for(int i=l,j=0;i<=r;i++,j++)
    q[i]=temp[j];
    return res;
}
```

#### 1.2 二分

```cpp
while(l<r)
        {
            int mid=l+r>>1;
            if(q[mid]>=k) r=mid;        //二分，若右区间被替换，则mid为l+r>>1
            else l=mid+1;
        }

while(l<r)
            {
                int mid=l+r+1 >> 1;
                if(q[mid]<=k)   l=mid;      //若左区间被替换，则mid为l+r+1>>1
                else r=mid-1;
            }
```

#### 1.3 二维前缀和与差分与二维差分

```cpp
/二维前缀和
  for(int i=1;i<=n;i++)
        for(int j=0;j<=m;j++)
            S[i][j]=S[i-1][j]+S[i][j-1]-S[i-1][j-1]+a[i][j];
//一维差分
void insert(int l,int r,int c)
{
    b[l]+=c;
    b[r+1]-=c;
}

 for(int i=1;i<=n;i++)
    insert(i,i,a[i]);

    while (m -- ){
        int l,r,c;
        cin>>l>>r>>c;
        insert(l,r,c);
    }

    for(int i=1;i<=n;i++)
    b[i]+=b[i-1];

//二维差分
void insert(int x1,int y1,int x2,int y2,int c)
{
    b[x1][y1]+=c;
    b[x2+1][y1]-=c;
    b[x1][y2+1]-=c;
    b[x2+1][y2+1]+=c;
}


for(int i=1;i<=n;i++)
        for(int j=1;j<=m;j++)
            insert(i,j,i,j,a[i][j]);

    while (q -- ){
        int x1,y1,x2,y2,c;
        cin>>x1>>y1>>x2>>y2>>c;
        insert(x1,y1,x2,y2,c);
    }

    for(int i=1;i<=n;i++)
        for(int j=1;j<=m;j++)
            b[i][j]+=b[i-1][j]+b[i][j-1]-b[i-1][j-1];
```

#### 1.4 双指针典例

##### 1.4.1 最长连续不重复子序列

```cpp
int res=0;
    for(int i=0,j=0;i<n;i++)
    {
        s[a[i]]++;
        while(s[a[i]]>1)
        {
            s[a[j]]--;
            j++;
        }
        res=max(res,i-j+1);
    }
```

##### 1.4.2 判断a是否为b的子序列（1e5）

```cpp
    int i=0,j=0;
    while( i<n &&j < m)
    {
        if(a[i]==b[j])  i++;;
        j++;
    }
```

#### 1.5 需要保序的离散化

```cpp
typedef pair<int, int> PII;         //每一次操作都是一个二元组，这里用pair


int n,m;
int a[N],s[N];
vector <int> alls;          //alls数组内存的是所有需要进行离散化的数以及进行完离散化之后的数组
vector<PII> add,query;          //add数组内存的是每次对数的操作，query数组内存的是每次询问的左右区间

int find (int x)            //查找离散化后数组的下标
{
    int l = 0, r = alls.size()-1;       
    while(l < r)
    {
        int mid = (l+r) >> 1;
        if(alls[mid] >= x)  r = mid;        //当该下标对应的值为待查找值（离散化前的大数）时，返回下标+1（为了从1开始便于求前缀和）
        else l = mid + 1;
    }
    return r + 1;
}


int main()
{
    cin>>n>>m;
    for(int i=0;i < n ; i++)
    {
        int x , c;
        scanf("%d%d",&x, &c);

        add.push_back({x,c});   //把对原数组的操作存放进去,即把x加上c

        alls.push_back(x);      //将需要进行离散化的数存到alls里
    }
    for(int i = 0; i < m; i++)
            {
                int l, r;
                scanf("%d%d",&l, &r);
                query.push_back({l, r});        //把每次询问存放进去，即存放需要求和的左右区间
                alls.push_back(l);          //由于l,r也可能是大数，因此我们也需要将l和r进行离散化
                alls.push_back(r);
            }

    //此处是离散化的核心，即进行离散化的过程
    sort(alls.begin(), alls.end());             //将需要离散化的数组进行排序
    alls.erase(unique(alls.begin(), alls.end()),alls.end());    //去重，目的是将数组中的存放的数量减少，节省内存空间

    for(auto it : add)          
    {
        int x = find(it.first);         //寻找被加的数进行离散化之后的下标
        a[x] += it.second;              //求离散化后的数组a
    }

    for(int i=1;i<=alls.size(); i++)
    s[i] = s[i-1] + a[i];               //求离散化后数组的前缀和

    for(auto it : query) {                  //处理每次询问
        int l = find(it.first);                 //寻找左区间进行离散化之后的下标
        int r = find(it.second);                //寻找右区间进行离散化之后的下标
        printf("%d\n" ,s[r]-s[l-1]);             //求区间和
    }

    return 0;
}
```

#### 1.6 不需要保序的离散化

```cpp
//待补充
```

#### 1.7 区间合并

```cpp
vector<PII> segs;

void merge(vector<PII> &segs)
{
    vector<PII> res;
    sort(segs.begin(), segs.end());
    int st = -2e9, ed = -2e9;
    for(auto seg : segs)
    {
        if(ed < seg.first)
        {
            if(st != -2e9)    
            res.push_back({st , ed});
            st = seg.first;
            ed = seg.second;
        }   
        else
        ed=max(ed , seg.second);
    }    
        if(st != -2e9)  res.push_back({st , ed});

        segs=res;


}

int main()
{
    int n;
    cin>>n;
    for(int i = 0;i < n; i++ )
    {
        int l , r;
        cin>>l>>r;
        segs.push_back({l,r});
    }

    merge(segs);

    cout<<segs.size()<<endl;
    return 0;
}
```

#### 1.8 区间最值问题（RMQ）

```cpp
int w[N];
int f[N][M];
int n, m;

void init()
{
    for(int j = 0; j < M; j ++)     //先枚举区间长度
    {
        for(int i = 1; i + (1 << j) - 1 <= n; i ++)      //枚举区间左端点
        {
            if(!j)  f[i][j] = w[i];
            else    f[i][j] = max(f[i][j - 1], f[i + (1 << j - 1)][j - 1]);
        }
    }
}

int query(int l, int r)
{
    int len = r - l + 1;
    int k = log(len) / log(2);

    return max(f[l][k], f[r - (1 << k) + 1][k]);        //这两个区间一定覆盖查询区间
}

int main()
{
    cin >> n;
    for(int i = 1; i <= n; i ++)
        cin >> w[i];

    init();
    cin >> m;
    while (m -- )
    {
        int l, r;
        cin >> l >> r;
        cout << query(l, r) << endl;
    }

    return 0;
}
```

#### 1.9 manacher算法

```cpp
int n;
char a[N], b[N];
int p[N];
int res;

void init()
{
    int k = 0;
    b[k ++] = '$';
    b[k ++] = '#';
    for(int i = 0; i < n; i ++)
    {
        b[k ++] = a[i];
        b[k ++] = '#';
    }
    b[k ++] = '^';
    n = k;
}

void manacher()
{
    int mr = 0, mid;
    for(int i = 1; i < n; i ++)
    {
        if(i < mr)
            p[i] = min(p[mid * 2 - i], mr - i);
        else p[i] = 1;
        while(b[i - p[i]] == b[i + p[i]])   p[i] ++;
        if(i + p[i] > mr)
        {
            mr = i + p[i];
            mid = i;
        }
    }
}

int main()
{
    scanf("%s", a);
    n = strlen(a);

    init();
    manacher();

    for(int i = 0; i < n; i ++)
        res = max(res, p[i]);

    cout << res - 1 << endl;
    return 0;
}
```

#### 1.10 最小表示法

###### 用于求字符串的最小表示，可以用来判断两个环形字符串是否是同一个字符串

```cpp
int get_min(char s[])
{
    int i = 0, j = 1;
    while(i < n && j < n)
    {
        int k = 0;
        while(k < n && s[i + k] == s[j + k])    k ++;
        if(k == n)  break;
        if(s[i + k] > s[j + k]) i += k + 1;
        else j += k + 1;
        if(i == j)  j ++;
    }
    int k = min(i, j);
    s[k + n] = 0;
    return k;
}

int main()
{
    cin >> a >> b;
    n = strlen(a);
    memcpy(a + n, a, n);
    memcpy(b + n, b, n);
    int x = get_min(a);
    int y = get_min(b);
    if(strcmp(a + x, b + y))    cout << "No" << endl;
    else
    {
        cout << "Yes" << endl;
        cout << a + x << endl;
    }
    return 0;
}
```

#### 1.11 对顶堆维护动态中位数

```cpp
/*
对顶堆，维护一个大根堆和一个小根堆，对于每个元素，如果大根堆为空或小于大根堆顶，则插入大根堆，否则插到小根堆，这两个堆需要时刻满足：
序列中从小到大排名为1 ~ M / 2 + 1的整数在大根堆中
序列中从小到大排名为M / 2 + 2 ~ M的整数存储在小根堆中
如果不满足，就把多出来的数放到另一个堆，由此序列的中位数一定是大根堆的堆顶
*/
int main()
{
    int T;
    cin >> T;
    while(T --)
    {
        priority_queue<int> b_heap;
        priority_queue<int, vector<int>, greater<int> > s_heap;
        int n, m;
        cin >> n >> m;
        cout << n << " " << (m + 1 >> 1) << endl;
        int cnt = 0;
        for(int i = 0; i < m; i ++)
        {
            int x;
            cin >> x;
            if(b_heap.empty() || x <= b_heap.top()) //大根堆为空或x小于大根堆顶，插入大根堆
                b_heap.push(x);
            else    s_heap.push(x);     //否则插入小根堆

            if(b_heap.size() > s_heap.size() + 1)
            {
                s_heap.push(b_heap.top());
                b_heap.pop();
            }

            if(s_heap.size() > b_heap.size())
            {
                b_heap.push(s_heap.top());
                s_heap.pop();
            }

            if(i % 2 == 0)
            {
                cout << b_heap.top() << " ";
                if(++ cnt % 10 == 0)    cout << endl;
            }
        }
        if(cnt % 10)    cout << endl;
    }

    return 0;
}
```

#### 1.12 二进制状态压缩求最短Hamilton路径

```cpp
int n;
int w[N][N];                            //用w来存储整个图
int f[M][N];                            //f[i][j]表示从0走到j，走过的点为i的所有路径长度，i是一个20位二进制数，如果第k位为1，表示这个点已经走过了

int main()
{
    cin >> n;                           //n个点
    for(int i = 0; i < n; i ++)         
    {
        for(int j = 0; j < n; j ++)
            cin >> w[i][j];             //输入n个点
    }

    memset(f, 0x3f, sizeof f);          //初始化路径长度为无穷大
    f[1][0] = 0;                        //初始化0号点的路径长度为0
    for(int i = 0; i < 1 << n; i ++)    //枚举所有的状态
        for(int j = 0; j < n; j ++)
            if(i >> j & 1)              //从0走到j时，i中一定要包含j，即i的第j位一定为1
                for(int k = 0; k < n; k ++)             //枚举j点从哪一个点转移过来
                    if((i - (1 << j)) >> k & 1)         //如果i除去第j个点之后包含第k个点
                        f[i][j] = min(f[i][j], f[i - (1 << j)][k] + w[k][j]);   //那么当前的状态就是从0走到k加上k走到j的所有路径取最小值

    cout << f[(1 << n) - 1][n - 1] << endl;             //输出走完所有的点，并且走到n-1号点时的距离
    return 0;
}
```

# 2. 数据结构

#### 2.1 单调栈

###### 用于寻找一个数左边最近的比它大（小）的数

```cpp
int stk[N],tt;
int main()
{
    int n;
    cin>>n;
    for(int i=0;i<n;i++)
    {
        int x;
        cin>>x;
        while(tt && stk[tt]>=x) tt--;
        if(tt)      cout<<stk[tt]<<" ";
        else        cout<<"-1"<<" ";

        stk[++tt] = x;

    }
    return 0;
}
```

#### 2.2 单调队列（滑动窗口）

###### 维护区间内最大值和最小值

```cpp
int n,k;
int a[N],q[N];

int main()
{
    scanf("%d%d",&n,&k);
    for(int i=0;i<n;i++)
    scanf("%d",&a[i]);

    int hh=0,tt=-1;
    for(int i=0;i<n;i++)
    {
        //首先判断队头是否滑出滑动窗口
        if(hh <=tt   && i - k + 1 > q[hh])  hh++;
        while(hh <= tt && a[q[tt]] >= a[i]) tt--;
        q[++tt] = i;
        if(i >= k-1)
        printf("%d ",a[q[hh]]);
    }
    puts("");

    hh = 0, tt = -1;
    for(int i=0;i<n;i++)
    {
        //首先判断队头是否滑出滑动窗口
        if(hh <=tt   && i - k + 1 > q[hh])  hh++;
        while(hh <= tt && a[q[tt]] <= a[i]) tt--;
        q[++tt] = i;
        if(i >= k - 1)
        printf("%d ",a[q[hh]]);
    }
    puts("");

    return 0;
}
```

#### 2.3 KMP算法

###### KMP算法是一种在模式串中寻找给定模板串的一种算法，该算法的时间复杂度为O(M+N)，相较于暴力算法，该算法最大的特点是模板串指针不需要回溯即可判断两个串是否匹配

该算法需要注意的几个地方

1. next数组的含义：next[i]的含义为：当当前模式串与模板串的元素不匹配时，当前元素之前的模板串的元素中，前缀与后缀相同的最大串长度
2. 求next数组时，next数组从下标2开始求，因为next[0]和next[1]的值均为0,
3. 进行kmp匹配时，从i下标1开始，j从下标0开始
4. p数组和s数组均从下标1开始存放元素

```cpp
int n,m;
char p[N], s[M];

int ne[N];

int main()
{
    cin>>n>>p+1>>m>>s+1;    //p数组和s数组均从下标1开始存放元素

    //求next数组的过程
    for(int i = 2 ,j = 0; i <= n ; i++ )
    {
        while(j && p[i] != p[j+1])  j=ne[j];    //前缀与后缀不同时，记录前缀与后缀相同时的长度
        if(p[i] == p[j+1])  j++;        //如果前缀和后缀相同，那么ij继续右移，判断更大的前缀后缀是否相同
        ne[i] = j;     //next数组的含义是:当当前模式串与模板串的元素不匹配时，当前元素之前的模板串的元素中，前缀与后缀相同的最大串长度
    }

    //kmp的匹配过程
    for(int i = 1, j = 0; i <= m; i ++)
    {
        while(j && s[i] != p[j+1])  j = ne[j];      //当模板串与模式串不匹配时，将模板串右移ne[j]的距离
        if(s[i] == p[j+1])  j++;        //如果模板串与模式串匹配，那么就将它们的下一位进行匹配
        if(j == n)      //如果模板串所有的字符都被匹配了，那么匹配成功
        {
            printf("%d ",i-n);
            j=ne[j];
        }
    }
    return 0;
}
```

#### 2.4 Trie统计字符串

###### son数组第一维表示n号节点，第二维表示它的第几个儿子

```cpp
int son[N][26],cnt[N],idx;
char str[N];

void insert(char str[])
{
    int p=0;
    for(int i=0 ; str[i] ; i++)
    {
        int u = str[i] - 'a';           //将字母映射到下标
        if(!son[p][u])      son[p][u]=++idx;        //如果该节点的儿子不存在，那么就将它加入进去
        p=son[p][u];            //转到p号节点的u号儿子
    }
    cnt[p]++;           //出现次数+1
}

int query(char str[])
{
    int p=0;
    for(int i=0;str[i];i++)
    {
        int u = str[i] - 'a';
        if(!son[p][u])  return 0;
        p = son[p][u];
    }
    return cnt[p];
}

int main()
{
    int n;
    cin>>n;
    while (n -- ){
        char op[2];
        scanf("%s%s",op,str);
        if(op[0] == 'I')    insert(str);
        else printf("%d\n", query(str));
    }
    return 0;
}
```

#### 2.5 并查集带维护集合大小

```cpp
int find(int x)  // 并查集
{
    if(p[x] != x)   p[x] = find(p[x]);
    return p[x];
}


int main()
{
    cin>>n;
    for(int i=1;i<=n;i++)
    {
    p[i]=i;
    siz[i]=1;
    }
    cin>>m;
    while (m -- )
    {
        char op[5];
        int a,b;

        scanf("%s",op);
        if(op[0] == 'C')
        {
             scanf("%d%d",&a,&b);
            if(find(a) == find(b))  continue;
            siz[find(b)] += siz[find(a)];
            p[find(a)] = find(b); 

        }

        else if(op[1] == '1')
        {
             scanf("%d%d",&a,&b);
            if(find(a) == find(b))
            cout<<"Yes"<<endl;
            else
            cout<<"No"<<endl;
        }

        else if(op[1] == '2')
        {
             scanf("%d",&a);
             cout<<siz[find(a)]<<endl;
        }
    }
    return 0;
}
```

#### 2.6 拓展域并查集（拆点）

```cpp
int find(int x)
{
    if(p[x] != x)   p[x] = find(p[x]);
    return p[x];
}

int main()
{
    cin >> n >> k;
    int res = 0;

    for(int i = 1; i <= 3 * n; i ++)    p[i] = i;

    while(k --)
    {
        int d, x, y;
        cin >> d >> x >> y;
        int xs = x, xe = x + n, xy = x + 2 * n;
        int ys = y, ye = y + n, yy = y + 2 * n;

        if(d == 1)
        {
            if(x > n || y > n)  res ++;
            else if(find(xs) == find(yy))   res ++;
            else if(find(ye) == find(xs))   res ++;
            else
            {
                p[find(xs)] = find(ys);
                p[find(xe)] = find(ye);
                p[find(xy)] = find(yy);
            }
        }

        if(d == 2)
        {
            if(x > n || y > n)  res ++;
            else if(x == y) res ++;
            else if(find(xs) == find(ys))   res ++;
            else if(find(ye) == find(xs))   res ++;
            else
            {
                p[find(xe)] = find(ys);
                p[find(xs)] = find(yy);
                p[find(xy)] = find(ye);
            }
        }

    }

    cout << res << endl;
    return 0;
}
```

#### 2.7 手写堆排序

```cpp
int h[N];
int n,m;
int siz;

void down(int u)
{
    int t = u;                  //t为最小值
    if(u * 2 <= siz && h[u * 2] < h[t])    t = u * 2;                  //如果左儿子存在并且左儿子的值小于父节点的值，那么最小值更新为左儿子
    if(u * 2 + 1 <= siz && h[u * 2 + 1] < h[t])  t = u * 2 + 1;        //如果右儿子存在并且右儿子的值小于父节点的值，那么最小值更新为右儿子
    if(u != t)                          //如果传入的值不是最小值，那么将该值与最小值互换，然后递归将该值放入堆中
    {
        swap(h[u], h[t]);
        down(t);
    }
}


void up(int u)
{
   while(u / 2 && h[u / 2] > h[u])
   {
       swap(h[u / 2], h[u]);
       u /= 2;
   }

}

int main()
{
    cin >> n >> m;
    for(int i = 1; i <= n; i++)
    scanf("%d", &h[i]);
    siz = n;

    for(int i = n / 2; i; i--)
    down(i);

    while (m -- )
    {
            cout << h[1] << " ";
            h[1] = h[siz];
            siz--;
            down(1);
    }

    return 0;
}
```

#### 2.8 字符串哈希

###### 用于判断两个区间内的字符串是否完全相同

```cpp
typedef unsigned long long ULL;
const int N = 1e5 + 5, P = 131;
ULL h[N], p[N];

ULL query(int l, int r)
{
    return  h[r] - h[l - 1] * p[r - l + 1];
}

int main()
{
    int n, m;
    cin >> n >> m;
    string x;
    cin >> x;
    p[0] = 1;
    h[0] = 0;
    for(int i = 0; i < n; i ++)
    {
        p[i + 1] = p[i] * P;
        h[i + 1] = h[i] * P + x[i];
    }

    while(m --)
    {
        int l1, r1, l2, r2;
        cin >> l1 >> r1 >> l2 >> r2;
        if(query(l1, r1) == query(l2, r2))
            cout << "Yes" << endl;
        else
            cout << "No" << endl;
    }

    return 0;
}
```

#### 2.9 树状数组

##### 2.9.1 区间修改，单点查询

```cpp
LL tr[N];
int a[N];
int n, m;

int lowbit(int x)
{
    return x & -x;
}

void add(int x, int c)
{
    for(int i = x; i <= n; i += lowbit(i))
    tr[i] += c;
}

LL sum(int x)
{
    LL res = 0;
    for(int i = x; i ; i -= lowbit(i))
    res += tr[i];
    return res;
}

int main()
{
    cin >> n >> m;
    for(int i = 1; i <= n ; i ++)
    cin >> a[i];
    for(int i = 1; i <= n ;i ++)
    {
        add(i, a[i] - a[i - 1]);
    }

    while(m --)
    {
        char op[2];
        int l;
        scanf("%s%d", op, &l);
        if(op[0] == 'C')
        {
            int r, d;
            cin >> r >> d;
            add(l, d);
            add(r + 1, -d);
        }
        else
        cout << sum(l) << endl;
    }

    return 0;
}
```

##### 2.9.2 单点修改，区间查询

```cpp
int lowbit(int x)
{
    return x & -x;
}

void add(int x, int c)
{
    for(int i = x; i <= n; i += lowbit(i))
    tr[i] += c;    
}

int sum(int x)
{
    int res = 0;
    for(int i = x; i; i -= lowbit(i))  res += tr[i];
    return res;
}
```

##### 2.9.3 区间修改，区间查询

```cpp
int a[N];
LL tr1[N], tr2[N];
int n, m;

int lowbit(int x)
{
    return x & -x;
}

void add(LL tr[], int x, LL c)
{
    for(int i = x; i <= n; i += lowbit(i))
    tr[i] += c;
}

LL sum(LL tr[], int x)
{
    LL res = 0;
    for(int i = x; i; i -= lowbit(i))
    res += tr[i];
    return res;
}

LL pre_sum(int x)                       //求原数组的前缀和
{
    return sum(tr1, x) * (x + 1) - sum(tr2, x);
}


int main()
{
    cin >> n >> m;
    for(int i = 1; i <= n; i ++)
    cin >> a[i];

    for(int i = 1; i <= n; i ++)
    {
        int b = a[i] - a[i - 1];
        add(tr1, i, b);
        add(tr2, i, (LL)b * i);
    }

    while(m --)
    {
        char op[2];
        int l ,r, d;
        scanf("%s%d%d", op, &l, &r);
        if(op[0] == 'Q')
        printf("%lld\n", pre_sum(r) - pre_sum(l - 1));          //原数组的区间查询
        else
        {
            cin >> d;
            add(tr1, l, d), add(tr2, l, l * d);
            add(tr1, r + 1, -d), add(tr2, r + 1, (r + 1) * -d);
        }
    }
    return 0;
}
```

#### 2.10 线段树

##### 2.10.1  单点修改，区间查询

```cpp
struct Node{
    int l, r;
    int v;
}tr[N * 4];

void pushup(int u)
{
    tr[u].v = max(tr[u << 1].v, tr[u << 1 | 1].v);
}

void build(int u, int l, int r)
{
    tr[u] = {l ,r};
    if(l == r)
    return ;
    int mid = (l + r) >> 1;
    build(u << 1, l, mid);
    build(u << 1 | 1, mid + 1, r);
}

int query(int u, int l, int r)
{
    if(tr[u].l >= l && tr[u].r <= r)  return tr[u].v;
    int mid = (tr[u].l + tr[u].r) >> 1;
    int v = 0;
    if(l <= mid)    v = query(u << 1, l ,r);
    if(r > mid) v = max(v, query(u << 1 | 1, l ,r));

    return v;
}

void modify(int u, int x, int v)
{
    if(tr[u].l == x && tr[u].r == x)    tr[u].v = v;
    else
    {
        int mid = (tr[u].l + tr[u].r) >> 1;
        if(x <= mid) modify(u << 1, x, v);
        else
        modify(u << 1 | 1, x, v);
        pushup(u);
    }
}

int main()
{
    int n = 0, last = 0;
    int m ,p;
    cin >> m >> p;
    build(1, 1, m);
    while (m -- ){
        char op[2];
        int t;
        scanf("%s%d", op, &t);
        if(op[0] == 'Q')
        {
            last = query(1, n - t + 1, n);
            cout << last << endl;
        }
        else
        {
            modify(1, n + 1, ((LL)last + t) % p);
            n ++;
        }
    }
    return 0;
}
```

##### 2.10.2 区间最大公约数（区间修改，区间查询）

```cpp
struct Node{
    int l, r;
    LL sum, d;
}tr[N * 4];

LL a[N];

LL gcd(LL a, LL b)
{
    return b ? gcd(b, a % b) : a;
}

void build(int u, int l, int r)
{
    if(l == r)
    {
        LL b = a[r] - a[r - 1];
        tr[u] = {l, l, b, b};
    }
    else
    {
        tr[u] = {l ,r};
        int mid = l + r >> 1;
        build(u << 1, l, mid);
        build(u << 1 | 1, mid + 1, r);
        tr[u].sum = tr[u << 1].sum + tr[u << 1 | 1].sum;
        tr[u].d = gcd(tr[u << 1].d, tr[u << 1 | 1].d);
    }
}

Node query(int u, int l, int r)
{
    if(l <= tr[u].l && r >= tr[u].r)    return tr[u];
    else
    {
        int mid = tr[u].l + tr[u].r >> 1;
        if(r <= mid)    return  query(u << 1, l, r);
        if(l > mid)    return query(u << 1 | 1, l, r);
        else
        {
            auto left = query(u << 1, l, r);
            auto right = query(u << 1 | 1, l, r);
            Node res;
            res.sum = left.sum + right.sum;
            res.d = gcd(left.d, right.d);

            return res;
        }
    }
}

void modify(int u, int x, LL c)
{
    if(tr[u].l == x &&  tr[u].r == x)
    {
        LL b = tr[u].sum + c;
        tr[u] = {x, x, b, b};
    }
    else
    {
        int mid = tr[u].l +tr[u].r >> 1;
        if(x <= mid)    modify(u << 1, x, c);
        else    modify(u << 1 | 1, x, c);
        tr[u].sum = tr[u << 1].sum + tr[u << 1 | 1].sum;
        tr[u].d = gcd(tr[u << 1].d, tr[u << 1 | 1].d);
    }
}

int main()
{
    cin >> n >> m;
    for(int i = 1; i <= n; i ++)
        cin >> a[i];

    build(1, 1, n);

    char op[2];
    while(m --)
    {
        int l, r;
        cin >> op >> l >> r;
        if(op[0] == 'C')
        {
            LL d;
            cin >> d;
            modify(1, l, d);
            if(r + 1 <= n)
                modify(1, r + 1, -d);
        }
        else
        {
            auto left = query(1, 1, l);
            Node right({0, 0, 0, 0});
            if(l + 1 <= r)    right = query(1, l + 1, r);
            cout << abs(gcd(left.sum, right.d)) << endl;
        }
    }

    return 0;
}
```

##### 2.10.3 带懒标记的区间修改，区间查询

```cpp
struct Node
{
    int l, r;
    LL sum, add;
}tr[N * 4];

void pushup(int u)
{
    tr[u].sum = tr[u << 1].sum + tr[u << 1 | 1].sum;
}

void pushdown(int u)
{
    auto &root = tr[u], &left = tr[u << 1], &right = tr[u << 1 | 1];
    if(root.add)
    {
        left.add += root.add, left.sum += (LL)(left.r - left.l + 1) * root.add;
        right.add += root.add, right.sum += (LL)(right.r - right.l + 1) * root.add;
        root.add = 0;
    }
}

void build(int u, int l, int r)
{
    if(l == r)  tr[u] = {l, r, w[r], 0};
    else
    {
        tr[u] = {l, r};
        int mid = l + r >> 1;
        build(u << 1, l, mid), build(u << 1 | 1, mid + 1, r);
        pushup(u);
    }
}

void modify(int u, int l, int r, int d)
{
    if(tr[u].l >= l && tr[u].r <= r)
    {
        tr[u].sum += (LL)(tr[u].r - tr[u].l + 1) * d;
        tr[u].add += d;
    }
    else
    {
        pushdown(u);
        int mid = tr[u].l + tr[u].r >> 1;
        if(l <= mid)    modify(u << 1, l, r, d);
        if(r > mid) modify(u << 1 | 1, l, r, d);
        pushup(u);
    }
}

LL query(int u, int l, int r)
{
    if(tr[u].l >= l && tr[u].r <= r)    return tr[u].sum;
    pushdown(u);
    int mid = tr[u].l + tr[u].r >> 1;
    LL sum = 0;
    if(l <= mid)    sum = query(u << 1, l, r);
    if(r > mid) sum += query(u << 1 | 1, l, r);
    return sum;
}

int main()
{
    cin >> n >> m;
    for(int i = 1; i <= n; i ++)
        cin >> w[i];

    build(1, 1, n);

    char op[2];
    int l, r, d;
    while(m --)
    {
        cin >> op >> l >> r;
        if(op[0] == 'C')
        {
            cin >> d;
            modify(1, l, r, d);
        }
        else
            cout << query(1, l ,r) << endl;
    }
    return 0;
}
```

##### 2.10.4 扫描线求矩形的面积并

```cpp
struct Segment
{
    double x, y1, y2;
    int k;
    bool operator< (const Segment &t)const
    {
        return x < t.x;
    }
}seg[N * 2];
struct Node
{
    int l, r;
    int cnt;
    double len;
}tr[N * 8];

vector<double> ys;

int find(double y)
{
    return lower_bound(ys.begin(), ys.end(), y) - ys.begin();
}

void pushup(int u)
{
    if (tr[u].cnt) tr[u].len = ys[tr[u].r + 1] - ys[tr[u].l];
    else if (tr[u].l != tr[u].r)
    {
        tr[u].len = tr[u << 1].len + tr[u << 1 | 1].len;
    }
    else tr[u].len = 0;
}

void build(int u, int l, int r)
{
    tr[u] = {l, r, 0, 0};
    if (l != r)
    {
        int mid = l + r >> 1;
        build(u << 1, l, mid), build(u << 1 | 1, mid + 1, r);
    }
}

void modify(int u, int l, int r, int k)
{
    if (tr[u].l >= l && tr[u].r <= r)
    {
        tr[u].cnt += k;
        pushup(u);
    }
    else
    {
        int mid = tr[u].l + tr[u].r >> 1;
        if (l <= mid) modify(u << 1, l, r, k);
        if (r > mid) modify(u << 1 | 1, l, r, k);
        pushup(u);
    }
}

int main()
{
    int T = 1;
    while (scanf("%d", &n), n)
    {
        ys.clear();
        for (int i = 0, j = 0; i < n; i ++ )
        {
            double x1, y1, x2, y2;
            scanf("%lf%lf%lf%lf", &x1, &y1, &x2, &y2);
            seg[j ++ ] = {x1, y1, y2, 1};
            seg[j ++ ] = {x2, y1, y2, -1};
            ys.push_back(y1), ys.push_back(y2);
        }

        sort(ys.begin(), ys.end());
        ys.erase(unique(ys.begin(), ys.end()), ys.end());

        build(1, 0, ys.size() - 2);

        sort(seg, seg + n * 2);

        double res = 0;
        for (int i = 0; i < n * 2; i ++ )
        {
            if (i > 0) res += tr[1].len * (seg[i].x - seg[i - 1].x);
            modify(1, find(seg[i].y1), find(seg[i].y2) - 1, seg[i].k);
        }

        printf("Test case #%d\n", T ++ );
        printf("Total explored area: %.2lf\n\n", res);
    }

    return 0;
}
```

##### 2.10.5 动态开点与权值线段树

```cpp
//待补充
```

#### 2.11 可持久化数据结构

##### 2.11.1 可持久化Trie

###### 支持两种操作：末尾添加一个数，求一个位置p，使得p在l-r之间，且a[p] xor ... xor a[n] xor x的值最大

```cpp
int tr[M][2], max_id[M];
int root[N];
int n, m, idx;
int s[N];

void insert(int i, int k, int p, int q) //i为前缀和下标，k为当前第几位，p为上一个版本，q为当前版本
{
    if(k < 0)
    {
        max_id[q] = i;
        return ;
    }
    int v = s[i] >> k & 1;
    if(p)   tr[q][v ^ 1] = tr[p][v ^ 1];
    tr[q][v] =  ++ idx;
    insert(i, k - 1, tr[p][v], tr[q][v]);
    max_id[q] = max(max_id[tr[q][0]], max_id[tr[q][1]]);
}

int query(int root, int c, int l)
{
    int p = root;
    for(int i = 23; i >= 0; i --)
    {
        int v = c >> i & 1;
        if(max_id[tr[p][v ^ 1]] >= l)   p = tr[p][v ^ 1];
        else    p = tr[p][v];
    }

    return c ^ s[max_id[p]];
}

int main()
{
    cin >> n >> m;
    max_id[0] = -1;
    root[0] = ++ idx;
    insert(0, 23, 0, root[0]);

    for(int i = 1; i <= n; i ++)
    {
        int x;
        cin >> x;
        s[i] = s[i - 1] ^ x;
        root[i] = ++ idx;
        insert(i, 23, root[i - 1], root[i]);
    }

    char op[2];
    int l, r, x;
    while(m --)
    {
        cin >> op;
        if(op[0] == 'A')
        {
            cin >> x;
            n ++;
            s[n] = s[n - 1] ^ x;
            root[n] = ++ idx;
            insert(n, 23, root[n - 1], root[n]);
        }
        else
        {
            cin >> l >> r >> x;
            cout << query(root[r - 1], s[n] ^ x, l - 1) << endl;
        }
    }

    return 0;
}
```

##### 2.11.2 可持久化线段树(主席树)

```cpp
//求区间内第k小数
int n, m;
int a[N];
vector<int> nums;
struct Node
{
    int l, r;
    int cnt;
}tr[N * 4 + N * 17];

int root[N], idx;

int build(int l, int r) //l,r表示左右儿子
{
    int p = ++ idx;
    if(l == r)  return p;
    int mid = l + r >> 1;
    tr[p].l = build(l, mid), tr[p].r = build(mid + 1, r);
    return p;
}

int insert(int p, int l, int r, int x)
{
    int q = ++ idx;
    tr[q] = tr[p];
    if(l == r)
    {
        tr[q].cnt ++;  
        return q;
    }
    int mid = l + r >> 1;
    if(x <= mid)    tr[q].l = insert(tr[p].l, l, mid, x);
    else    tr[q].r = insert(tr[p].r, mid + 1, r, x);
    tr[q].cnt = tr[tr[q].l].cnt + tr[tr[q].r].cnt;
    return q;
}

int find(int x)
{
    return lower_bound(nums.begin(), nums.end(), x) - nums.begin();
}

int query(int q, int p, int l, int r, int k)
{
    if(l == r)  return r;
    int cnt = tr[tr[q].l].cnt - tr[tr[p].l].cnt;
    int mid = l + r >> 1;
    if(k <= cnt)    return query(tr[q].l, tr[p].l, l, mid, k);
    else    return query(tr[q].r, tr[p].r, mid + 1, r, k - cnt);
}

int main()
{
    cin >> n >> m;
    for(int i = 1; i <= n; i ++)
    {
        cin >> a[i];
        nums.push_back(a[i]);
    }

    sort(nums.begin(), nums.end());
    nums.erase(unique(nums.begin(), nums.end()), nums.end());

    root[0] = build(0, nums.size() - 1);
    for(int i = 1; i <= n; i ++)
        root[i] = insert(root[i - 1], 0, nums.size() - 1, find(a[i]));

    while(m --)
    {
        int l, r, k;
        cin >> l >> r >> k;
        cout << nums[query(root[r], root[l - 1], 0, nums.size() - 1, k)] << endl;
    }
}
```

#### 2.12 平衡树

##### 2.12.1 普通平衡树（Treap）

###### 支持的操作：

1. 插入数值 x。
2. 删除数值 x(若有多个相同的数，应只删除一个)。
3. 查询数值 x 的排名(若有多个相同的数，应输出最小的排名)。
4. 查询排名为 x 的数值。
5. 求数值 x 的前驱(前驱定义为小于 x 的最大的数)。
6. 求数值 x 的后继(后继定义为大于 x 的最小的数)。

```cpp
struct Node
{
    int l, r;
    int key, val;
    int cnt, size;  //cnt表示某个数出现的次数，size表示子树中有多少个数
}tr[N];

int root, idx;  //idx表示当前分配到第几个节点

void pushup(int p)
{
    tr[p].size = tr[tr[p].l].size + tr[tr[p].r].size + tr[p].cnt;
}

int get_node(int key)   //创建节点
{
    tr[++ idx].key = key;
    tr[idx].val = rand();
    tr[idx].cnt = tr[idx].size = 1; //初始化cnt和size
    return idx;
}

void zig(int &p)    //右旋，传引用
{
    int q = tr[p].l;
    tr[p].l = tr[q].r, tr[q].r = p, p = q;
    pushup(tr[p].r), pushup(p);
}

void zag(int &p)
{
    int q = tr[p].r;
    tr[p].r = tr[q].l, tr[q].l = p, p = q;
    pushup(tr[p].l), pushup(p);
}

void build()
{
    get_node(-INF), get_node(INF);  //插入正无穷和无负穷哨兵
    root = 1, tr[1].r = 2;  //根节点是一号点，右儿子是二号点
    pushup(root);
    if(tr[1].val <tr[2].val) zag(root);
}

void insert(int &p, int key)
{
    if(!p)  p = get_node(key);
    else if(tr[p].key == key)   tr[p].cnt ++;
    else if(tr[p].key > key)
    {
        insert(tr[p].l, key);
        if(tr[tr[p].l].val > tr[p].val) zig(p);
    }
    else
    {
        insert(tr[p].r, key);
        if(tr[tr[p].r].val > tr[p].val) zag(p);
    }
    pushup(p);
}

void remove(int &p, int key)
{
    if(!p)  return ;
    if(tr[p].key == key)
    {
        if(tr[p].cnt > 1)   tr[p].cnt --;
        else if(tr[p].l || tr[p].r)
        {
            if(!tr[p].r || tr[tr[p].l].val > tr[tr[p].r].val)
            {
                zig(p);
                remove(tr[p].r, key);
            }
            else
            {
                zag(p);
                remove(tr[p].l, key);
            }
        }
        else p = 0;
    }
    else if(tr[p].key > key)    remove(tr[p].l, key);
    else remove(tr[p].r, key);
    pushup(p);
}

int get_rank_by_key(int &p, int key)    //通过排名找数值
{
    if(!p)  return 0;
    if(tr[p].key == key)    return tr[tr[p].l].size + 1;
    if(tr[p].key > key) return get_rank_by_key(tr[p].l, key);
    return tr[tr[p].l].size + tr[p].cnt + get_rank_by_key(tr[p].r, key);
}

int get_key_by_rank(int &p, int rank)   //通过数值找排名
{
    if(!p)  return INF;
    if(tr[tr[p].l].size >= rank)    return get_key_by_rank(tr[p].l, rank);
    if(tr[tr[p].l].size + tr[p].cnt >= rank)    return tr[p].key;
    return get_key_by_rank(tr[p].r, rank - tr[tr[p].l].size - tr[p].cnt);
}

int get_prev(int &p, int key)   //找到严格小于key的最大数
{
    if(!p)  return -INF;
    if(tr[p].key >= key)    return get_prev(tr[p].l, key);
    return max(tr[p].key, get_prev(tr[p].r, key));
}

int get_next(int &p, int key)   //找到严格大于key的最小数
{
    if(!p)  return INF;
    if(tr[p].key <= key)    return get_next(tr[p].r, key);
    return min(tr[p].key, get_next(tr[p].l, key));
}

int main()
{
    build();
    cin >> n;
    while(n --)
    {
        int op, x;
        cin >> op >> x;
        if(op == 1) insert(root, x);
        else if(op == 2)    remove(root, x);
        else if(op == 3)    cout << get_rank_by_key(root, x) - 1 << endl;
        else if(op == 4)    cout << get_key_by_rank(root, x + 1) << endl;
        else if(op == 5)    cout << get_prev(root, x) << endl;
        else if(op == 6)    cout << get_next(root, x) << endl;
    }
    return 0;
}
```

##### 2.12.2 Splay(伸展树)

###### m 次操作，每次操作选定一个子序列 [l,r]，并将该子序列中的所有数字进行翻转

```cpp
int n, m;
struct Node
{
    int s[2], p, v;
    int size, flag;

    void init(int _v, int _p)
    {
        v = _v, p = _p;
        size = 1;
    }
}tr[N];
int root, idx;

void pushup(int x)
{
    tr[x].size = tr[tr[x].s[0]].size + tr[tr[x].s[1]].size + 1;
}

void pushdown(int x)
{
    if (tr[x].flag)
    {
        swap(tr[x].s[0], tr[x].s[1]);
        tr[tr[x].s[0]].flag ^= 1;
        tr[tr[x].s[1]].flag ^= 1;
        tr[x].flag = 0;
    }
}

void rotate(int x)
{
    int y = tr[x].p, z = tr[y].p;
    int k = tr[y].s[1] == x;  // k=0表示x是y的左儿子；k=1表示x是y的右儿子
    tr[z].s[tr[z].s[1] == y] = x, tr[x].p = z;
    tr[y].s[k] = tr[x].s[k ^ 1], tr[tr[x].s[k ^ 1]].p = y;
    tr[x].s[k ^ 1] = y, tr[y].p = x;
    pushup(y), pushup(x);
}

void splay(int x, int k)
{
    while (tr[x].p != k)
    {
        int y = tr[x].p, z = tr[y].p;
        if (z != k)
            if ((tr[y].s[1] == x) ^ (tr[z].s[1] == y)) rotate(x);
            else rotate(y);
        rotate(x);
    }
    if (!k) root = x;
}

void insert(int v)
{
    int u = root, p = 0;
    while (u) p = u, u = tr[u].s[v > tr[u].v];
    u = ++ idx;
    if (p) tr[p].s[v > tr[p].v] = u;
    tr[u].init(v, p);
    splay(u, 0);
}

int get_k(int k)
{
    int u = root;
    while (true)
    {
        pushdown(u);
        if (tr[tr[u].s[0]].size >= k) u = tr[u].s[0];
        else if (tr[tr[u].s[0]].size + 1 == k) return u;
        else k -= tr[tr[u].s[0]].size + 1, u = tr[u].s[1];
    }
    return -1;
}

void output(int u)
{
    pushdown(u);
    if (tr[u].s[0]) output(tr[u].s[0]);
    if (tr[u].v >= 1 && tr[u].v <= n) printf("%d ", tr[u].v);
    if (tr[u].s[1]) output(tr[u].s[1]);
}

int main()
{
    scanf("%d%d", &n, &m);
    for (int i = 0; i <= n + 1; i ++ ) insert(i);
    while (m -- )
    {
        int l, r;
        scanf("%d%d", &l, &r);
        l = get_k(l), r = get_k(r + 2);
        splay(l, 0), splay(r, l);
        tr[tr[r].s[0]].flag ^= 1;
    }
    output(root);
    return 0;
}
```

#### 2.13  AC自动机

```cpp
/给定n个单词，长度为m的文章，求有多少个单词在文章中出现了
int n;
int tr[N * S][26], cnt[N * S], idx;
char str[M];
int q[N * S], ne[N * S];

void insert()
{
    int p = 0;
    for (int i = 0; str[i]; i ++ )
    {
        int t = str[i] - 'a';
        if (!tr[p][t]) tr[p][t] = ++ idx;
        p = tr[p][t];
    }
    cnt[p] ++ ;
}

void build()
{
    int hh = 0, tt = -1;
    for (int i = 0; i < 26; i ++ )
        if (tr[0][i])
            q[ ++ tt] = tr[0][i];

    while (hh <= tt)
    {
        int t = q[hh ++ ];
        for (int i = 0; i < 26; i ++ )
        {
            int p = tr[t][i];
            if (!p) tr[t][i] = tr[ne[t]][i];
            else
            {
                ne[p] = tr[ne[t]][i];
                q[ ++ tt] = p;
            }
        }
    }
}

int main()
{
    int T;
    scanf("%d", &T);
    while (T -- )
    {
        memset(tr, 0, sizeof tr);
        memset(cnt, 0, sizeof cnt);
        memset(ne, 0, sizeof ne);
        idx = 0;

        scanf("%d", &n);
        for (int i = 0; i < n; i ++ )
        {
            scanf("%s", str);
            insert();
        }

        build();

        scanf("%s", str);

        int res = 0;
        for (int i = 0, j = 0; str[i]; i ++ )
        {
            int t = str[i] - 'a';
            j = tr[j][t];

            int p = j;
            while (p)
            {
                res += cnt[p];
                cnt[p] = 0;
                p = ne[p];
            }
        }

        printf("%d\n", res);
    }

    return 0;
}
```

#### 2.14 分块与莫队

##### 2.14.1 分块解决区间修改，区间查询

```cpp
LL a[N], sum[N], add[N];
int L[N], R[N];
int pos[N];
int n, m, t;

void modify(int l, int r, LL d)
{
    int p = pos[l], q = pos[r];
    if(p == q)
    {
        for(int i = l; i <= r; i ++)
            a[i] += d;
        sum[p] += d * (r - l + 1);
    }
    else
    {
        for(int i = p + 1; i <= q - 1; i ++)
            add[i] += d;

        for(int i = l; i <= R[p]; i ++)
            a[i] += d;

        sum[p] += d * (R[p] - l + 1);
        for(int i = L[q]; i <= r; i ++)
            a[i] += d;

        sum[q] += d * (r - L[q] + 1);
    }
}

LL query(int l, int r)
{
    int p = pos[l], q = pos[r];
    LL ans = 0;
    if(p == q)
    {
        for(int i = l; i <= r; i ++)
            ans += a[i];

        ans += add[p] * (r - l + 1);
    }
    else
    {
        for(int i = p + 1; i <= q - 1; i ++)
            ans += sum[i] + add[i] * (R[i] - L[i] + 1);

        for(int i = l; i <= R[p]; i ++)
            ans += a[i];

        ans += add[p] * (R[p] - l + 1);

        for(int i = L[q]; i <= r; i ++)
            ans += a[i];

        ans += add[q] * (r - L[q] + 1);
    }

    return ans;
}

int main()
{
    cin >> n >> m;
    for(int i = 1; i <= n; i ++)
        cin >> a[i];

    //分块
    t = sqrt(n);
    for(int i = 1; i <= t; i ++)
    {
        L[i] = (i - 1) * sqrt(n) + 1;
        R[i] = i * sqrt(n);
    }

    if(R[t] < n)
    {
        t ++;
        L[t] = R[t - 1] + 1;
        R[t] = n;
    }

    for(int i = 1; i <= t; i ++)
    {
        for(int j = L[i]; j <= R[i]; j ++)
        {
            pos[j] = i;
            sum[i] += a[j];
        }
    }

    while(m --)
    {
        char op[3];
        int l, r, d;
        cin >> op >> l >> r;
        if(op[0] == 'C')
        {
            cin >> d;
            modify(l, r, d);
        }
        else    cout << query(l, r) << endl;
    }

    return 0;
}
```

##### 2.14.2 分块-块状链表

```cpp
//待补充
```

##### 2.14.3 基础莫队

###### 求一段区间内有多少个不同的数

```cpp
int n, m, len;
int w[N], ans[M];
struct Query{
    int id, l, r;
}q[M];
int cnt[S];

int get(int x)      //求块的编号
{
    return x / len;
}

bool cmp(const Query& a, const Query& b)
{
    int i = get(a.l), j = get(b.l);
    if(i != j)  return i < j;
    return a.r < b.r;
}

void add(int x, int& res)
{
    if(!cnt[x]) res ++;
    cnt[x] ++;
}

void del(int x, int & res)
{
    cnt[x] --;
    if(!cnt[x]) res --;
}

int main()
{
    cin >> n;
    for(int i = 1; i <= n; i ++)
        cin >> w[i];
    cin >> m;
    len = max(1, (int)sqrt((double)n * n / m));
    for(int i = 0; i < m; i ++)
    {
        int l, r;
        cin >> l >> r;
        q[i] = {i, l, r};
    }

    sort(q, q + m, cmp);

    for(int k = 0, i = 0, j = 1, res = 0; k < m; k ++)  //处理所有询问
    {
        int id = q[k].id, l = q[k].l, r = q[k].r;   //区间的编号，区间左右端点
        while(i < r)    add(w[ ++ i], res);     //当前区间加一个数
        while(i > r)    del(w[i --], res);
        while(j < l)    del(w[j ++], res);
        while(j > l)    add(w[-- j], res);
        ans[id] = res;
    }

    for(int i = 0; i < m; i ++)
        cout << ans[i] << endl;

    return 0;
}
```

#### 2.15 点分治

###### 求树上边权长度不超过K的路径有多少条

```cpp
int n, m;
int h[N], e[M], w[M], ne[M], idx;
bool st[N];     //表示点是否被删掉
int p[N], q[N];

void add(int a, int b, int c)
{
    e[idx] = b;
    w[idx] = c;
    ne[idx] = h[a];
    h[a] = idx ++;
}

int get_size(int u, int fa)     //求子树大小
{
    if(st[u])   return 0;
    int res = 1;
    for(int i = h[u]; ~i; i = ne[i])
    {
        int j = e[i];
        if(j != fa)
            res += get_size(j, u);
    }

    return res;
}

int get_wc(int u, int fa, int tot, int& wc) //求树的重心
{
    if(st[u])   return 0;
    int sum = 1, ms = 0;
    for(int i = h[u]; ~i; i = ne[i])
    {
        int j = e[i];
        if(j == fa) continue;
        int t = get_wc(j, u, tot, wc);
        ms = max(ms, t);
        sum += t;
    }
    ms = max(ms, tot - sum);
    if(ms <= tot / 2)   wc = u;
    return sum;
}

void get_dist(int u, int fa, int dist, int& qt)
{
    if(st[u])   return ;
    q[qt ++] = dist;
    for(int i = h[u]; ~i; i = ne[i])
        if(e[i] != fa)
            get_dist(e[i], u, dist + w[i], qt);
}

int get(int a[], int k)
{
    sort(a, a + k);
    int res = 0;
    for(int i = k - 1, j = -1; i >= 0; i --)
    {
        while(j + 1 < i && a[j + 1] + a[i] <= m)    j ++;
        j = min(j, i - 1);
        res += j + 1;
    }

    return res;
}

int calc(int u)
{
    if(st[u])   return 0;
    int res = 0;
    get_wc(u, -1, get_size(u, -1), u);
    st[u] = true;

    int pt = 0;
    for(int i = h[u]; ~i; i = ne[i])
    {
        int j = e[i], qt = 0;
        get_dist(j, -1, w[i], qt);
        res -= get(q, qt);
        for(int k = 0; k < qt; k ++)
        {
            if(q[k] <= m)   res ++;
            p[pt ++] = q[k];
        }
    }
    res += get(p, pt);

    for(int i = h[u]; ~i; i = ne[i])
    {
        res += calc(e[i]);
    }

    return res;
}

int main()
{
    while(cin >> n >> m && n, m)
    {
        memset(st, 0, sizeof st);
        idx = 0;
        memset(h, -1, sizeof h);
        for(int i = 0; i < n - 1; i ++)
        {
            int a, b, c;
            cin >> a >> b >> c;
            add(a, b, c);
            add(b, a, c);
        }

        cout << calc(0) << endl;
    }
    return 0;
}
```

#### 2.16 树套树(线段树套平衡树)

###### 树套树用于维护一个长度为n的数列，支持以下操作

1. `1 l r x`，查询整数 x 在区间 [l,r] 内的排名。

2. `2 l r k`，查询区间 [l,r] 内排名为 k 的值。

3. `3 pos x`，将 pos 位置的数修改为 x。

4. `4 l r x`，查询整数 x 在区间 [l,r] 内的前驱(前驱定义为小于 x，且最大的数)。

5. `5 l r x`，查询整数 x 在区间 [l,r] 内的后继(后继定义为大于 x，且最小的数)。的数)。
   
   ```cpp
   #include <cstdio>
   #include <cstring>
   #include <iostream>
   #include <algorithm>
   
   using namespace std;
   
   const int N = 2000010, INF = 1e9;
   
   int n, m;
   struct Node
   {
       int s[2], p, v;
       int size;
   
       void init(int _v, int _p)
       {
           v = _v, p = _p;
           size = 1;
       }
   }tr[N];
   int L[N], R[N], T[N], idx;
   int w[N];
   
   void pushup(int x)
   {
       tr[x].size = tr[tr[x].s[0]].size + tr[tr[x].s[1]].size + 1;
   }
   
   void rotate(int x)
   {
       int y = tr[x].p, z = tr[y].p;
       int k = tr[y].s[1] == x;
       tr[z].s[tr[z].s[1] == y] = x, tr[x].p = z;
       tr[y].s[k] = tr[x].s[k ^ 1], tr[tr[x].s[k ^ 1]].p = y;
       tr[x].s[k ^ 1] = y, tr[y].p = x;
       pushup(y), pushup(x);
   }
   
   void splay(int& root, int x, int k)
   {
       while (tr[x].p != k)
       {
           int y = tr[x].p, z = tr[y].p;
           if (z != k)
               if ((tr[y].s[1] == x) ^ (tr[z].s[1] == y)) rotate(x);
               else rotate(y);
           rotate(x);
       }
       if (!k) root = x;
   }
   
   void insert(int& root, int v)
   {
       int u = root, p = 0;
       while (u) p = u, u = tr[u].s[v > tr[u].v];
       u = ++ idx;
       if (p) tr[p].s[v > tr[p].v] = u;
       tr[u].init(v, p);
       splay(root, u, 0);
   }
   
   int get_k(int root, int v)
   {
       int u = root, res = 0;
       while (u)
       {
           if (tr[u].v < v) res += tr[tr[u].s[0]].size + 1, u = tr[u].s[1];
           else u = tr[u].s[0];
       }
       return res;
   }
   
   void update(int& root, int x, int y)
   {
       int u = root;
       while (u)
       {
           if (tr[u].v == x) break;
           if (tr[u].v < x) u = tr[u].s[1];
           else u = tr[u].s[0];
       }
       splay(root, u, 0);
       int l = tr[u].s[0], r = tr[u].s[1];
       while (tr[l].s[1]) l = tr[l].s[1];
       while (tr[r].s[0]) r = tr[r].s[0];
       splay(root, l, 0), splay(root, r, l);
       tr[r].s[0] = 0;
       pushup(r), pushup(l);
       insert(root, y);
   }
   
   void build(int u, int l, int r)
   {
       L[u] = l, R[u] = r;
       insert(T[u], -INF), insert(T[u], INF);
       for (int i = l; i <= r; i ++ ) insert(T[u], w[i]);
       if (l == r) return;
       int mid = l + r >> 1;
       build(u << 1, l, mid), build(u << 1 | 1, mid + 1, r);
   }
   
   int query(int u, int a, int b, int x)
   {
       if (L[u] >= a && R[u] <= b) return get_k(T[u], x) - 1;
       int mid = L[u] + R[u] >> 1, res = 0;
       if (a <= mid) res += query(u << 1, a, b, x);
       if (b > mid) res += query(u << 1 | 1, a, b, x);
       return res;
   }
   
   void change(int u, int p, int x)
   {
       update(T[u], w[p], x);
       if (L[u] == R[u]) return;
       int mid = L[u] + R[u] >> 1;
       if (p <= mid) change(u << 1, p, x);
       else change(u << 1 | 1, p, x);
   }
   
   int get_pre(int root, int v)
   {
       int u = root, res = -INF;
       while (u)
       {
           if (tr[u].v < v) res = max(res, tr[u].v), u = tr[u].s[1];
           else u = tr[u].s[0];
       }
       return res;
   }
   
   int get_suc(int root, int v)
   {
       int u = root, res = INF;
       while (u)
       {
           if (tr[u].v > v) res = min(res, tr[u].v), u = tr[u].s[0];
           else u = tr[u].s[1];
       }
       return res;
   }
   
   int query_pre(int u, int a, int b, int x)
   {
       if (L[u] >= a && R[u] <= b) return get_pre(T[u], x);
       int mid = L[u] + R[u] >> 1, res = -INF;
       if (a <= mid) res = max(res, query_pre(u << 1, a, b, x));
       if (b > mid) res = max(res, query_pre(u << 1 | 1, a, b, x));
       return res;
   }
   
   int query_suc(int u, int a, int b, int x)
   {
       if (L[u] >= a && R[u] <= b) return get_suc(T[u], x);
       int mid = L[u] + R[u] >> 1, res = INF;
       if (a <= mid) res = min(res, query_suc(u << 1, a, b, x));
       if (b > mid) res = min(res, query_suc(u << 1 | 1, a, b, x));
       return res;
   }
   
   int main()
   {
       scanf("%d%d", &n, &m);
       for (int i = 1; i <= n; i ++ ) scanf("%d", &w[i]);
       build(1, 1, n);
   
       while (m -- )
       {
           int op, a, b, x;
           scanf("%d", &op);
           if (op == 1)
           {
               scanf("%d%d%d", &a, &b, &x);
               printf("%d\n", query(1, a, b, x) + 1);
           }
           else if (op == 2)
           {
               scanf("%d%d%d", &a, &b, &x);
               int l = 0, r = 1e8;
               while (l < r)
               {
                   int mid = l + r + 1 >> 1;
                   if (query(1, a, b, mid) + 1 <= x) l = mid;
                   else r = mid - 1;
               }
               printf("%d\n", r);
           }
           else if (op == 3)
           {
               scanf("%d%d", &a, &x);
               change(1, a, x);
               w[a] = x;
           }
           else if (op == 4)
           {
               scanf("%d%d%d", &a, &b, &x);
               printf("%d\n", query_pre(1, a, b, x));
           }
           else
           {
               scanf("%d%d%d", &a, &b, &x);
               printf("%d\n", query_suc(1, a, b, x));
           }
       }
   
       return 0;
   }
   ```

###### 树套树动态维护区间第k大数

```cpp
#include <iostream>
#include <cstring>
#include <cstdio>
#include <algorithm>
#include <vector>

using namespace std;

const int N = 50010, P = N * 17 * 17, M = N * 4;

int n, m;
struct Tree
{
    int l, r, sum, add;
}tr[P];
int L[M], R[M], T[M], idx;
struct Query
{
    int op, a, b, c;
}q[N];
vector<int> nums;

int get(int x)
{
    return lower_bound(nums.begin(), nums.end(), x) - nums.begin();
}

void build(int u, int l, int r)
{
    L[u] = l, R[u] = r, T[u] = ++ idx;
    if (l == r) return;
    int mid = l + r >> 1;
    build(u << 1, l, mid), build(u << 1 | 1, mid + 1, r);
}

int intersection(int a, int b, int c, int d)
{
    return min(b, d) - max(a, c) + 1;
}

void update(int u, int l, int r, int pl, int pr)
{
    tr[u].sum += intersection(l, r, pl, pr);
    if (l >= pl && r <= pr)
    {
        tr[u].add ++ ;
        return;
    }
    int mid = l + r >> 1;
    if (pl <= mid)
    {
        if (!tr[u].l) tr[u].l = ++ idx;
        update(tr[u].l, l, mid, pl, pr);
    }
    if (pr > mid)
    {
        if (!tr[u].r) tr[u].r = ++ idx;
        update(tr[u].r, mid + 1, r, pl, pr);
    }
}

void change(int u, int a, int b, int c)
{
    update(T[u], 1, n, a, b);
    if (L[u] == R[u]) return;
    int mid = L[u] + R[u] >> 1;
    if (c <= mid) change(u << 1, a, b, c);
    else change(u << 1 | 1, a, b, c);
}

int get_sum(int u, int l, int r, int pl, int pr, int add)
{
    if (l >= pl && r <= pr) return tr[u].sum + (r - l + 1) * add;
    int mid = l + r >> 1, res = 0;
    add += tr[u].add;
    if (pl <= mid)
    {
        if (tr[u].l) res += get_sum(tr[u].l, l, mid, pl, pr, add);
        else res += intersection(l, mid, pl, pr) * add;
    }
    if (pr > mid)
    {
        if (tr[u].r) res += get_sum(tr[u].r, mid + 1, r, pl, pr, add);
        else res += intersection(mid + 1, r, pl, pr) * add;
    }
    return res;
}

int query(int u, int a, int b, int c)
{
    if (L[u] == R[u]) return R[u];
    int mid = L[u] + R[u] >> 1;
    int k = get_sum(T[u << 1 | 1], 1, n, a, b, 0);
    if (k >= c) return query(u << 1 | 1, a, b, c);
    return query(u << 1, a, b, c - k);
}

int main()
{
    scanf("%d%d", &n, &m);
    for (int i = 0; i < m; i ++ )
    {
        scanf("%d%d%d%d", &q[i].op, &q[i].a, &q[i].b, &q[i].c);
        if (q[i].op == 1) nums.push_back(q[i].c);
    }
    sort(nums.begin(), nums.end());
    nums.erase(unique(nums.begin(), nums.end()), nums.end());
    build(1, 0, nums.size() - 1);

    for (int i = 0; i < m; i ++ )
    {
        int op = q[i].op, a = q[i].a, b = q[i].b, c = q[i].c;
        if (op == 1) change(1, a, b, get(c));
        else printf("%d\n", nums[query(1, a, b, c)]);
    }

    return 0;
}
```

#### 2.17 树链剖分(树上差分plus)

###### 维护一棵树，支持以下操作：

- `1 u v k`，修改路径上节点权值，将节点 u 和节点 v 之间路径上的所有节点（包括这两个节点）的权值增加 k。
- `2 u k`，修改子树上节点权值，将以节点 u 为根的子树上的所有节点的权值增加 k。
- `3 u v`，询问路径，询问节点 u 和节点 v 之间路径上的所有节点（包括这两个节点）的权值和。
- `4 u`，询问子树，询问以节点 u 为根的子树上的所有节点的权值和。

```cpp
#include <iostream>
#include <cstring>
#include <algorithm>

using namespace std;

typedef long long LL;
const int N = 100010, M = N * 2;

int n, m;
int w[N], h[N], e[M], ne[M], idx;
int id[N], nw[N], cnt;
int dep[N], sz[N], top[N], fa[N], son[N];
struct Tree
{
    int l, r;
    LL add, sum;
}tr[N * 4];

void add(int a, int b)
{
    e[idx] = b, ne[idx] = h[a], h[a] = idx ++ ;
}

void dfs1(int u, int father, int depth)
{
    dep[u] = depth, fa[u] = father, sz[u] = 1;
    for (int i = h[u]; ~i; i = ne[i])
    {
        int j = e[i];
        if (j == father) continue;
        dfs1(j, u, depth + 1);
        sz[u] += sz[j];
        if (sz[son[u]] < sz[j]) son[u] = j;
    }
}

void dfs2(int u, int t)
{
    id[u] = ++ cnt, nw[cnt] = w[u], top[u] = t;
    if (!son[u]) return;
    dfs2(son[u], t);
    for (int i = h[u]; ~i; i = ne[i])
    {
        int j = e[i];
        if (j == fa[u] || j == son[u]) continue;
        dfs2(j, j);
    }
}

void pushup(int u)
{
    tr[u].sum = tr[u << 1].sum + tr[u << 1 | 1].sum;
}

void pushdown(int u)
{
    auto &root = tr[u], &left = tr[u << 1], &right = tr[u << 1 | 1];
    if (root.add)
    {
        left.add += root.add, left.sum += root.add * (left.r - left.l + 1);
        right.add += root.add, right.sum += root.add * (right.r - right.l + 1);
        root.add = 0;
    }
}

void build(int u, int l, int r)
{
    tr[u] = {l, r, 0, nw[r]};
    if (l == r) return;
    int mid = l + r >> 1;
    build(u << 1, l, mid), build(u << 1 | 1, mid + 1, r);
    pushup(u);
}

void update(int u, int l, int r, int k)
{
    if (l <= tr[u].l && r >= tr[u].r)
    {
        tr[u].add += k;
        tr[u].sum += k * (tr[u].r - tr[u].l + 1);
        return;
    }
    pushdown(u);
    int mid = tr[u].l + tr[u].r >> 1;
    if (l <= mid) update(u << 1, l, r, k);
    if (r > mid) update(u << 1 | 1, l, r, k);
    pushup(u);
}

LL query(int u, int l, int r)
{
    if (l <= tr[u].l && r >= tr[u].r) return tr[u].sum;
    pushdown(u);
    int mid = tr[u].l + tr[u].r >> 1;
    LL res = 0;
    if (l <= mid) res += query(u << 1, l, r);
    if (r > mid) res += query(u << 1 | 1, l, r);
    return res;
}

void update_path(int u, int v, int k)
{
    while (top[u] != top[v])
    {
        if (dep[top[u]] < dep[top[v]]) swap(u, v);
        update(1, id[top[u]], id[u], k);
        u = fa[top[u]];
    }
    if (dep[u] < dep[v]) swap(u, v);
    update(1, id[v], id[u], k);
}

LL query_path(int u, int v)
{
    LL res = 0;
    while (top[u] != top[v])
    {
        if (dep[top[u]] < dep[top[v]]) swap(u, v);
        res += query(1, id[top[u]], id[u]);
        u = fa[top[u]];
    }
    if (dep[u] < dep[v]) swap(u, v);
    res += query(1, id[v], id[u]);
    return res;
}

void update_tree(int u, int k)
{
    update(1, id[u], id[u] + sz[u] - 1, k);
}

LL query_tree(int u)
{
    return query(1, id[u], id[u] + sz[u] - 1);
}

int main()
{
    scanf("%d", &n);
    for (int i = 1; i <= n; i ++ ) scanf("%d", &w[i]);
    memset(h, -1, sizeof h);
    for (int i = 0; i < n - 1; i ++ )
    {
        int a, b;
        scanf("%d%d", &a, &b);
        add(a, b), add(b, a);
    }
    dfs1(1, -1, 1);
    dfs2(1, 1);
    build(1, 1, n);

    scanf("%d", &m);
    while (m -- )
    {
        int t, u, v, k;
        scanf("%d%d", &t, &u);
        if (t == 1)
        {
            scanf("%d%d", &v, &k);
            update_path(u, v, k);
        }
        else if (t == 2)
        {
            scanf("%d", &k);
            update_tree(u, k);
        }
        else if (t == 3)
        {
            scanf("%d", &v);
            printf("%lld\n", query_path(u, v));
        }
        else printf("%lld\n", query_tree(u));
    }

    return 0;
}
```

#### 2.18 动态树

###### 维护一棵树，支持以下操作：

- `0 x y`，表示询问点 x 到点 y 之间的路径上的所有点（包括两端点）的权值的异或和。保证 x 和 y 之间存在连通路径。
- `1 x y`，表示在点 x 和点 y 之间增加一条边 (x,y)。注意：**如果两点已经处于连通状态，则无视该操作**。
- `2 x y`，表示删除边 (x,y)。注意：**如果该边不存在，则无视该操作**。
- `3 x w`，表示将点 x 的权值修改为 w。

```cpp
#include <iostream>
#include <cstring>
#include <algorithm>

using namespace std;

const int N = 100010;

int n, m;
struct Node
{
    int s[2], p, v;
    int sum, rev;
}tr[N];
int stk[N];

void pushrev(int x)
{
    swap(tr[x].s[0], tr[x].s[1]);
    tr[x].rev ^= 1;
}

void pushup(int x)
{
    tr[x].sum = tr[tr[x].s[0]].sum ^ tr[x].v ^ tr[tr[x].s[1]].sum;
}

void pushdown(int x)
{
    if (tr[x].rev)
    {
        pushrev(tr[x].s[0]), pushrev(tr[x].s[1]);
        tr[x].rev = 0;
    }
}

bool isroot(int x)
{
    return tr[tr[x].p].s[0] != x && tr[tr[x].p].s[1] != x;
}

void rotate(int x)
{
    int y = tr[x].p, z = tr[y].p;
    int k = tr[y].s[1] == x;
    if (!isroot(y)) tr[z].s[tr[z].s[1] == y] = x;
    tr[x].p = z;
    tr[y].s[k] = tr[x].s[k ^ 1], tr[tr[x].s[k ^ 1]].p = y;
    tr[x].s[k ^ 1] = y, tr[y].p = x;
    pushup(y), pushup(x);
}

void splay(int x)
{
    int top = 0, r = x;
    stk[ ++ top] = r;
    while (!isroot(r)) stk[ ++ top] = r = tr[r].p;
    while (top) pushdown(stk[top -- ]);
    while (!isroot(x))
    {
        int y = tr[x].p, z = tr[y].p;
        if (!isroot(y))
            if ((tr[y].s[1] == x) ^ (tr[z].s[1] == y)) rotate(x);
            else rotate(y);
        rotate(x);
    }
}

void access(int x)  // 建立一条从根到x的路径，同时将x变成splay的根节点
{
    int z = x;
    for (int y = 0; x; y = x, x = tr[x].p)
    {
        splay(x);
        tr[x].s[1] = y, pushup(x);
    }
    splay(z);
}

void makeroot(int x)  // 将x变成原树的根节点
{
    access(x);
    pushrev(x);
}

int findroot(int x)  // 找到x所在原树的根节点, 再将原树的根节点旋转到splay的根节点
{
    access(x);
    while (tr[x].s[0]) pushdown(x), x = tr[x].s[0];
    splay(x);
    return x;
}

void split(int x, int y)  // 给x和y之间的路径建立一个splay，其根节点是y
{
    makeroot(x);
    access(y);
}

void link(int x, int y)  // 如果x和y不连通，则加入一条x和y之间的边
{
    makeroot(x);
    if (findroot(y) != x) tr[x].p = y;
}

void cut(int x, int y)  // 如果x和y之间存在边，则删除该边
{
    makeroot(x);
    if (findroot(y) == x && tr[y].p == x && !tr[y].s[0])
    {
        tr[x].s[1] = tr[y].p = 0;
        pushup(x);
    }
}

int main()
{
    scanf("%d%d", &n, &m);
    for (int i = 1; i <= n; i ++ ) scanf("%d", &tr[i].v);
    while (m -- )
    {
        int t, x, y;
        scanf("%d%d%d", &t, &x, &y);
        if (t == 0)
        {
            split(x, y);
            printf("%d\n", tr[y].sum);
        }
        else if (t == 1) link(x, y);
        else if (t == 2) cut(x, y);
        else
        {
            splay(x);
            tr[x].v = y;
            pushup(x);
        }
    }

    return 0;
}
```

#### 2.19 Dancing Links(DLX)

###### 2.19.1 精确覆盖问题

    给定一个01矩阵A，找到一个行的集合，使得这些行中，每一列有且仅有一个数字1

```cpp
#include <iostream>
#include <cstring>
#include <algorithm>

using namespace std;

const int N = 5510;

int n, m;
int l[N], r[N], u[N], d[N], s[N], row[N], col[N], idx;
int ans[N], top;

void init()
{
    for (int i = 0; i <= m; i ++ )
    {
        l[i] = i - 1, r[i] = i + 1;
        u[i] = d[i] = i;
    }
    l[0] = m, r[m] = 0;
    idx = m + 1;
}

void add(int& hh, int& tt, int x, int y)
{
    row[idx] = x, col[idx] = y, s[y] ++ ;
    u[idx] = y, d[idx] = d[y], u[d[y]] = idx, d[y] = idx;
    r[hh] = l[tt] = idx, r[idx] = tt, l[idx] = hh;
    tt = idx ++ ;
}

void remove(int p)
{
    r[l[p]] = r[p], l[r[p]] = l[p];
    for (int i = d[p]; i != p; i = d[i])
        for (int j = r[i]; j != i; j = r[j])
        {
            s[col[j]] -- ;
            u[d[j]] = u[j], d[u[j]] = d[j];
        }
}

void resume(int p)
{
    for (int i = u[p]; i != p; i = u[i])
        for (int j = l[i]; j != i; j = l[j])
        {
            u[d[j]] = j, d[u[j]] = j;
            s[col[j]] ++ ;
        }
    r[l[p]] = p, l[r[p]] = p;
}

bool dfs()
{
    if (!r[0]) return true;
    int p = r[0];
    for (int i = r[0]; i; i = r[i])
        if (s[i] < s[p])
            p = i;
    remove(p);
    for (int i = d[p]; i != p; i = d[i])
    {
        ans[ ++ top] = row[i];
        for (int j = r[i]; j != i; j = r[j]) remove(col[j]);
        if (dfs()) return true;
        for (int j = l[i]; j != i; j = l[j]) resume(col[j]);
        top -- ;
    }
    resume(p);
    return false;
}

int main()
{
    scanf("%d%d", &n, &m);
    init();
    for (int i = 1; i <= n; i ++ )
    {
        int hh = idx, tt = idx;
        for (int j = 1; j <= m; j ++ )
        {
            int x;
            scanf("%d", &x);
            if (x) add(hh, tt, i, j);
        }
    }

    if (dfs())
    {
        for (int i = 1; i <= top; i ++ ) printf("%d ", ans[i]);
        puts("");
    }
    else puts("No Solution!");

    return 0;
}
```

填写16*16的数独

```cpp
#include <iostream>
#include <cstring>
#include <algorithm>

using namespace std;

const int N = 20000;

int m = 16 * 16 * 4;
int u[N], d[N], l[N], r[N], s[N], col[N], row[N], idx;
int ans[N], top;
struct Op
{
    int x, y;
    char z;
}op[N];
char g[20][20];

void init()
{
    for (int i = 0; i <= m; i ++ )
    {
        l[i] = i - 1, r[i] = i + 1;
        s[i] = 0;
        d[i] = u[i] = i;
    }
    l[0] = m, r[m] = 0;
    idx = m + 1;
}

void add(int& hh, int& tt, int x, int y)
{
    row[idx] = x, col[idx] = y, s[y] ++ ;
    u[idx] = y, d[idx] = d[y], u[d[y]] = idx, d[y] = idx;
    r[hh] = l[tt] = idx, r[idx] = tt, l[idx] = hh;
    tt = idx ++ ;
}

void remove(int p)
{
    r[l[p]] = r[p], l[r[p]] = l[p];
    for (int i = d[p]; i != p; i = d[i])
        for (int j = r[i]; j != i; j = r[j])
        {
            s[col[j]] -- ;
            u[d[j]] = u[j], d[u[j]] = d[j];
        }
}

void resume(int p)
{
    for (int i = u[p]; i != p; i = u[i])
        for (int j = l[i]; j != i; j = l[j])
        {
            u[d[j]] = j, d[u[j]] = j;
            s[col[j]] ++ ;
        }
    r[l[p]] = p, l[r[p]] = p;
}

bool dfs()
{
    if (!r[0]) return true;
    int p = r[0];
    for (int i = r[0]; i; i = r[i])
        if (s[i] < s[p])
            p = i;
    remove(p);
    for (int i = d[p]; i != p; i = d[i])
    {
        ans[ ++ top] = row[i];
        for (int j = r[i]; j != i; j = r[j]) remove(col[j]);
        if (dfs()) return true;
        for (int j = l[i]; j != i; j = l[j]) resume(col[j]);
        top -- ;
    }
    resume(p);
    return false;
}

int main()
{
    while (~scanf("%s", g[0]))
    {
        for (int i = 1; i < 16; i ++ ) scanf("%s", g[i]);
        init();

        for (int i = 0, n = 1; i < 16; i ++ )
            for (int j = 0; j < 16; j ++ )
            {
                int a = 0, b = 15;
                if (g[i][j] != '-') a = b = g[i][j] - 'A';
                for (int k = a; k <= b; k ++, n ++ )
                {
                    int hh = idx, tt = idx;
                    op[n] = {i, j, k + 'A'};
                    add(hh, tt, n, i * 16 + j + 1);
                    add(hh, tt, n, 256 + i * 16 + k + 1);
                    add(hh, tt, n, 256 * 2 + j * 16 + k + 1);
                    add(hh, tt, n, 256 * 3 + (i / 4 * 4 + j / 4) * 16 + k + 1);
                }
            }

        dfs();
        for (int i = 1; i <= top; i ++ )
        {
            auto t = op[ans[i]];
            g[t.x][t.y] = t.z;
        }

        for (int i = 0; i < 16; i ++ ) puts(g[i]);
        puts("");
    }

    return 0;
}
```

###### 2.19.2 重复覆盖问题

给定一个01矩阵A，找到一个行的集合，使得这些行中，每一列都包含数字1，且集合中包含的行数尽可能少。

```cpp
#include <iostream>
#include <cstring>
#include <algorithm>

using namespace std;

const int N = 10010;

int n, m;
int l[N], r[N], u[N], d[N], col[N], row[N], s[N], idx;
int ans[N];
bool st[110];

void init()
{
    for (int i = 0; i <= m; i ++ )
    {
        l[i] = i - 1, r[i] = i + 1;
        col[i] = u[i] = d[i] = i;
        s[i] = 0;
    }
    l[0] = m, r[m] = 0;
    idx = m + 1;
}

void add(int& hh, int& tt, int x, int y)
{
    row[idx] = x, col[idx] = y, s[y] ++ ;
    u[idx] = y, d[idx] = d[y], u[d[y]] = idx, d[y] = idx;
    r[hh] = l[tt] = idx, r[idx] = tt, l[idx] = hh;
    tt = idx ++ ;
}

int h()
{
    int cnt = 0;
    memset(st, 0, sizeof st);
    for (int i = r[0]; i; i = r[i])
    {
        if (st[col[i]]) continue;
        cnt ++ ;
        st[col[i]] = true;
        for (int j = d[i]; j != i; j = d[j])
            for (int k = r[j]; k != j; k = r[k])
                st[col[k]] = true;
    }
    return cnt;
}

void remove(int p)
{
    for (int i = d[p]; i != p; i = d[i])
    {
        r[l[i]] = r[i];
        l[r[i]] = l[i];
    }
}

void resume(int p)
{
    for (int i = u[p]; i != p; i = u[i])
    {
        r[l[i]] = i;
        l[r[i]] = i;
    }
}

bool dfs(int k, int depth)
{
    if (k + h() > depth) return false;
    if (!r[0]) return true;
    int p = r[0];
    for (int i = r[0]; i; i = r[i])
        if (s[p] > s[i])
            p = i;

    for (int i = d[p]; i != p; i = d[i])
    {
        ans[k] = row[i];
        remove(i);
        for (int j = r[i]; j != i; j = r[j]) remove(j);
        if (dfs(k + 1, depth)) return true;
        for (int j = l[i]; j != i; j = l[j]) resume(j);
        resume(i);
    }
    return false;
}

int main()
{
    scanf("%d%d", &n, &m);
    init();
    for (int i = 1; i <= n; i ++ )
    {
        int hh = idx, tt = idx;
        for (int j = 1; j <= m; j ++ )
        {
            int x;
            scanf("%d", &x);
            if (x) add(hh, tt, i, j);
        }
    }

    int depth = 0;
    while (!dfs(0, depth)) depth ++ ;
    printf("%d\n", depth);
    for (int i = 0; i < depth; i ++ ) printf("%d ", ans[i]);
    return 0;
}
```

#### 2.20 左偏树

###### 维护一个小根堆，支持以下操作：

1. `1 a`，在集合中插入一个新堆，堆中只包含一个数 a。
2. `2 x y`，将第 x 个插入的数和第 y 个插入的数所在的小根堆合并。数据保证两个数均未被删除。若两数已在同一堆中，则忽略此操作。
3. `3 x`，输出第 x 个插入的数所在小根堆的最小值。数据保证该数未被删除。
4. `4 x`，删除第 x 个插入的数所在小根堆的最小值（若最小值不唯一，则优先删除先插入的数）。数据保证该数未被删除。

```cpp
#include <iostream>
#include <cstring>
#include <algorithm>

using namespace std;

const int N = 200010;

int n;
int v[N], dist[N], l[N], r[N], idx;
int p[N];

bool cmp(int x, int y)
{
    if (v[x] != v[y]) return v[x] < v[y];
    return x < y;
}

int find(int x)
{
    if (p[x] != x) p[x] = find(p[x]);
    return p[x];
}

int merge(int x, int y)
{
    if (!x || !y) return x + y;
    if (cmp(y, x)) swap(x, y);
    r[x] = merge(r[x], y);
    if (dist[r[x]] > dist[l[x]]) swap(l[x], r[x]);
    dist[x] = dist[r[x]] + 1;
    return x;
}

int main()
{
    scanf("%d", &n);
    v[0] = 2e9;
    while (n -- )
    {
        int t, x, y;
        scanf("%d%d", &t, &x);
        if (t == 1)
        {
            v[ ++ idx] = x;
            dist[idx] = 1;
            p[idx] = idx;
        }
        else if (t == 2)
        {
            scanf("%d", &y);
            x = find(x), y = find(y);
            if (x != y)
            {
                if (cmp(y, x)) swap(x, y);
                p[y] = x;
                merge(x, y);
            }
        }
        else if (t == 3)
        {
            printf("%d\n", v[find(x)]);
        }
        else
        {
            x = find(x);
            if (cmp(r[x], l[x])) swap(l[x], r[x]);
            p[x] = l[x], p[l[x]] = l[x];
            merge(l[x], r[x]);
        }
    }

    return 0;
}
```

###### 给定一个整数序列a，求一个递增序列b，使得$a_{i}$和$b_{i}$的各项之差的绝对值之和最小

```cpp
#include <iostream>
#include <cstring>
#include <algorithm>

using namespace std;

typedef long long LL;
const int N = 1000010;

int n;
int v[N], dist[N], l[N], r[N];
struct Segment
{
    int end, root, size;
}stk[N];
int ans[N];

int merge(int x, int y)
{
    if (!x || !y) return x + y;
    if (v[x] < v[y]) swap(x, y);
    r[x] = merge(r[x], y);
    if (dist[r[x]] > dist[l[x]]) swap(r[x], l[x]);
    dist[x] = dist[r[x]] + 1;
    return x;
}

int pop(int x)
{
    return merge(l[x], r[x]);
}

int main()
{
    scanf("%d", &n);
    for (int i = 1; i <= n; i ++ )
    {
        scanf("%d", &v[i]);
        v[i] -= i;
    }
    int tt = 0;
    for (int i = 1; i <= n; i ++ )
    {
        auto cur = Segment({i, i, 1});
        dist[i] = 1;
        while (tt && v[cur.root] < v[stk[tt].root])
        {
            cur.root = merge(cur.root, stk[tt].root);
            if (cur.size % 2 && stk[tt].size % 2)
                cur.root = pop(cur.root);
            cur.size += stk[tt].size;
            tt -- ;
        }
        stk[ ++ tt] = cur;
    }

    for (int i = 1, j = 1; i <= tt; i ++ )
    {
        while (j <= stk[i].end)
            ans[j ++ ] = v[stk[i].root];
    }

    LL res = 0;
    for (int i = 1; i <= n; i ++ ) res += abs(v[i] - ans[i]);
    printf("%lld\n", res);
    for (int i = 1; i <= n; i ++ )
        printf("%d ", ans[i] + i);

    return 0;
}
```

#### 2.21 后缀数组

```cpp
#include <iostream>
#include <cstring>
#include <algorithm>

using namespace std;

const int N = 1000010;

int n, m;
char s[N];
int sa[N], x[N], y[N], c[N], rk[N], height[N];

void get_sa()
{
    for (int i = 1; i <= n; i ++ ) c[x[i] = s[i]] ++ ;
    for (int i = 2; i <= m; i ++ ) c[i] += c[i - 1];
    for (int i = n; i; i -- ) sa[c[x[i]] -- ] = i;
    for (int k = 1; k <= n; k <<= 1)
    {
        int num = 0;
        for (int i = n - k + 1; i <= n; i ++ ) y[ ++ num] = i;
        for (int i = 1; i <= n; i ++ )
            if (sa[i] > k)
                y[ ++ num] = sa[i] - k;
        for (int i = 1; i <= m; i ++ ) c[i] = 0;
        for (int i = 1; i <= n; i ++ ) c[x[i]] ++ ;
        for (int i = 2; i <= m; i ++ ) c[i] += c[i - 1];
        for (int i = n; i; i -- ) sa[c[x[y[i]]] -- ] = y[i], y[i] = 0;
        swap(x, y);
        x[sa[1]] = 1, num = 1;
        for (int i = 2; i <= n; i ++ )
            x[sa[i]] = (y[sa[i]] == y[sa[i - 1]] && y[sa[i] + k] == y[sa[i - 1] + k]) ? num : ++ num;
        if (num == n) break;
        m = num;
    }
}

void get_height()
{
    for (int i = 1; i <= n; i ++ ) rk[sa[i]] = i;
    for (int i = 1, k = 0; i <= n; i ++ )
    {
        if (rk[i] == 1) continue;
        if (k) k -- ;
        int j = sa[rk[i] - 1];
        while (i + k <= n && j + k <= n && s[i + k] == s[j + k]) k ++ ;
        height[rk[i]] = k;
    }
}

int main()
{
    scanf("%s", s + 1);
    n = strlen(s + 1), m = 122;
    get_sa();
    get_height();

    for (int i = 1; i <= n; i ++ ) printf("%d ", sa[i]);
    puts("");
    for (int i = 1; i <= n; i ++ ) printf("%d ", height[i]);
    puts("");
    return 0;
}
```

#### 2.22 后缀自动机

###### 给定一个长度为n的小写字母字符串S，对于所有S的出现次数不为1的子串，设value的值为子串出现的次数×子串的长度，求value的最大值

```cpp
#include <iostream>
#include <cstring>
#include <algorithm>

using namespace std;

typedef long long LL;

const int N = 2000010;

int tot = 1, last = 1;
struct Node
{
    int len, fa;
    int ch[26];
}node[N];
char str[N];
LL f[N], ans;
int h[N], e[N], ne[N], idx;

void extend(int c)
{
    int p = last, np = last = ++ tot;
    f[tot] = 1;
    node[np].len = node[p].len + 1;
    for (; p && !node[p].ch[c]; p = node[p].fa) node[p].ch[c] = np;
    if (!p) node[np].fa = 1;
    else
    {
        int q = node[p].ch[c];
        if (node[q].len == node[p].len + 1) node[np].fa = q;
        else
        {
            int nq = ++ tot;
            node[nq] = node[q], node[nq].len = node[p].len + 1;
            node[q].fa = node[np].fa = nq;
            for (; p && node[p].ch[c] == q; p = node[p].fa) node[p].ch[c] = nq;
        }
    }
}

void add(int a, int b)
{
    e[idx] = b, ne[idx] = h[a], h[a] = idx ++ ;
}

void dfs(int u)
{
    for (int i = h[u]; ~i; i = ne[i])
    {
        dfs(e[i]);
        f[u] += f[e[i]];
    }
    if (f[u] > 1) ans = max(ans, f[u] * node[u].len);
}

int main()
{
    scanf("%s", str);
    for (int i = 0; str[i]; i ++ ) extend(str[i] - 'a');
    memset(h, -1, sizeof h);
    for (int i = 2; i <= tot; i ++ ) add(node[i].fa, i);
    dfs(1);
    printf("%lld\n", ans);

    return 0;
}
```

###### 后缀自动机求最长公共子串

```cpp
#include <iostream>
#include <cstring>
#include <algorithm>

using namespace std;

const int N = 20010;

int n;
int tot = 1, last = 1;
char str[N];
struct Node
{
    int len, fa;
    int ch[26];
}node[N];
int ans[N], now[N];
int h[N], e[N], ne[N], idx;

void extend(int c)
{
    int p = last, np = last = ++ tot;
    node[np].len = node[p].len + 1;
    for (; p && !node[p].ch[c]; p = node[p].fa) node[p].ch[c] = np;
    if (!p) node[np].fa = 1;
    else
    {
        int q = node[p].ch[c];
        if (node[q].len == node[p].len + 1) node[np].fa = q;
        else
        {
            int nq = ++ tot;
            node[nq] = node[q], node[nq].len = node[p].len + 1;
            node[q].fa = node[np].fa = nq;
            for (; p && node[p].ch[c] == q; p = node[p].fa) node[p].ch[c] = nq;
        }
    }
}

void add(int a, int b)
{
    e[idx] = b, ne[idx] = h[a], h[a] = idx ++ ;
}

void dfs(int u)
{
    for (int i = h[u]; ~i; i = ne[i])
    {
        dfs(e[i]);
        now[u] = max(now[u], now[e[i]]);
    }
}

int main()
{
    scanf("%d", &n);
    scanf("%s", str);
    for (int i = 0; str[i]; i ++ ) extend(str[i] - 'a');
    for (int i = 1; i <= tot; i ++ ) ans[i] = node[i].len;
    memset(h, -1, sizeof h);
    for (int i = 2; i <= tot; i ++ ) add(node[i].fa, i);

    for (int i = 0; i < n - 1; i ++ )
    {
        scanf("%s", str);
        memset(now, 0, sizeof now);
        int p = 1, t = 0;
        for (int j = 0; str[j]; j ++ )
        {
            int c = str[j] - 'a';
            while (p > 1 && !node[p].ch[c]) p = node[p].fa, t = node[p].len;
            if (node[p].ch[c]) p = node[p].ch[c], t ++ ;
            now[p] = max(now[p], t);
        }
        dfs(1);
        for (int j = 1; j <= tot; j ++ ) ans[j] = min(ans[j], now[j]);
    }

    int res = 0;
    for (int i = 1; i <= tot; i ++ ) res = max(res, ans[i]);
    printf("%d\n", res);

    return 0;
}
```

#### 2.23 点分树

```
//待补充
```

#### 2.24 CDQ分治

```
//待补充
```

###### CDQ分治求动态逆序对

```cpp
#include <iostream>
#include <cstring>
#include <algorithm>

using namespace std;

typedef long long LL;

const int N = 100010;

int n, m;
struct Data
{
    int a, t, res;
}q[N], w[N];
int tr[N], pos[N];
LL ans[N];

int lowbit(int x)
{
    return x & -x;
}

void add(int x, int v)
{
    for (int i = x; i < N; i += lowbit(i)) tr[i] += v;
}

int query(int x)
{
    int res = 0;
    for (int i = x; i; i -= lowbit(i)) res += tr[i];
    return res;
}

void merge_sort(int l, int r)
{
    if (l >= r) return;
    int mid = l + r >> 1;
    merge_sort(l, mid), merge_sort(mid + 1, r);
    int i = mid, j = r;
    while (i >= l && j > mid)
        if (q[i].a > q[j].a) add(q[i].t, 1), i -- ;
        else q[j].res += query(q[j].t - 1), j -- ;
    while (j > mid) q[j].res += query(q[j].t - 1), j -- ;
    for (int k = i + 1; k <= mid; k ++ ) add(q[k].t, -1);

    j = l, i = mid + 1;
    while (j <= mid && i <= r)
        if (q[i].a < q[j].a) add(q[i].t, 1), i ++ ;
        else q[j].res += query(q[j].t - 1), j ++ ;
    while (j <= mid) q[j].res += query(q[j].t - 1), j ++ ;
    for (int k = mid + 1; k < i; k ++ ) add(q[k].t, -1);

    i = l, j = mid + 1;
    int k = 0;
    while (i <= mid && j <= r)
        if (q[i].a <= q[j].a) w[k ++ ] = q[i ++ ];
        else w[k ++ ] = q[j ++ ];
    while (i <= mid) w[k ++ ] = q[i ++ ];
    while (j <= r) w[k ++ ] = q[j ++ ];

    for (i = l, j = 0; j < k; i ++, j ++ ) q[i] = w[j];
}

int main()
{
    scanf("%d%d", &n, &m);
    for (int i = 0; i < n; i ++ )
    {
        scanf("%d", &q[i].a);
        pos[q[i].a] = i;
    }
    for (int i = 0, j = n; i < m; i ++ )
    {
        int a;
        scanf("%d", &a);
        q[pos[a]].t = j -- ;
        pos[a] = -1;
    }

    for (int i = 1, j = n - m; i <= n; i ++ )
        if (pos[i] != -1)
            q[pos[i]].t = j -- ;

    merge_sort(0, n - 1);

    for (int i = 0; i < n; i ++ ) ans[q[i].t] = q[i].res;
    for (int i = 2; i <= n; i ++ ) ans[i] += ans[i - 1];
    for (int i = 0, j = n; i < m; i ++, j -- ) printf("%lld\n", ans[j]);

    return 0;
}
```

# 3. 数学

#### 3.1 分解质因数

```cpp
#include<iostream>
using  namespace std;


void device(int a)
{
    for(int i = 2; i <= a / i; i ++)
    {
        if(a % i == 0)              //如果该语句成立，那么i一定是质数

            int s = 0;
            while(a % i == 0)
            {
                a /= i;
                s ++;
            } 
            printf("%d %d\n", i, s);
        }

    }
    if(a > 1)   cout << a << " " << 1 <<endl;
    cout  << endl;

}

int main()
{
    int n;
    cin >> n;
    while (n -- )
    {
        int a;
        cin >> a;
        device(a);

    }

    return 0;
}
```

#### 3.2 筛质数

```cpp
#include<iostream>
using namespace std;
const int N = 1e6 + 10;
int prime[N],cnt;
int st[N];

void getprime(int n)
{
    for(int i = 2; i <= n; i ++)
    {
      if(!st[i])    prime[cnt ++] = i;              //如果i是一个质数，那么就把i加入到质数表里
      for(int j = 0; prime[j] <= n / i; j ++)       //枚举质数表中小于n/i的质因子
      {
          st[prime[j] * i] = true;                  //将所有最小质因子为prime[j]的合数筛掉
          if(i % prime[j] == 0) break;              //如果i%prime[j]成立，那么prime[j]是i的最小质因子，并且也是prime[j] * i的最小质因子
          //如果不成立，那么prime[j]也是prime[j] * i的最小质因子
      }
    }
}

int main()
{
    int n;
    cin >> n;

    getprime(n);

    cout << cnt ;
    return 0;
}
```

#### 3.3 试除法求约数

```cpp
#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;

void ddd(int a)
{
    vector<int> res;
    for(int i = 1; i <= a / i; i ++)
    {
        if(a % i == 0)
        {
            res.push_back(i);
            if(i != a / i)  res.push_back(a / i);
        }
    }

    sort(res.begin(), res.end());
    for(auto t : res)
    cout << t  << " ";

    cout << endl;
}

int main()
{
    int n;
    cin >> n;
    while(n --)
    {
        int a;
        cin >> a;
        ddd(a);
    }


    return 0;
}
```

#### 3.4 求n个数乘积的约数个数

```cpp
#include<iostream>
#include<cstring>
#include<algorithm>
#include<unordered_map>
typedef long long LL;
using namespace std;
const int mod = 1e9 + 7;

int main()
{
    int n;
    cin >> n;
    unordered_map<int, int> primes;
    while(n --)
    {
        int x;
        cin >> x;
        for(int i = 2; i <= x / i; i ++)
        {
            while(x % i == 0)
            {
                x /= i;
                primes[i] ++;
            }
        }
        if(x > 1)   primes[x] ++;
    }
    LL res = 1;
    for(auto prime : primes)
        res = res * (prime.second + 1) % mod;

    cout << res << endl;

    return 0;
}
```

#### 3.5 求n个数乘积的约数之和

```cpp
#include<iostream>
#include<cstring>
#include<algorithm>
#include<unordered_map>
typedef long long LL;
using namespace std;
const int mod = 1e9 + 7;

int main()
{
    int n;
    cin >> n;
    unordered_map<int, int> primes;
    while(n --)
    {
        int x;
        cin >> x;
        for(int i = 2; i <= x / i; i ++)
        {
            while(x % i == 0)
            {
                x /= i;
                primes[i] ++;
            }
        }
        if(x > 1)   primes[x] ++;
    }
    LL res = 1;
    for(auto prime : primes)
    {
        int p = prime.first, a = prime.second;
        LL t = 1;
        while(a --)
            t = (t * p + 1) % mod;
        res = res * t % mod;
    }

    cout << res << endl;

    return 0;
}
```

#### 3.6 线性筛求欧拉函数

```cpp
#include<iostream>
#include<cstring>
#include<algorithm>
using namespace std;
typedef long long LL;
const int N = 1e6 + 10;

int primes[N], cnt;
int phi[N];
bool st[N];

LL get_eulers(int n)
{
    phi[1] = 1;
    for(int i = 2; i <= n; i ++)
    {
        if(!st[i])
        {
            primes[cnt ++] = i;
            phi[i] = i - 1;
        }
        for(int j = 0; primes[j] * i <= n; j ++)
        {
            st[primes[j] * i] = true;
            if(i % primes[j] == 0)
            {
                phi[primes[j] * i] = primes[j] * phi[i];
                break;
            }
            phi[primes[j] * i] = phi[i] * (primes[j] - 1);
        }
    }
    LL res = 0;
    for(int i = 1; i <= n; i ++)
        res += phi[i];
    return res;
}

int main()
{
    int n;
    cin >> n;
    cout << get_eulers(n) << endl;

    return 0;
}
```

#### 3.7 快速幂

```cpp
int qmi(int a, int b, int p)
{
    int res = 1 % p;
    for(; b; b >>= 1)
    {
        if(b & 1)    res = (long long)res * a % p;
        a = (long long)a * a % p;
    }
    return res;
}
```

#### 3.8 扩展欧几里得算法(EXGCD)

给定 n 对正整数 $a_i$,$b_i$，对于每对数，求出一组 $xi$ , $y_i$，使其满足 $a_i$×$x_i$+$b_i$×$y_i$=gcd($a_i$,$b_i$)。

```cpp
#include<iostream>
#include<cstring>
#include<algorithm>
using namespace std;

int exgcd(int a, int b, int &x, int &y)
{
    if(!b)
    {
        x = 1, y = 0;
        return a;
    }
    int d = exgcd(b, a % b, y, x);
    y -= a / b * x;
    return d;
}

int main()
{
    int n;
    cin >> n;

    while(n --)
    {
        int a, b, x, y;
        cin >> a >> b;
        exgcd(a, b, x, y);

        cout << x << " " << y << endl;
    }
    return 0;
}
```

###### 求解线性同余方程组

```cpp
#include<iostream>
#include<cstring>
#include<algorithm>
typedef long long LL;
using namespace std;

int exgcd(int a, int b, int &x, int &y)
{
    if(!b)
    {
        x = 1, y = 0;
        return a;
    }

    int d = exgcd(b, a % b, y, x);
    y -= a / b * x;
    return d;
}

int main()
{
    int n;
    cin >> n;
    while(n --)
    {
        int a, b, m;
        cin >> a >> b >> m;
        int x, y;
        int d = exgcd(a, m, x ,y);
        if(b % d)   cout << "impossible" << endl;
        else
        cout << (LL)x * (b / d) % m << endl;
    }

    return 0;
}
```

#### 3.9 高斯消元求解线性方程组

```cpp
#include<bits/stdc++.h>
using namespace std;
const int N = 110;
const double eps = 1e-6;
int n;
double a[N][N];

int gauss()
{
    int c, r;
    for(c = 0, r = 0; c < n; c ++)
    {
        int t = r;
        for(int i = r; i < n; i ++)
            if(fabs(a[i][c] > fabs(a[t][c])))
                t = i;
        if(fabs(a[t][c]) < eps)   continue;
        for(int i = c; i <= n; i ++)
            swap(a[t][i], a[r][i]);
        for(int i = n; i >= c; i --)
            a[r][i] /= a[r][c];
        for(int i = r + 1; i < n; i ++)
            if(fabs(a[i][c]) > eps)
                for(int j = n; j >= c; j --)
                    a[i][j] -= a[r][j] * a[i][c];
        r ++;
    }

    if(r < n)
    {
        for(int i = r; i < n; i ++)
            if(fabs(a[i][n]) > eps)
                return 2;
        return 1;
    }
    for(int i = n - 1; i >= 0; i --)
        for(int j = i + 1; j < n; j ++)
            a[i][n] -= a[i][j] * a[j][n];
    return 0;
}

int main()
{
    cin >> n;
    for(int i = 0; i < n; i ++)
        for(int j = 0; j < n + 1; j ++)
            cin >> a[i][j];

    int t = gauss();
    if(t == 0)
    {
        for(int i = 0; i < n; i ++)
        {
            if (fabs(a[i][n]) < eps) a[i][n] = 0;
            printf("%.2lf\n", a[i][n]);
        }
    }
    else if(t == 1) cout << "Infinite group solutions" << endl;
    else puts("No solution");
    return 0;
}
```

#### 3.10 组合数大全

###### 3.10.1 求C(a, b)，其中1 ≤ b ≤ a ≤ 2000

```cpp
#include<iostream>
#include<cstring>
#include<algorithm>
using namespace std;
const int N = 2010, mod = 1e9 + 7;

int c[N][N];

void init()
{
    for(int i = 0; i < N; i ++)
        for(int j = 0; j <= i; j ++)
            if(!j)  c[i][j] = 1;
            else c[i][j] = (c[i - 1][j] + c[i - 1][j - 1]) % mod;
}

int main()
{
    init();
    int n;
    cin >> n;
    while(n --)
    {
        int a, b;
        cin >> a >> b;
        cout << c[a][b] << endl;
    }

    return 0;
}
```

###### 3.10.2 求C(a, b)，其中1 ≤ b ≤ a ≤ 100000

```cpp
#include<iostream>
#include<cstring>
#include<algorithm>
using namespace std;
typedef long long LL;
const int N = 100010, mod = 1e9 + 7;

int fact[N], infact[N];

int qmi(int a, int k, int p)
{
    int res = 1;
    for(; k; k >>= 1)
    {
        if(k & 1)   res = (LL)res * a % p;
        a = (LL)a * a % p;
    }

    return res;
}

int main()
{
    fact[0] = infact[0] = 1;
    for(int i = 1; i < N; i ++)
    {
        fact[i] = (LL)fact[i - 1] * i % mod;
        infact[i] = (LL)infact[i - 1] * qmi(i, mod - 2, mod) % mod;
    }

    int n;
    cin >> n;
    while(n --)
    {
        int a, b;
        cin >> a >> b;
        cout << (LL)fact[a] * infact[b] % mod * infact[a - b] % mod << endl;
    }
}
```

###### 3.10.3 求C(a, b) mod p，其中 $1 ≤ b ≤ a ≤ 10^{18}$，且p为质数

```cpp
#include<iostream>
#include<cstring>
#include<algorithm>
using namespace std;
typedef long long LL;
int p;

int qmi(int a, int k)
{
    int res = 1;
    for(; k; k >>= 1)
    {
        if(k & 1)   res = (LL)res * a % p;
        a = (LL)a * a % p;
    }

    return res;
}

int C(LL a, LL b)
{
    int res = 1;
    for(int i = 1, j = a; i <= b; i ++, j --)
    {
        res = (LL)res * j % p;
        res = (LL)res * qmi(i ,p - 2) % p;
    }

    return res;
}

LL lucas(LL a, LL b)
{
    if(a < p & b < p)   return C(a, b);
    return C(a % p, b % p) * lucas(a / p, b / p) % p;
}

int main()
{
    int n;
    cin >> n;
    while(n --)
    {
        LL a, b;
        cin >> a >> b >> p;
        cout << lucas(a, b) << endl;
    }

    return 0;
}
```

###### 3.10.4 求C(a, b)，其中1 ≤ b ≤ a ≤ 5000 (高精度不取模)

```cpp
#include<iostream>
#include<cstring>
#include<algorithm>
#include<vector>
using namespace std;
const int N = 5010;
int primes[N], cnt;
bool st[N];
int sum[N];

void init(int n)
{
    for(int i = 2; i <= n; i ++)
    {
        if(!st[i])  primes[cnt ++] = i;
        for(int j = 0; primes[j] * i <= n; j ++)
        {
            st[primes[j] * i] = true;
            if(i % primes[j] == 0)  break;
        }
    }
}

int get(int n, int p)  //*n的阶乘里包含的p的个数
{
    int res = 0;
    while(n)
    {
        res += n / p;
        n /= p;
    }
    return res;
}

vector<int> mul(vector<int> a, int b)
{
    vector<int> c;
    int t = 0;
    for(int i = 0; i < a.size(); i ++)
    {
        t += a[i] * b;
        c.push_back(t % 10);
        t /= 10;
    }

    while(t)
    {
        c.push_back(t % 10);
        t /= 10;
    }
    return c;
}

int main()
{
    int a, b;
    cin >> a >> b;
    init(a);
    for(int i = 0; i < cnt; i ++)
    {
        int p = primes[i];
        sum[i] = get(a, p) - get(b, p) - get(a - b, p);
    }

    vector<int> res;
    res.push_back(1);

    for(int i = 0; i < cnt; i ++)
        for(int j = 0; j < sum[i]; j ++)
            res = mul(res, primes[i]);

    for(int i = res.size() - 1; i >= 0; i --)
        cout << res[i] ;

    cout << endl;
    return 0;
}
```

###### 3.10.5 卡特兰数

    给定01序列，求任意前缀序列中0的个数不少于1的个数的序列有多少个

```cpp
#include<iostream>
#include<cstring>
#include<algorithm>
typedef long long LL;
using namespace std;
const int mod = 1e9 + 7;

int qmi(int a, int k, int p)
{
    int res = 1;
    for(; k; k >>= 1)
    {
        if(k & 1)   res = (LL)res * a % p;
        a=  (LL)a * a % p;
    }

    return res;
}

int main()
{
    int n;
    cin >> n;
    int a = 2 * n, b = n;
    int res = 1;
    for(int i = a; i > a - b; i --)
        res = (LL)res * i % mod;
    for(int i = 1; i <= b; i ++)
        res = (LL)res * qmi(i, mod - 2, mod) % mod;
    res = (LL)res * qmi(n + 1, mod - 2, mod) % mod;

    cout << res << endl;
    return 0;
}
```

#### 3.11 容斥原理

###### 给定n和m个不同的质数p，求1-n中能被p中至少一个数整除的整数有多少个

```cpp
#include<iostream>
#include<cstring>
#include<algorithm>
using namespace std;
const int N = 20;
typedef long long LL;

int n, m;
int p[N];

int main()
{
    cin >> n >> m;
    for(int i = 0; i < m; i ++)
        cin >> p[i];
    int res = 0;
    for(int i = 1; i < 1 << m; i ++)
    {
        int t = 1, cnt = 0;
        for(int j = 0; j < m; j ++)
            if(i >> j & 1)
            {
                cnt ++;
                if((LL)t * p[j] > n)
                {
                    t = -1;
                    break;
                }
                t *= p[j];
            }
        if(t != -1)
        {
            if(cnt % 2) res += n / t;
            else res -= n / t;
        }
    }
    cout << res << endl;
    return 0;
}
```

###### n个盒子放$a_i$枝花，同一个盒子内的花的颜色相同，不同盒子内的画的颜色不同，选出M枝花共有多少种方案

```cpp
#include<iostream>
#include<cstring>
#include<algorithm>
#include<vector>
#include<cmath>
#include<string>
#define int long long
using namespace std;
const int N = 20, mod = 1e9 + 7;
int A[N];
int down = 1;

int qmi(int a, int b, int k)
{
    int res = 1;
    for(; b; b >>= 1)
    {
        if(b & 1)   res = (long long)res * a % k;
        a = (long long)a * a % k;
    }
    return res;
}

int C(int a, int b)
{
    if(a < b)   return 0;
    int up = 1;
    for(int i = a; i > a - b; i --)
        up = i % mod * up % mod;
    return (up * down) % mod;
}

signed main()
{
    ios::sync_with_stdio(false), cin.tie(nullptr), cout.tie(nullptr);
    int n, m;
    int res = 0;
    cin >> n >> m;
    for(int i = 0; i < n; i ++) cin >> A[i];
    for(int j = 1; j <= n - 1; j ++)
        down = j * down % mod;
    down = qmi(down, mod - 2, mod);

    for(int i = 0; i < 1 << n; i ++)
    {
        int a = m + n - 1, b = n - 1;
        int p = 1;
        for(int j = 0; j < n; j ++)
            if(i >> j & 1)
            {
                p *= -1;
                a -= A[j] + 1;
            }
        res = (res + C(a, b) * p) % mod;
    }

    cout << (res + mod) % mod << endl;
    return 0;
}
```



#### 3.12 博弈论

###### 3.12.1 NIM博弈

给定 n 堆石子，两位玩家轮流操作，每次操作可以从任意一堆石子中拿走任意数量的石子（可以拿完，但不能不拿），最后无法进行操作的人视为失败。

问如果两人都采用最优策略，先手是否必胜。

```cpp
#include<iostream>
#include<cstring>
#include<algorithm>
using namespace std;

int main()
{
    int n;
    int res = 0;
    cin >> n;
    while(n --)
    {
        int x;
        cin >> x;
        res ^= x;
    }

    if(res) cout << "Yes" << endl;
    else
    cout << "No" << endl;
}
```

###### 3.12.2 台阶-NIM游戏

有一个 n 级台阶的楼梯，每级台阶上都有若干个石子，其中第 i 级台阶上有 ai 个石子(i≥1)。

两位玩家轮流操作，每次操作可以从任意一级台阶上拿若干个石子放到下一级台阶中（不能不拿）。

已经拿到地面上的石子不能再拿，最后无法进行操作的人视为失败。

问如果两人都采用最优策略，先手是否必胜。

```cpp
#include <iostream>
#include <algorithm>

using namespace std;

const int N = 100010;

int main()
{
    int n;
    scanf("%d", &n);

    int res = 0;
    for (int i = 1; i <= n; i ++ )
    {
        int x;
        scanf("%d", &x);
        if (i & 1) res ^= x;
    }

    if (res) puts("Yes");
    else puts("No");

    return 0;
}
```

###### 3.12.3 集合-NIM游戏

给定 n 堆石子以及一个由 k 个不同正整数构成的数字集合 S。

现在有两位玩家轮流操作，每次操作可以从任意一堆石子中拿取石子，每次拿取的石子数量必须包含于集合 S，最后无法进行操作的人视为失败。

问如果两人都采用最优策略，先手是否必胜。

```cpp
#include<iostream>
#include<cstring>
#include<algorithm>
#include<unordered_set>
using namespace std;
const int N = 110, M = 10010;
int n, m;
int s[N], f[M];

int sg(int x)
{
    if(f[x] != -1)  return f[x];
    unordered_set<int> S;
    for(int i = 0; i < m; i ++)
    {
        int sum = s[i];
        if(x >= sum)    S.insert(sg(x - sum));
    }
    for(int i = 0; ; i ++)
    {
        if(!S.count(i))
            return f[x] = i;
    }
}

int main()
{
    cin >> m;
    for(int i = 0; i < m; i ++)
        cin >> s[i];
    cin >> n;
    memset(f, -1, sizeof f);
    int res = 0;
    for(int i = 0; i < n; i ++)
    {
        int x;
        cin >> x;
        res ^= sg(x);
    }

    if(res) cout << "Yes" << endl;
    else
    cout << "No" << endl;
    return 0;
}
```

###### 3.12.4 拆分-NIM游戏

给定 n 堆石子，两位玩家轮流操作，每次操作可以取走其中的一堆石子，然后放入两堆**规模更小**的石子（新堆规模可以为 0，且两个新堆的石子总数可以大于取走的那堆石子数），最后无法进行操作的人视为失败。

问如果两人都采用最优策略，先手是否必胜。

```cpp
#include <cstring>
#include <iostream>
#include <algorithm>
#include <unordered_set>

using namespace std;

const int N = 110;


int n;
int f[N];


int sg(int x)
{
    if (f[x] != -1) return f[x];

    unordered_set<int> S;
    for (int i = 0; i < x; i ++ )
        for (int j = 0; j <= i; j ++ )
            S.insert(sg(i) ^ sg(j));

    for (int i = 0;; i ++ )
        if (!S.count(i))
            return f[x] = i;
}


int main()
{
    cin >> n;

    memset(f, -1, sizeof f);

    int res = 0;
    while (n -- )
    {
        int x;
        cin >> x;
        res ^= sg(x);
    }

    if (res) puts("Yes");
    else puts("No");

    return 0;
}
```



#### 3.13 矩阵乘法

###### 求斐波那契数列的前n项和

```cpp
#include<iostream>
#include<cstring>
#include<algorithm>
using namespace std;
const int N = 3;
typedef long long LL;
int n, m;
void mul(int c[], int a[], int b[][N])
{
    int temp[N] = {0};
    for(int i = 0; i < N; i ++)
        for(int j = 0; j < N; j ++)
            temp[i] = (temp[i] + (LL)a[j] * b[j][i]) % m;
    memcpy(c, temp, sizeof temp);
}

void mul(int c[][N], int a[][N], int b[][N])
{
    int temp[N][N] = {0};
    for(int i = 0; i < N; i ++)
        for(int j = 0; j < N; j ++)
            for(int k = 0; k < N; k ++)
                temp[i][j] = (temp[i][j] + (LL)a[i][k] * b[k][j]) % m;
    memcpy(c, temp, sizeof temp);
}

int main()
{
    cin >> n >> m;
    int f1[N] = {1, 1, 1};
    int a[N][N] = {
        {0, 1, 0},
        {1, 1, 1},
        {0, 0, 1}
    };

    n --;
    for(; n; n >>= 1)
    {
        if(n & 1)   mul(f1, f1, a);
        mul(a, a, a);
    }

    cout << f1[2] << endl;
    return 0;
}
```

用 T(n)=(F1+2F2+3F3+…+nFn)modm 表示 Fibonacci 数列前 n 项变形后的和 mod m 的值，求出 T(n) 的值。

```cpp
#include<iostream>
#include<cstring>
#include<algorithm>
using namespace std;
typedef long long LL;
const int N = 4;
int n, m;

void mul(int c[][N], int a[][N], int b[][N])    //*c = a * b
{
    static int t[N][N];
    memset(t, 0, sizeof t);
    for(int i = 0; i < N; i ++)
        for(int j = 0; j < N; j ++)
            for(int k = 0; k < N; k ++)
                t[i][j] = (t[i][j] + (LL)a[i][k] * b[k][j]) % m;
    memcpy(c, t, sizeof t);
}

int main()
{
    cin >> n >> m;
    int f1[N][N] = {1, 1, 1, 0};
    int a[N][N] = {
        {0, 1, 0, 0},
        {1, 1, 1, 0},
        {0, 0, 1, 1},
        {0, 0, 0, 1},
    };

    int k = n - 1;
    for(; k; k >>= 1)
    {
        if(k & 1)   mul(f1, f1, a);
        mul(a, a, a);
    }

    cout << (((LL)n * f1[0][2] - f1[0][3]) % m + m) % m << endl;
    return 0;
}
```



#### 3.14 莫比乌斯函数与莫比乌斯反演与积性函数

```cpp
//待补充
```

# 4. 动态规划

## 数字三角形模型

###  4.1 一条路径点权和最大(摘花生)

```cpp
#include <iostream>
#include <algorithm>

using namespace std;

const int N = 110;

int n, m;
int w[N][N];
int f[N][N];

int main()
{
    int T;
    scanf("%d", &T);
    while (T -- )
    {
        scanf("%d%d", &n, &m);
        for (int i = 1; i <= n; i ++ )
            for (int j = 1; j <= m; j ++ )
                scanf("%d", &w[i][j]);

        for (int i = 1; i <= n; i ++ )
            for (int j = 1; j <= m; j ++ )
                f[i][j] = max(f[i - 1][j], f[i][j - 1]) + w[i][j];

        printf("%d\n", f[n][m]);
    }

    return 0;
}
```

### 4.2 一条路径点权和最小

```cpp
#include <iostream>
#include <algorithm>

using namespace std;

const int N = 110, INF = 1e9;

int n;
int w[N][N];
int f[N][N];

int main()
{
    scanf("%d", &n);

    for (int i = 1; i <= n; i ++ )
        for (int j = 1; j <= n; j ++ )
            scanf("%d", &w[i][j]);

    for (int i = 1; i <= n; i ++ )
        for (int j = 1; j <= n; j ++ )
            if (i == 1 && j == 1) f[i][j] = w[i][j];    // 特判左上角
            else
            {
                f[i][j] = INF;
                if (i > 1) f[i][j] = min(f[i][j], f[i - 1][j] + w[i][j]);// 只有不在第一行的时候，才可以从上面过来
                if (j > 1) f[i][j] = min(f[i][j], f[i][j - 1] + w[i][j]);// 只有不在第一列的时候，才可以从左边过来
            }

    printf("%d\n", f[n][n]);

    return 0;
}
```

### 4.3 两条路径点权和最大

该类问题满足：左上走到右下走两次，格点数被取过第二次就**不会**再取(坐标和相加相等即被走了两次)

```cpp
// 两条路径都是：左上到右下
#include <iostream>
#include <algorithm>

using namespace std;

const int N = 15;

int n;
int w[N][N];
int f[N * 2][N][N];

int main()
{
    scanf("%d", &n);

    int a, b, c;
    while (cin >> a >> b >> c, a || b || c) w[a][b] = c;

    for (int k = 2; k <= n + n; k ++ )
        for (int i1 = 1; i1 <= n; i1 ++ )
            for (int i2 = 1; i2 <= n; i2 ++ )
            {
                int j1 = k - i1, j2 = k - i2;
                if (j1 >= 1 && j1 <= n && j2 >= 1 && j2 <= n)
                {
                    int t = w[i1][j1];
                    if (i1 != i2) t += w[i2][j2];
                    int &x = f[k][i1][i2];
                    x = max(x, f[k - 1][i1 - 1][i2 - 1] + t);
                    x = max(x, f[k - 1][i1 - 1][i2] + t);
                    x = max(x, f[k - 1][i1][i2 - 1] + t);
                    x = max(x, f[k - 1][i1][i2] + t);
                }
            }

    printf("%d\n", f[n + n][n][n]);
    return 0;
}
```



```cpp
// 先左上到右下，再右下到左上
#include <iostream>
#include <cstring>
#include <algorithm>

using namespace std;

const int N = 1e5 + 10;

int n, m;
int g[55][55], f[110][55][55];
int main() {
	cin >> n >> m;
	for(int i = 1;i <= n;i ++)
		for(int j = 1;j <= m;j ++)
			cin >> g[i][j];
	for(int k = 2; k <= n + m;k ++) {
		for(int i1 = max(1, k - m);i1 <= min(k - 1, n);i1 ++) {
			for(int i2 = max(1, k - m);i2 <= min(k - 1, n);i2 ++) {
				int j1 = k - i1, j2 = k - i2;
				int t = g[i1][j1];
				if(i1 != i2) t += g[i2][j2];
				int &x = f[k][i1][i2];
				x = max(x, f[k - 1][i1 - 1][i2 - 1] + t);
				x = max(x, f[k - 1][i1 - 1][i2] + t);
				x = max(x, f[k - 1][i1][i2 - 1] + t);
				x = max(x, f[k - 1][i1][i2] + t);
			}
		}  
	}
	cout << f[n + m][n][n] << endl;
	return 0;
}
```

## 最长上升子序列模型（LIS）

### 4.4 基本转换模型

```cpp
#include <iostream>
#include <algorithm>
#include <cstring>
using namespace std;
const int N = 1e5 + 10;
int n, q[N], a[N];
int ask(int s,int t) {
	q[0] = -2e9;
	int len = 0;
    for(int i = s;i < t;i ++) {
        int l = 0, r = len;
        while(l < r) {
            int mid = l + r + 1 >> 1;
            if(q[mid] < a[i]) l = mid;
            else r = mid - 1;
        }
        len = max(len, r + 1);
        q[r + 1] = a[i];
    }
	return len;
}

int main() {
	int n;
	cin >> n;
	for(int i = 0;i < n;i ++) cin >>  a[i];
	cout << ask(0, n) << endl; // 左闭右开
	return 0;
}

```

### 4.5上下模型

先上升再下降，一旦下降就不再上升，**中间高两边矮**的最长子序列

```cpp
#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;

const int N = 1e3 + 10;
int f[N][2], n, a[N];
int main () {
	cin >> n;
	for(int i = 0;i < n;i ++ ) cin >> a[i];
	
	for(int i = 0;i < n;i ++) {
		f[i][1] = f[i][0] = 1;
		for(int k = 0;k < i;k ++) {
			if(a[i] > a[k]) f[i][0] = max(f[i][0], f[k][0] + 1);
			if(a[i] < a[k]) f[i][1] = max(f[i][1], max(f[k][0], f[k][1]) + 1);
		}
	}
	int res = 0;
	for(int i = 0;i < n;i ++) res = max(res, max(f[i][1], f[i][0]));
	cout << res << endl;
	return 0;
}
```

### 4.6 最大上升子序列和

```cpp
#include <iostream>
#include <cstring>
#include <algorithm>

using namespace std;

const int N = 1010;
int a[N], n, f[N];
int main () {
    cin >> n;
    for(int i = 1;i <= n;i ++) cin >> a[i];
    for(int i = 1;i <= n;i ++) {
        f[i] = a[i];
        for(int k = 1;k < i;k ++) {
            if(a[k] < a[i]) f[i] = max(f[i], f[k] + a[i]);
        }
    }
    int res = 0;
    for(int i = 1;i <= n;i ++) res = max(res, f[i]);
    cout << res << endl;
    return 0;
}
```

### 4.7 Dilworth定理（最少下降子序列数等于最长上升子序列长度）

## 最长公共子序列

### 4.8 最长公共上升子序列（LICS和LCS）

```cpp
#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;
const int N = 3010;

int n, f[N][N], a[N], b[N];
int main () {
	cin >> n;
	for(int i = 1;i <= n;i ++) cin >> a[i];
	for(int i = 1;i <= n;i ++) cin >> b[i];
	for(int i = 1;i <= n;i ++) {
		int res = 0;
		if(b[1] < a[i]) res = f[i - 1][1];
		for(int j = 1;j <= n;j ++) {
			if(a[i] == b[j]) f[i][j] = res + 1;
			else f[i][j] = f[i - 1][j];
			if(b[j] < a[i]) res = max(res, f[i - 1][j]);
		}
	}
	int ans = 0;
	for(int i = 1;i <= n;i ++) ans = max(ans, f[n][i]);
	cout << ans << endl;
	return 0;
}
```

### 4.9 最长公共子序列

````cpp
#include <iostream>
#include <algorithm>
using namespace std;
const int N = 1010;

int n, m;
char a[N], b[N];
int f[N][N];

int main()
{
    scanf("%d%d", &n, &m);
    scanf("%s%s", a + 1, b + 1);
    for (int i = 1; i <= n; i ++ )
        for (int j = 1; j <= m; j ++ ) {
            f[i][j] = max(f[i - 1][j], f[i][j - 1]);
            if (a[i] == b[j]) f[i][j] = max(f[i][j], f[i - 1][j - 1] + 1);
        }
    printf("%d\n", f[n][m]);
    return 0;
}
````

## 4.10 最短编辑距离

A到B最少操作次数

操作：

1. 删除–将字符串 A 中的某个字符删除。
2. 插入–在字符串 A 的某个位置插入某个字符。
3. 替换–将字符串 A 中的某个字符替换为另一个字符。

```cpp
#include <iostream>
#include <algorithm>
#include <cstring>

using namespace std;

int n,m;
char a[1010],b[1010];
int f[1010][1010];
int main()
{
    scanf("%d%s",&n, a + 1);
    scanf("%d%s",&m, b + 1);
    for(int i = 0;i <= m;i ++) f[0][i] = i;
    for(int i = 0;i <= n;i ++) f[i][0] = i;
    for(int i = 1;i <= n;i ++)
    {
        for(int j = 1;j <= m;j ++)
        {
            f[i][j] = min(f[i][j - 1], f[i - 1][j]) + 1;
            if(a[i] != b[j]) f[i][j] = min(f[i][j], f[i - 1][j - 1] + 1);
            else f[i][j] = min(f[i][j], f[i - 1][j - 1]);
        }
    }
    cout << f[n][m] << endl;
    return 0;
}
```

## 背包

### 4.11 01背包问题

```cpp
#include <iostream>
#include <algorithm>

using namespace std;

const int M = 20010;

int n, m;
int f[M];

int main()
{
    cin >> m >> n;
    for (int i = 0; i < n; i ++ )
    {
        int v;
        cin >> v;
        for (int j = m; j >= v; j -- )
            f[j] = max(f[j], f[j - v] + v);
    }

    cout << m - f[m] << endl;

    return 0;
}
```

#### 01背包求方案数

```cpp
//数字组合方案，非最优最大价值方案数
#include <iostream>
#include <algorithm>
using namespace std;
const int N = 10010;

int n, m;
int f[N];
int main()
{
    cin >> n >> m;
    f[0] = 1;
    for (int i = 0; i < n; i ++ )
    {
        int v;
        cin >> v;
        for (int j = m; j >= v; j -- )
            f[j] += f[j - v];
    }
    cout << f[m] << endl;
    return 0;
}
```

### 4.12 完全背包问题

```cpp
#include <iostream>
#include <algorithm>
using namespace std;
const int N = 1010;

int n, m;
int v[N], w[N];
int f[N];

int main()
{
    cin >> n >> m;
    for (int i = 1; i <= n; i ++ ) cin >> v[i] >> w[i];

    for (int i = 1; i <= n; i ++ )
        for (int j = v[i]; j <= m; j ++ )
            f[j] = max(f[j], f[j - v[i]] + w[i]);

    cout << f[m] << endl;

    return 0;
}
```

#### 完全背包求方案数

```	cpp
//数字组合方案，非最优最大价值方案数
#include <iostream>
#include <cstdio>
using namespace std;

typedef long long LL;
const LL mod=2147483648LL;//默认数字为int类型，因此数字后要加LL
int n;
long long f[4005];

int main() {
    scanf("%d",&n);
    f[0]=1;
    for(int i = 1;i < n;i ++)
        for(int j = i;j <= n;j ++)
            f[j] = (f[j] + f[j - i]) % mod;
    printf("%d",f[n]);
}
```

### 4.13 多重背包问题

```cpp
#include <iostream>
#include <cstring>
#include <algorithm>
#include <vector>
using namespace std;
const int N = 1e5+10;

int n, m;
struct node {
	int v, w;
};
vector<node> nodes;
int f[N];
int main() {
	cin >> n >> m;
	for(int i = 1;i <= n;i ++) {
		int v, w ,s;
		cin >> v >> w >> s;
		for(int k = 1;k <= s;k <<= 1) nodes.push_back({v*k, w*k}), s -= k;
		if(s) nodes.push_back({v*s, w*s});
	}
	for(auto t : nodes) {
		for(int j = m;j >= t.v;j -- ) {
			f[j] = max(f[j], f[j - t.v] + t.w);
		}
	}
	cout << f[m] << endl;
	return 0;
}
```

**单调队列优化**

```cpp
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;
const int N = 100010;

int n, m;
int f[N], g[N], q[N];

int main()
{
    cin >> n >> m;
    for (int i = 0; i < n; i ++ )
    {
        int v, w, s;
        cin >> v >> w >> s;
        memcpy(g, f, sizeof f);
        for (int j = 0; j < v; j ++ )
        {
            int hh = 0, tt = -1;
            for (int k = j; k <= m; k += v)
            {
                if (hh <= tt && q[hh] < k - s * v) hh ++ ;
                while (hh <= tt && g[q[tt]] - (q[tt] - j) / v * w <= g[k] - (k - j) / v * w) tt -- ;
                q[ ++ tt] = k;
                f[k] = g[q[hh]] + (k - q[hh]) / v * w;
            }
        }
    }
    cout << f[m] << endl;
    return 0;
}
```

### 4.14 混合背包问题

```cpp
#include <iostream>
using namespace std;
const int N = 1010;

int n, m;
int f[N];
int main()
{
    cin >> n >> m;
    for (int i = 0; i < n; i ++ )
    {
        int v, w, s;
        cin >> v >> w >> s;
        if (!s)
        {
            for (int j = v; j <= m; j ++ )
                f[j] = max(f[j], f[j - v] + w);
        }
        else
        {
            if (s == -1) s = 1;
            for (int k = 1; k <= s; k *= 2)
            {
                for (int j = m; j >= k * v; j -- )
                    f[j] = max(f[j], f[j - k * v] + k * w);
                s -= k;
            }
            if (s)
            {
                for (int j = m; j >= s * v; j -- )
                    f[j] = max(f[j], f[j - s * v] + s * w);
            }
        }
    }
    cout << f[m] << endl;
    return 0;
}
```

### 4.15 二维费用的背包问题

```cpp
#include <iostream>
using namespace std;
const int N = 110;

int n, V, M;
int f[N][N];

int main()
{
    cin >> n >> V >> M;
    for (int i = 0; i < n; i ++ )
    {
        int v, m, w;
        cin >> v >> m >> w;
        for (int j = V; j >= v; j -- )
            for (int k = M; k >= m; k -- )
                f[j][k] = max(f[j][k], f[j - v][k - m] + w);
    }
    cout << f[V][M] << endl;
    return 0;
}
```

### 4.16 分组背包问题

```cpp
#include <iostream>
#include <algorithm>
using namespace std;
const int N = 110;

int n, m;
int v[N][N], w[N][N], s[N];
int f[N];

int main()
{
    cin >> n >> m;
    for (int i = 1; i <= n; i ++ )
    {
        cin >> s[i];
        for (int j = 0; j < s[i]; j ++ )
            cin >> v[i][j] >> w[i][j];
    }
    for (int i = 1; i <= n; i ++ )
        for (int j = m; j >= 0; j -- )
            for (int k = 0; k < s[i]; k ++ )
                if (v[i][k] <= j)
                    f[j] = max(f[j], f[j - v[i][k]] + w[i][k]);
    cout << f[m] << endl;
    return 0;
}
```

### 4.17 有依赖的背包问题

物品之间具有依赖关系，且依赖关系组成一棵树的形状。如果选择一个物品，则必须选择它的父节点。

```cpp
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;
const int N = 110;

int n, m;
int v[N], w[N];
int h[N], e[N], ne[N], idx;
int f[N][N];

void add(int a, int b)
{
    e[idx] = b, ne[idx] = h[a], h[a] = idx ++ ;
}

void dfs(int u)
{
    for (int i = h[u]; ~i; i = ne[i])   // 循环物品组
    {
        int son = e[i];
        dfs(e[i]);

        // 分组背包
        for (int j = m - v[u]; j >= 0; j -- )  // 循环体积
            for (int k = 0; k <= j; k ++ )  // 循环决策
                f[u][j] = max(f[u][j], f[u][j - k] + f[son][k]);
    }

    // 将物品u加进去
    for (int i = m; i >= v[u]; i -- ) f[u][i] = f[u][i - v[u]] + w[u];
    for (int i = 0; i < v[u]; i ++ ) f[u][i] = 0;
}

int main()
{
    cin >> n >> m;

    memset(h, -1, sizeof h);
    int root;
    for (int i = 1; i <= n; i ++ )
    {
        int p;
        cin >> v[i] >> w[i] >> p;
        if (p == -1) root = i;
        else add(p, i);
    }
    dfs(root);
    cout << f[root][m] << endl;
    return 0;
}
/*
5 7
2 3 -1
2 2 1
3 5 1
4 7 2
3 6 2

11
*/
```

### 4.18 最优最大价值方案数

```cpp
#include <cstring>
#include <iostream>
using namespace std;
const int N = 1010, mod = 1e9 + 7;

int n, m;
int f[N], g[N];
int main()
{
    cin >> n >> m;
    memset(f, -0x3f, sizeof f);
    f[0] = 0;
    g[0] = 1;

    for (int i = 0; i < n; i ++ )
    {
        int v, w;
        cin >> v >> w;
        for (int j = m; j >= v; j -- )
        {
            int maxv = max(f[j], f[j - v] + w);
            int s = 0;
            if (f[j] == maxv) s = g[j];
            if (f[j - v] + w == maxv) s = (s + g[j - v]) % mod;
            f[j] = maxv, g[j] = s;
        }
    }
    
    int res = 0;
    for (int i = 1; i <= m; i ++ )
        if (f[i] > f[res])
            res = i;
    
    int sum = 0;
    for (int i = 0; i <= m; i ++ )
        if (f[i] == f[res])
            sum = (sum + g[i]) % mod;
    cout << sum << endl;
    return 0;
}
```

### 4.19 背包问题求具体方案

```cpp
#include <iostream>

using namespace std;

const int N = 1010;

int n, m;
int v[N], w[N];
int f[N][N];

int main()
{
    cin >> n >> m;
    for (int i = 1; i <= n; i ++ ) cin >> v[i] >> w[i];

    for (int i = n; i >= 1; i -- )
        for (int j = 0; j <= m; j ++ )
        {
            f[i][j] = f[i + 1][j];
            if (j >= v[i]) f[i][j] = max(f[i][j], f[i + 1][j - v[i]] + w[i]);
        }

    int j = m;
    for (int i = 1; i <= n; i ++ )
        if (j >= v[i] && f[i][j] == f[i + 1][j - v[i]] + w[i])
        {
            cout << i << ' ';
            j -= v[i];
        }

    return 0;
}
```

## 状态机模型

**大盗阿福**

阿福事先调查得知，只有当他同时洗劫了两家相邻的店铺时，街上的报警系统才会启动，然后警察就会蜂拥而至。他想知道，在不惊动警察的情况下，他今晚最多可以得到多少现金？

```cpp
#include <iostream>
#include <algorithm>

using namespace std;

const int N = 100010;

int n;
int w[N], f[N][2];

int main()
{
    int T;
    scanf("%d", &T);
    while (T -- )
    {
        scanf("%d", &n);
        for (int i = 1; i <= n; i ++ ) scanf("%d", &w[i]);

        for (int i = 1; i <= n; i ++ )
        {
            f[i][0] = max(f[i - 1][0], f[i - 1][1]);
            f[i][1] = f[i - 1][0] + w[i];
        }

        printf("%d\n", max(f[n][0], f[n][1]));
    }

    return 0;
}
/*
2
3
1 8 2
4
10 7 6 14

8
24
*/
```

**股票买卖 IV**

给定一个长度为 N 的数组，数组中的第 i 个数字表示一个给定股票在第 i天的价格。设计一个算法来计算你所能获取的最大利润，你最多可以完成 k笔交易。
注意：你不能同时参与多笔交易（你必须在再次购买前出售掉之前的股票）。一次买入卖出合为一笔交易。

```cpp
// 输出一个整数，表示最大利润。
#include <cstring>
#include <iostream>
#include <algorithm>

using namespace std;

const int N = 100010, M = 110, INF = 0x3f3f3f3f;

int n, m;
int w[N];
int f[N][M][2];

int main()
{
    scanf("%d%d", &n, &m);
    for (int i = 1; i <= n; i ++ ) scanf("%d", &w[i]);

    memset(f, -0x3f, sizeof f);
    for (int i = 0; i <= n; i ++ ) f[i][0][0] = 0;

    for (int i = 1; i <= n; i ++ )
        for (int j = 1; j <= m; j ++ )
        {
            f[i][j][0] = max(f[i - 1][j][0], f[i - 1][j][1] + w[i]);
            f[i][j][1] = max(f[i - 1][j][1], f[i - 1][j - 1][0] - w[i]);
        }

    int res = 0;
    for (int i = 0; i <= m; i ++ ) res = max(res, f[n][i][0]);

    printf("%d\n", res);

    return 0;
}
```
**股票买卖 V**
给定一个长度为 N 的数组，数组中的第 i 个数字表示一个给定股票在第 i 天的价格。
设计一个算法计算出最大利润。在满足以下约束条件下，你可以尽可能地完成更多的交易（多次买卖一支股票）:
- 你不能同时参与多笔交易（你必须在再次购买前出售掉之前的股票）。
- 卖出股票后，你无法在第二天买入股票 (即冷冻期为 1 天)。
```cpp
// 算出最大利润
#include <cstring>
#include <iostream>
#include <algorithm>

using namespace std;

const int N = 100010, INF = 0x3f3f3f3f;

int n;
int w[N];
int f[N][3];

int main()
{
    scanf("%d", &n);

    for (int i = 1; i <= n; i ++ ) scanf("%d", &w[i]);

    f[0][0] = f[0][1] = -INF, f[0][2] = 0;
    for (int i = 1; i <= n; i ++ )
    {
        f[i][0] = max(f[i - 1][0], f[i - 1][2] - w[i]);
        f[i][1] = f[i - 1][0] + w[i];
        f[i][2] = max(f[i - 1][2], f[i - 1][1]);
    }

    printf("%d\n", max(f[n][1], f[n][2]));

    return 0;
}
```

**设计密码**
你现在需要设计一个密码 S，S需要满足：

- S 的长度是 N；
- S 只包含小写英文字母；
- S 不包含子串 T；
例如：abc 和 abcde 是 abcde 的子串，abd 不是 abcde的子串。
请问共有多少种不同的密码满足要求？ 由于答案会非常大，请输出答案模 109+7的余数。
```cpp
#include <cstring>
#include <iostream>
#include <algorithm>

using namespace std;

const int N = 55, mod = 1e9 + 7;

int n, m;
char str[N];
int nxt[N];
int f[N][N];

int main()
{
    cin >> n >> str + 1;

    m = strlen(str + 1);

    for (int i = 2, j = 0; i <= m; i ++ )
    {
        while (j && str[i] != str[j + 1]) j = nxt[j];
        if (str[i] == str[j + 1]) j ++ ;
        nxt[i] = j;
    }

    f[0][0] = 1;
    for (int i = 0; i < n; i ++ )
        for (int j = 0; j < m; j ++ )
            for (char k = 'a'; k <= 'z'; k ++ )
            {
                int u = j;
                while (u && k != str[u + 1]) u = nxt[u];
                if (k == str[u + 1]) u ++ ;
                if (u < m) f[i + 1][u] = (f[i + 1][u] + f[i][j]) % mod;
            }

    int res = 0;
    for (int i = 0; i < m; i ++ ) res = (res + f[n][i]) % mod;

    cout << res << endl;

    return 0;
}
```
**修复DNA**

生物学家终于发明了修复DNA的技术，能够将包含各种遗传疾病的DNA片段进行修复。为了简单起见，DNA看作是一个由’A’, ‘G’ , ‘C’ , ‘T’构成的字符串。修复技术就是通过改变字符串中的一些字符，从而消除字符串中包含的致病片段。需注意，被修复的DNA片段中，仍然只能包含字符’A’, ‘G’ , ‘C’ , ‘T’。

请你帮助生物学家修复给定的DNA片段，并且修复过程中改变的字符数量要尽可能的少。

```cpp
#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>

using namespace std;

const int N = 1010;

int n, m;
int tr[N][4], dar[N], idx;
int q[N], ne[N];
char str[N];

int f[N][N];

int get(char c)
{
    if (c == 'A') return 0;
    if (c == 'T') return 1;
    if (c == 'G') return 2;
    return 3;
}

void insert()
{
    int p = 0;
    for (int i = 0; str[i]; i ++ )
    {
        int t = get(str[i]);
        if (tr[p][t] == 0) tr[p][t] = ++ idx;
        p = tr[p][t];
    }
    dar[p] = 1;
}

void build()
{
    int hh = 0, tt = -1;
    for (int i = 0; i < 4; i ++ )
        if (tr[0][i])
            q[ ++ tt] = tr[0][i];

    while (hh <= tt)
    {
        int t = q[hh ++ ];
        for (int i = 0; i < 4; i ++ )
        {
            int p = tr[t][i];
            if (!p) tr[t][i] = tr[ne[t]][i];
            else
            {
                ne[p] = tr[ne[t]][i];
                q[ ++ tt] = p;
                dar[p] |= dar[ne[p]];
            }
        }
    }
}

int main()
{
    int T = 1;
    while (scanf("%d", &n), n)
    {
        memset(tr, 0, sizeof tr);
        memset(dar, 0, sizeof dar);
        memset(ne, 0, sizeof ne);
        idx = 0;

        for (int i = 0; i < n; i ++ )
        {
            scanf("%s", str);
            insert();
        }

        build();

        scanf("%s", str + 1);
        m = strlen(str + 1);

        memset(f, 0x3f, sizeof f);
        f[0][0] = 0;
        for (int i = 0; i < m; i ++ )
            for (int j = 0; j <= idx; j ++ )
                for (int k = 0; k < 4; k ++ )
                {
                    int t = get(str[i + 1]) != k;
                    int p = tr[j][k];
                    if (!dar[p]) f[i + 1][p] = min(f[i + 1][p], f[i][j] + t);
                }

        int res = 0x3f3f3f3f;
        for (int i = 0; i <= idx; i ++ ) res = min(res, f[m][i]);

        if (res == 0x3f3f3f3f) res = -1;
        printf("Case %d: %d\n", T ++, res);
    }

    return 0;
}
/*
2
AAA
AAG
AAAG    
2
A
TG
TGAATG
4
A
G
C
T
AGT
0

Case 1: 1
Case 2: 4
Case 3: -1
*/
```



## 状态压缩DP

**小国王**

```cpp
// 在 n×n 的棋盘上放 k 个国王，国王可攻击相邻的 8 个格子，求使它们无法互相攻击的方案总数。
#include <cstring>
#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

typedef long long LL;

const int N = 12, M = 1 << 10, K = 110;

int n, m;
vector<int> state;
int cnt[M];
vector<int> head[M];
LL f[N][K][M];

bool check(int state)
{
    for (int i = 0; i < n; i ++ )
        if ((state >> i & 1) && (state >> i + 1 & 1))
            return false;
    return true;
}

int count(int state)
{
    int res = 0;
    for (int i = 0; i < n; i ++ ) res += state >> i & 1;
    return res;
}

int main()
{
    cin >> n >> m;

    for (int i = 0; i < 1 << n; i ++ )
        if (check(i))
        {
            state.push_back(i);
            cnt[i] = count(i);
        }

    for (int i = 0; i < state.size(); i ++ )
        for (int j = 0; j < state.size(); j ++ )
        {
            int a = state[i], b = state[j];
            if ((a & b) == 0 && check(a | b))
                head[i].push_back(j);
        }

    f[0][0][0] = 1;
    for (int i = 1; i <= n + 1; i ++ )
        for (int j = 0; j <= m; j ++ )
            for (int a = 0; a < state.size(); a ++ )
                for (int b : head[a])
                {
                    int c = cnt[state[a]];
                    if (j >= c)
                        f[i][j][a] += f[i - 1][j - c][b];
                }

    cout << f[n + 1][m][0] << endl;

    return 0;
}
/*
3 2

16
*/
```
**玉米田**

农夫约翰的土地由 M×N 个小方格组成，现在他要在土地里种植玉米。非常遗憾，部分土地是不育的，无法种植。
而且，相邻的土地不能同时种植玉米，也就是说种植玉米的所有方格之间都不会有公共边缘。
现在给定土地的大小，请你求出共有多少种种植方法。土地上什么都不种也算一种方法。

```cpp
#include <cstring>
#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

const int N = 14, M = 1 << 12, mod = 1e8;

int n, m;
int w[N];
vector<int> state;
vector<int> head[M];
int f[N][M];

bool check(int state)
{
    for (int i = 0; i + 1 < m; i ++ )
        if ((state >> i & 1) && (state >> i + 1 & 1))
            return false;
    return true;
}

int main()
{
    cin >> n >> m;
    for (int i = 1; i <= n; i ++ )
        for (int j = 0; j < m; j ++ )
        {
            int t;
            cin >> t;
            w[i] += !t * (1 << j);
        }

    for (int i = 0; i < 1 << m; i ++ )
        if (check(i))
            state.push_back(i);

    for (int i = 0; i < state.size(); i ++ )
        for (int j = 0; j < state.size(); j ++ )
        {
            int a = state[i], b = state[j];
            if (!(a & b))
                head[i].push_back(j);
        }

    f[0][0] = 1;
    for (int i = 1; i <= n + 1; i ++ )
        for (int j = 0; j < state.size(); j ++ )
            if (!(state[j] & w[i]))
                for (int k : head[j])
                    f[i][j] = (f[i][j] + f[i - 1][k]) % mod;

    cout << f[n + 1][0] << endl;

    return 0;
}
/*
2 3
1 1 1
0 1 0

9
*/
```

## 区间DP

**环形石子合并**

求：

- 选择一种合并石子的方案，使得做 n−1 次合并得分总和最大。
- 选择一种合并石子的方案，使得做 n−1 次合并得分总和最小。

```cpp
#include <cstring>
#include <iostream>
#include <algorithm>

using namespace std;

const int N = 410, INF = 0x3f3f3f3f;

int n;
int w[N], s[N];
int f[N][N], g[N][N];

int main()
{
    cin >> n;
    for (int i = 1; i <= n; i ++ )
    {
        cin >> w[i];
        w[i + n] = w[i];
    }

    for (int i = 1; i <= n * 2; i ++ ) s[i] = s[i - 1] + w[i];

    memset(f, 0x3f, sizeof f);
    memset(g, -0x3f, sizeof g);

    for (int len = 1; len <= n; len ++ )
        for (int l = 1; l + len - 1 <= n * 2; l ++ )
        {
            int r = l + len - 1;
            if (l == r) f[l][r] = g[l][r] = 0;
            else
            {
                for (int k = l; k < r; k ++ )
                {
                    f[l][r] = min(f[l][r], f[l][k] + f[k + 1][r] + s[r] - s[l - 1]);
                    g[l][r] = max(g[l][r], g[l][k] + g[k + 1][r] + s[r] - s[l - 1]);
                }
            }
        }

    int minv = INF, maxv = -INF;
    for (int i = 1; i <= n; i ++ )
    {
        minv = min(minv, f[i][i + n - 1]);
        maxv = max(maxv, g[i][i + n - 1]);
    }

    cout << minv << endl << maxv << endl;

    return 0;
}
```
**加分二叉树**
设一个 n 个节点的二叉树 tree 的中序遍历为（1,2,3,…,n），其中数字 1,2,3,…,n 为节点编号。
每个节点都有一个分数（均为正整数），记第 i 个节点的分数为 di，tree 及它的每个子树都有一个加分，任一棵子树 subtree（也包含 tree 本身）的加分计算方法如下：     
subtree的左子树的加分 × subtree的右子树的加分 ＋ subtree的根的分数 
若某个子树为空，规定其加分为 1。
叶子的加分就是叶节点本身的分数，不考虑它的空子树。
试求一棵符合中序遍历为（1,2,3,…,n）且加分最高的二叉树 tree。

```cpp
#include <cstring>
#include <iostream>
#include <algorithm>

using namespace std;

const int N = 30;

int n;
int w[N];
int f[N][N], g[N][N];

void dfs(int l, int r)
{
    if (l > r) return;
    int k = g[l][r];
    cout << k << ' ';
    dfs(l, k - 1);
    dfs(k + 1, r);
}

int main()
{
    cin >> n;

    for (int i = 1; i <= n; i ++ ) cin >> w[i];

    for (int len = 1; len <= n; len ++ )
        for (int l = 1; l + len - 1 <= n; l ++ )
        {
            int r = l + len - 1;
            if (len == 1) f[l][r] = w[l], g[l][r] = l;
            else
            {
                for (int k = l; k <= r; k ++ )
                {
                    int left = k == l ? 1 : f[l][k - 1];
                    int right = k == r ? 1 : f[k + 1][r];
                    int score = left * right + w[k];
                    if (f[l][r] < score)
                    {
                        f[l][r] = score;
                        g[l][r] = k;
                    }
                }
            }
        }

    cout << f[1][n] << endl;
    dfs(1, n);
    return 0;
}
```

**凸多边形的划分**

给定一个具有 N 个顶点的凸多边形，将顶点从 1 至 N 标号，每个顶点的权值都是一个正整数。
将这个凸多边形划分成 N−2 个互不相交的三角形，对于每个三角形，其三个顶点的权值相乘都可得到一个权值乘积，试求所有三角形的顶点权值乘积之和至少为多少。

```cpp
#include <cstring>
#include <iostream>
#include <algorithm>

using namespace std;

typedef long long LL;

const int N = 55, M = 35, INF = 1e9;

int n;
int w[N];
LL f[N][N][M];

void add(LL a[], LL b[])
{
    static LL c[M];
    memset(c, 0, sizeof c);
    for (int i = 0, t = 0; i < M; i ++ )
    {
        t += a[i] + b[i];
        c[i] = t % 10;
        t /= 10;
    }
    memcpy(a, c, sizeof c);
}

void mul(LL a[], LL b)
{
    static LL c[M];
    memset(c, 0, sizeof c);
    LL t = 0;
    for (int i = 0; i < M; i ++ )
    {
        t += a[i] * b;
        c[i] = t % 10;
        t /= 10;
    }
    memcpy(a, c, sizeof c);
}

int cmp(LL a[], LL b[])
{
    for (int i = M - 1; i >= 0; i -- )
        if (a[i] > b[i]) return 1;
        else if (a[i] < b[i]) return -1;
    return 0;
}

void print(LL a[])
{
    int k = M - 1;
    while (k && !a[k]) k -- ;
    while (k >= 0) cout << a[k -- ];
    cout << endl;
}

int main()
{
    cin >> n;
    for (int i = 1; i <= n; i ++ ) cin >> w[i];

    LL temp[M];
    for (int len = 3; len <= n; len ++ )
        for (int l = 1; l + len - 1 <= n; l ++ )
        {
            int r = l + len - 1;
            f[l][r][M - 1] = 1;
            for (int k = l + 1; k < r; k ++ )
            {
                memset(temp, 0, sizeof temp);
                temp[0] = w[l];
                mul(temp, w[k]);
                mul(temp, w[r]);
                add(temp, f[l][k]);
                add(temp, f[k][r]);
                if (cmp(f[l][r], temp) > 0)
                    memcpy(f[l][r], temp, sizeof temp);
            }
        }
    print(f[1][n]);
    return 0;
}
```

## 数位DP

**数字游戏**
科协里最近很流行数字游戏。
某人命名了一种不降数，这种数字必须满足从左到右各位数字呈非下降关系，如 123，446。
现在大家决定玩一个游戏，指定一个整数闭区间 [a,b]，问这个区间内有多少个不降数。
```cpp
#include <cstring>
#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

const int N = 15;

int f[N][N];    // f[i, j]表示一共有i位，且最高位填j的数的个数

void init()
{
    for (int i = 0; i <= 9; i ++ ) f[1][i] = 1;

    for (int i = 2; i < N; i ++ )
        for (int j = 0; j <= 9; j ++ )
            for (int k = j; k <= 9; k ++ )
                f[i][j] += f[i - 1][k];
}

int dp(int n)
{
    if (!n) return 1;

    vector<int> nums;
    while (n) nums.push_back(n % 10), n /= 10;

    int res = 0;
    int last = 0;
    for (int i = nums.size() - 1; i >= 0; i -- )
    {
        int x = nums[i];
        for (int j = last; j < x; j ++ )
            res += f[i + 1][j];

        if (x < last) break;
        last = x;

        if (!i) res ++ ;
    }

    return res;
}

int main()
{
    init();
    int l, r;
    while (cin >> l >> r) cout << dp(r) - dp(l - 1) << endl;
    return 0;
}
/*
1 9
1 19

9
18
*/
```
**数字游戏 II**
由于科协里最近真的很流行数字游戏。
某人又命名了一种取模数，这种数字必须满足各位数字之和 mod N 为 0。
现在大家又要玩游戏了，指定一个整数闭区间 [a.b]，问这个区间内有多少个取模数。
```cpp
#include <cstring>
#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

const int N = 11, M = 110;

int P;
int f[N][10][M];

int mod(int x, int y)
{
    return (x % y + y) % y;
}

void init()
{
    memset(f, 0, sizeof f);

    for (int i = 0; i <= 9; i ++ ) f[1][i][i % P] ++ ;

    for (int i = 2; i < N; i ++ )
        for (int j = 0; j <= 9; j ++ )
            for (int k = 0; k < P; k ++ )
                for (int x = 0; x <= 9; x ++ )
                    f[i][j][k] += f[i - 1][x][mod(k - j, P)];
}

int dp(int n)
{
    if (!n) return 1;

    vector<int> nums;
    while (n) nums.push_back(n % 10), n /= 10;

    int res = 0;
    int last = 0;
    for (int i = nums.size() - 1; i >= 0; i -- )
    {
        int x = nums[i];
        for (int j = 0; j < x; j ++ )
            res += f[i + 1][j][mod(-last, P)];

        last += x;

        if (!i && last % P == 0) res ++ ;
    }

    return res;
}

int main()
{
    int l, r;
    while (cin >> l >> r >> P)
    {
        init();

        cout << dp(r) - dp(l - 1) << endl;
    }

    return 0;
}
/*
1 19 9

2
*/
```
**不要62**
不吉利的数字为所有含有 4 或 62 的号码。例如：62315,73418,88914 都属于不吉利号码。但是，61152 虽然含有 6 和 2，但不是 连号，所以不属于不吉利数字之列。
你的任务是，对于每次给出的一个牌照号区间 [n,m]，推断出交管局今后又要实际上给多少辆新的士车上牌照了。
```cpp
/*
每组数据包含一个整数对 n 和 m。
当输入一行为“0 0”时，表示输入结束。
*/
#include <cstring>
#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

const int N = 35;

int f[N][10];

void init()
{
    for (int i = 0; i <= 9; i ++ )
        if (i != 4)
            f[1][i] = 1;

    for (int i = 1; i < N; i ++ )
        for (int j = 0; j <= 9; j ++ )
        {
            if (j == 4) continue;
            for (int k = 0; k <= 9; k ++ )
            {
                if (k == 4 || j == 6 && k == 2) continue;
                f[i][j] += f[i - 1][k];
            }
        }
}

int dp(int n)
{
    if (!n) return 1;

    vector<int> nums;
    while (n) nums.push_back(n % 10), n /= 10;

    int res = 0;
    int last = 0;
    for (int i = nums.size() - 1; i >= 0; i -- )
    {
        int x = nums[i];
        for (int j = 0; j < x; j ++ )
        {
            if (j == 4 || last == 6 && j == 2) continue;
            res += f[i + 1][j];
        }

        if (x == 4 || last == 6 && x == 2) break;
        last = x;

        if (!i) res ++ ;
    }

    return res;
}

int main()
{
    init();
    int l, r;
    while (cin >> l >> r, l || r)
    {
        cout << dp(r) - dp(l - 1) << endl;
    }
    return 0;
}
/*
1 100
0 0

80
*/
```

## 斜率优化DP

**任务安排3**
有 N 个任务排成一个序列在一台机器上等待执行，它们的顺序不得改变。
机器会把这 N 个任务分成若干批，每一批包含连续的若干个任务。
从时刻 0 开始，任务被分批加工，执行第 i 个任务所需的时间是 Ti。
另外，在每批任务开始前，机器需要 S 的启动时间，故执行一批任务所需的时间是启动时间 S 加上每个任务所需时间之和。
一个任务执行后，将在机器中稍作等待，直至该批任务全部执行完毕。
也就是说，同一批任务将在同一时刻完成。
每个任务的费用是它的完成时刻乘以一个费用系数 Ci。
请为机器规划一个分组方案，使得总费用最小。

```cpp
#include <cstring>
#include <iostream>
#include <algorithm>

using namespace std;

typedef long long LL;

const int N = 300010;

int n, s;
LL t[N], c[N];
LL f[N];
int q[N];

int main()
{
    scanf("%d%d", &n, &s);
    for (int i = 1; i <= n; i ++ )
    {
        scanf("%lld%lld", &t[i], &c[i]);
        t[i] += t[i - 1];
        c[i] += c[i - 1];
    }

    int hh = 0, tt = 0;
    q[0] = 0;

    for (int i = 1; i <= n; i ++ )
    {
        int l = hh, r = tt;
        while (l < r)
        {
            int mid = l + r >> 1;
            if (f[q[mid + 1]] - f[q[mid]] > (t[i] + s) * (c[q[mid + 1]] - c[q[mid]])) r = mid;
            else l = mid + 1;
        }

        int j = q[r];
        f[i] = f[j] -   (t[i] + s) * c[j] + t[i] * c[i] + s * c[n];
        while (hh < tt && (double)(f[q[tt]] - f[q[tt - 1]]) * (c[i] - c[q[tt - 1]]) >= (double)(f[i] - f[q[tt - 1]]) * (c[q[tt]] - c[q[tt - 1]])) tt -- ;
        q[ ++ tt] = i;
    }

    printf("%lld\n", f[n]);

    return 0;
}
/*
5 1
1 3
3 2
4 3
2 3
1 4

153
*/
```

# 5. 搜索

## 5.1 BFS求连通块(FLood Fill)

```cpp
#include <cstring>
#include <iostream>
#include <algorithm>

#define x first
#define y second

using namespace std;

typedef pair<int, int> PII;

const int N = 1010, M = N * N;

int n, m;
char g[N][N];
PII q[M];
bool st[N][N];

void bfs(int sx, int sy)
{
    int hh = 0, tt = 0;
    q[0] = {sx, sy};
    st[sx][sy] = true;

    while (hh <= tt)
    {
        PII t = q[hh ++ ];

        for (int i = t.x - 1; i <= t.x + 1; i ++ )
            for (int j = t.y - 1; j <= t.y + 1; j ++ )
            {
                if (i == t.x && j == t.y) continue;
                if (i < 0 || i >= n || j < 0 || j >= m) continue;
                if (g[i][j] == '.' || st[i][j]) continue;

                q[ ++ tt] = {i, j};
                st[i][j] = true;
            }
    }
}

int main()
{
    scanf("%d%d", &n, &m);
    for (int i = 0; i < n; i ++ ) scanf("%s", g[i]);

    int cnt = 0;
    for (int i = 0; i < n; i ++ )
        for (int j = 0; j < m; j ++ )
            if (g[i][j] == 'W' && !st[i][j])
            {
                bfs(i, j);
                cnt ++ ;
            }

    printf("%d\n", cnt);

    return 0;
}
```

##  5.2 矩阵最短路模型

经典迷宫问题，左上到右下找到一条最短路径(并输出)

```cpp
#include <cstring>
#include <iostream>
#include <algorithm>

#define x first
#define y second

using namespace std;

typedef pair<int, int> PII;

const int N = 1010, M = N * N;

int n;
int g[N][N];
PII q[M];
PII pre[N][N];

void bfs(int sx, int sy)
{
    int dx[4] = {-1, 0, 1, 0}, dy[4] = {0, 1, 0, -1};

    int hh = 0, tt = 0;
    q[0] = {sx, sy};

    memset(pre, -1, sizeof pre);
    pre[sx][sy] = {0, 0};
    while (hh <= tt)
    {
        PII t = q[hh ++ ];

        for (int i = 0; i < 4; i ++ )
        {
            int a = t.x + dx[i], b = t.y + dy[i];
            if (a < 0 || a >= n || b < 0 || b >= n) continue;
            if (g[a][b]) continue;
            if (pre[a][b].x != -1) continue;

            q[ ++ tt] = {a, b};
            pre[a][b] = t;
        }
    }
}

int main()
{
    scanf("%d", &n);

    for (int i = 0; i < n; i ++ )
        for (int j = 0; j < n; j ++ )
            scanf("%d", &g[i][j]);

    bfs(n - 1, n - 1);

    PII end(0, 0);

    while (true)
    {
        printf("%d %d\n", end.x, end.y);
        if (end.x == n - 1 && end.y == n - 1) break;
        end = pre[end.x][end.y];
    }

    return 0;
}
```

**象棋马走日，象走田最短路径等**只需要稍微修改一下dx，dy数组

## 5.3 双向BFS
**字符串变换**

```cpp
#include <iostream>
#include <cstring>
#include <algorithm>
#include <queue>
#include <unordered_map>

using namespace std;

const int N = 6;

int n;
string A, B;
string a[N], b[N];

int extend(queue<string>& q, unordered_map<string, int>&da, unordered_map<string, int>& db, 
    string a[N], string b[N])
{
    int d = da[q.front()];
    while (q.size() && da[q.front()] == d)
    {
        auto t = q.front();
        q.pop();

        for (int i = 0; i < n; i ++ )
            for (int j = 0; j < t.size(); j ++ )
                if (t.substr(j, a[i].size()) == a[i])
                {
                    string r = t.substr(0, j) + b[i] + t.substr(j + a[i].size());
                    if (db.count(r)) return da[t] + db[r] + 1;
                    if (da.count(r)) continue;
                    da[r] = da[t] + 1;
                    q.push(r);
                }
    }

    return 11;
}

int bfs()
{
    if (A == B) return 0;
    queue<string> qa, qb;
    unordered_map<string, int> da, db;

    qa.push(A), qb.push(B);
    da[A] = db[B] = 0;

    int step = 0;
    while (qa.size() && qb.size())
    {
        int t;
        if (qa.size() < qb.size()) t = extend(qa, da, db, a, b);
        else t = extend(qb, db, da, b, a);

        if (t <= 10) return t;
        if ( ++ step == 10) return -1;
    }

    return -1;
}

int main()
{
    cin >> A >> B;
    while (cin >> a[n] >> b[n]) n ++ ;

    int t = bfs();
    if (t == -1) puts("NO ANSWER!");
    else cout << t << endl;

    return 0;
}
```

## 5.4 双端队列广搜

边权只有01的图适用

```cpp
// 电路维修
/*
联通的边权为0，不连通的边权为0
*/
#include <cstring>
#include <iostream>
#include <algorithm>
#include <deque>

#define x first
#define y second

using namespace std;

typedef pair<int, int> PII;

const int N = 510, M = N * N;

int n, m;
char g[N][N];
int dist[N][N];
bool st[N][N];

int bfs()
{
    memset(dist, 0x3f, sizeof dist);
    memset(st, 0, sizeof st);
    dist[0][0] = 0;
    deque<PII> q;
    q.push_back({0, 0});

    char cs[] = "\\/\\/";
    int dx[4] = {-1, -1, 1, 1}, dy[4] = {-1, 1, 1, -1};
    int ix[4] = {-1, -1, 0, 0}, iy[4] = {-1, 0, 0, -1};

    while (q.size())
    {
        PII t = q.front();
        q.pop_front();

        if (st[t.x][t.y]) continue;
        st[t.x][t.y] = true;

        for (int i = 0; i < 4; i ++ )
        {
            int a = t.x + dx[i], b = t.y + dy[i];
            if (a < 0 || a > n || b < 0 || b > m) continue;

            int ca = t.x + ix[i], cb = t.y + iy[i];
            int d = dist[t.x][t.y] + (g[ca][cb] != cs[i]);

            if (d < dist[a][b])
            {
                dist[a][b] = d;

                if (g[ca][cb] != cs[i]) q.push_back({a, b}); // 如果边权为1则放到队尾
                else q.push_front({a, b}); // 如果边权为0则放到对头
            }
        }
    }

    return dist[n][m];
}

int main()
{
    int T;
    scanf("%d", &T);
    while (T -- )
    {
        scanf("%d%d", &n, &m);
        for (int i = 0; i < n; i ++ ) scanf("%s", g[i]);

        int t = bfs();

        if (t == 0x3f3f3f3f) puts("NO SOLUTION");
        else printf("%d\n", t);
    }

    return 0;
}
```

## 5.5 A*

### 第K短路

``` cpp
// 给定一张 N 个点（编号 1,2…N），M 条边的有向图，求从起点 S 到终点 T 的第 K 短路的长度，路径允许重复经过点或边。
#include <cstring>
#include <iostream>
#include <algorithm>
#include <queue>

#define x first
#define y second

using namespace std;

typedef pair<int, int> PII;
typedef pair<int, PII> PIII;

const int N = 1010, M = 200010;

int n, m, S, T, K;
int h[N], rh[N], e[M], w[M], ne[M], idx;
int dist[N], cnt[N];
bool st[N];

void add(int h[], int a, int b, int c)
{
    e[idx] = b, w[idx] = c, ne[idx] = h[a], h[a] = idx ++ ;
}

void dijkstra()
{
    priority_queue<PII, vector<PII>, greater<PII>> heap;
    heap.push({0, T});

    memset(dist, 0x3f, sizeof dist);
    dist[T] = 0;

    while (heap.size())
    {
        auto t = heap.top();
        heap.pop();

        int ver = t.y;
        if (st[ver]) continue;
        st[ver] = true;

        for (int i = rh[ver]; ~i; i = ne[i])
        {
            int j = e[i];
            if (dist[j] > dist[ver] + w[i])
            {
                dist[j] = dist[ver] + w[i];
                heap.push({dist[j], j});
            }
        }
    }
}

int astar()
{
    priority_queue<PIII, vector<PIII>, greater<PIII>> heap;
    heap.push({dist[S], {0, S}});

    while (heap.size())
    {
        auto t = heap.top();
        heap.pop();

        int ver = t.y.y, distance = t.y.x;
        cnt[ver] ++ ;
        if (cnt[T] == K) return distance;

        for (int i = h[ver]; ~i; i = ne[i])
        {
            int j = e[i];
            if (cnt[j] < K)
                heap.push({distance + w[i] + dist[j], {distance + w[i], j}});
        }
    }

    return -1;
}

int main()
{
    scanf("%d%d", &n, &m);
    memset(h, -1, sizeof h);
    memset(rh, -1, sizeof rh);

    for (int i = 0; i < m; i ++ )
    {
        int a, b, c;
        scanf("%d%d%d", &a, &b, &c);
        add(h, a, b, c);
        add(rh, b, a, c);
    }
    scanf("%d%d%d", &S, &T, &K);
    if (S == T) K ++ ;

    dijkstra();
    printf("%d\n", astar());

    return 0;
}
```

## 5.6 双向DFS
达达帮翰翰给女生送礼物，翰翰一共准备了 N 个礼物，其中第 i 个礼物的重量是 G[i]。
达达的力气很大，他一次可以搬动重量之和不超过 W 的任意多个物品。
达达希望一次搬掉尽量重的一些物品，请你告诉达达在他的力气范围内一次性能搬动的最大重量是多少。
```cpp
#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

typedef long long LL;

const int N = 1 << 24;

int n, m, k;
int g[50], weights[N];
int cnt = 0;
int ans;

void dfs(int u, int s)
{
    if (u == k)
    {
        weights[cnt ++ ] = s;
        return;
    }

    if ((LL)s + g[u] <= m) dfs(u + 1, s + g[u]);
    dfs(u + 1, s);
}

void dfs2(int u, int s)
{
    if (u == n)
    {
        int l = 0, r = cnt - 1;
        while (l < r)
        {
            int mid = l + r + 1 >> 1;
            if (weights[mid] + (LL)s <= m) l = mid;
            else r = mid - 1;
        }
        if (weights[l] + (LL)s <= m) ans = max(ans, weights[l] + s);

        return;
    }

    if ((LL)s + g[u] <= m) dfs2(u + 1, s + g[u]);
    dfs2(u + 1, s);
}

int main()
{
    cin >> m >> n;
    for (int i = 0; i < n; i ++ ) cin >> g[i];

    sort(g, g + n);
    reverse(g, g + n);

    k = n / 2;  // 防止 n = 1时，出现死循环
    dfs(0, 0);

    sort(weights, weights + cnt);
    int t = 1;
    for (int i = 1; i < cnt; i ++ )
        if (weights[i] != weights[i - 1])
            weights[t ++ ] = weights[i];
    cnt = t;

    dfs2(k, 0);

    cout << ans << endl;

    return 0;
}
/*
20 5
7
5
4
18
1

19
*/
```

## 5.7 IDA*
### 排书
给定 n 本书，编号为 1∼n。
在初始状态下，书是任意排列的。
在每一次操作中，可以抽取其中连续的一段，再把这段插入到其他某个位置。
我们的目标状态是把书按照 1∼n 的顺序依次排列。
求最少需要多少次操作。

```cpp
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;
const int N = 15;

int n;
int q[N];
int w[5][N];

int f()
{
    int cnt = 0;
    for (int i = 0; i + 1 < n; i ++ )
        if (q[i + 1] != q[i] + 1)
            cnt ++ ;
    return (cnt + 2) / 3;
}

bool check()
{
    for (int i = 0; i + 1 < n; i ++ )
        if (q[i + 1] != q[i] + 1)
            return false;
    return true;
}

bool dfs(int depth, int max_depth)
{
    if (depth + f() > max_depth) return false;
    if (check()) return true;

    for (int len = 1; len <= n; len ++ )
        for (int l = 0; l + len - 1 < n; l ++ )
        {
            int r = l + len - 1;
            for (int k = r + 1; k < n; k ++ )
            {
                memcpy(w[depth], q, sizeof q);
                int x, y;
                for (x = r + 1, y = l; x <= k; x ++, y ++ ) q[y] = w[depth][x];
                for (x = l; x <= r; x ++, y ++ ) q[y] = w[depth][x];
                if (dfs(depth + 1, max_depth)) return true;
                memcpy(q, w[depth], sizeof q);
            }
        }

    return false;
}

int main()
{
    int T;
    cin >> T;
    while (T -- )
    {
        cin >> n;
        for (int i = 0; i < n; i ++ ) cin >> q[i];

        int depth = 0;
        while (depth < 5 && !dfs(0, depth)) depth ++ ;
        if (depth >= 5) puts("5 or more");
        else cout << depth << endl;
    }

    return 0;
}
```

# 6. 图论

## 6.1 存边

- 邻接矩阵

- 邻接表

```cpp
// 对于每个点k，开一个单链表，存储k所有可以走到的点。h[k]存储这个单链表的头结点
int h[N], e[N], ne[N], idx;
// 添加一条边a->b
void add(int a, int b)
{
    e[idx] = b, ne[idx] = h[a], h[a] = idx ++ ;
}
// 初始化
idx = 0;
memset(h, -1, sizeof h);
```
## 6.2 树与图的遍历
时间复杂度 O(n+m)，n 表示点数，m 表示边数
- **深度优先遍历**
```cpp
int dfs(int u)
{
    st[u] = true; // st[u] 表示点u已经被遍历过

    for (int i = h[u]; i != -1; i = ne[i])
    {
        int j = e[i];
        if (!st[j]) dfs(j);
    }
}
```
- **宽度优先遍历**
```cpp
queue<int> q;
st[1] = true; // 表示1号点已经被遍历过
q.push(1);

while (q.size())
{
    int t = q.front();
    q.pop();

    for (int i = h[t]; i != -1; i = ne[i])
    {
        int j = e[i];
        if (!st[j])
        {
            st[j] = true; // 表示点j已经被遍历过
            q.push(j);
        }
    }
}
```
## 6.3 拓扑排序 
时间复杂度 O(n+m)，n 表示点数，m 表示边数
```cpp
bool topsort()
{
    int hh = 0, tt = -1;

    // d[i] 存储点i的入度
    for (int i = 1; i <= n; i ++ )
        if (!d[i])
            q[ ++ tt] = i;

    while (hh <= tt)
    {
        int t = q[hh ++ ];

        for (int i = h[t]; i != -1; i = ne[i])
        {
            int j = e[i];
            if (-- d[j] == 0)
                q[ ++ tt] = j;
        }
    }

    // 如果所有点都入队了，说明存在拓扑序列；否则不存在拓扑序列。
    return tt == n - 1;
}
```
## 6.4 图论最短路模型(DJ, SPFA..)
### 堆优化的Dijkstra
**时间复杂度 O(mlogn), n 表示点数，m 表示边数**

```cpp
typedef pair<int, int> PII;

int n;      // 点的数量
int h[N], w[N], e[N], ne[N], idx;       // 邻接表存储所有边
int dist[N];        // 存储所有点到1号点的距离
bool st[N];     // 存储每个点的最短距离是否已确定

// 求1号点到n号点的最短距离，如果不存在，则返回-1
int dijkstra()
{
    memset(dist, 0x3f, sizeof dist);
    dist[1] = 0;
    priority_queue<PII, vector<PII>, greater<PII>> heap;
    heap.push({0, 1});      // first存储距离，second存储节点编号

    while (heap.size())
    {
        auto t = heap.top();
        heap.pop();

        int ver = t.second, distance = t.first;

        if (st[ver]) continue;
        st[ver] = true;

        for (int i = h[ver]; i != -1; i = ne[i])
        {
            int j = e[i];
            if (dist[j] > distance + w[i])
            {
                dist[j] = distance + w[i];
                heap.push({dist[j], j});
            }
        }
    }

    if (dist[n] == 0x3f3f3f3f) return -1;
    return dist[n];
}
```
### Bellman-Ford算法
**时间复杂度 O(nm), n 表示点数，m 表示边数**

```cpp
#include <iostream>
#include <cstring>
#include <algorithm>

using namespace std;

const int N = 1e4 + 10;

struct Edge
{
    int a, b, w;
}edge[N];

int n, m, k;
int dist[N], backup[N];

void bellman_ford()
{
    memset(dist, 0x3f, sizeof dist);
    dist[1] = 0;
    for(int i = 1;i <= k;i ++)
    {
        memcpy(backup, dist, sizeof dist);
        for(int j = 0;j <= m;j ++)
        {
            int a = edge[j].a,b = edge[j].b,w = edge[j].w;
            dist[b] = min(dist[b], backup[a] + w);
        }
    }
    if(dist[n] > 0x3f3f3f3f / 2)    printf("impossible\n");
    else    printf("%d\n", dist[n]);
}

int main()
{
    scanf("%d%d%d",&n, &m, &k);
    for(int i = 1;i <= m;i ++)
    {
        Edge &x = edge[i];
        scanf("%d%d%d",&x.a, &x.b, &x.w);
    }
    bellman_ford();
    return 0;
}
```
### SPFA算法
**时间复杂度 平均情况下 O(m)，最坏情况下 O(nm), n 表示点数, m 表示边数**
```cpp
int n;      // 总点数
int h[N], w[N], e[N], ne[N], idx;       // 邻接表存储所有边
int dist[N];        // 存储每个点到1号点的最短距离
bool st[N];     // 存储每个点是否在队列中

// 求1号点到n号点的最短路距离，如果从1号点无法走到n号点则返回-1
int spfa()
{
    memset(dist, 0x3f, sizeof dist);
    dist[1] = 0;

    queue<int> q;
    q.push(1);
    st[1] = true;

    while (q.size())
    {
        auto t = q.front();
        q.pop();

        st[t] = false;

        for (int i = h[t]; i != -1; i = ne[i])
        {
            int j = e[i];
            if (dist[j] > dist[t] + w[i])
            {
                dist[j] = dist[t] + w[i];
                if (!st[j])     // 如果队列中已存在j，则不需要将j重复插入
                {
                    q.push(j);
                    st[j] = true;
                }
            }
        }
    }

    if (dist[n] == 0x3f3f3f3f) return -1;
    return dist[n];
}
```
### spfa判断图中是否存在负环
**时间复杂度是 O(nm), n 表示点数，m 表示边数**
```cpp
int n;      // 总点数
int h[N], w[N], e[N], ne[N], idx;       // 邻接表存储所有边
int dist[N], cnt[N];        // dist[x]存储1号点到x的最短距离，cnt[x]存储1到x的最短路中经过的点数
bool st[N];     // 存储每个点是否在队列中

// 如果存在负环，则返回true，否则返回false。
bool spfa()
{
    // 不需要初始化dist数组
    // 原理：如果某条最短路径上有n个点（除了自己），那么加上自己之后一共有n+1个点，由抽屉原理一定有两个点相同，所以存在环。

    queue<int> q;
    for (int i = 1; i <= n; i ++ )
    {
        q.push(i);
        st[i] = true;
    }

    while (q.size())
    {
        auto t = q.front();
        q.pop();

        st[t] = false;

        for (int i = h[t]; i != -1; i = ne[i])
        {
            int j = e[i];
            if (dist[j] > dist[t] + w[i])
            {
                dist[j] = dist[t] + w[i];
                cnt[j] = cnt[t] + 1;
                if (cnt[j] >= n) return true;       // 如果从1号点到x的最短路中包含至少n个点（不包括自己），则说明存在环
                if (!st[j])
                {
                    q.push(j);
                    st[j] = true;
                }
            }
        }
    }

    return false;
}
```
### floyd算法
**时间复杂度是 O(n3), n 表示点数**
```cpp
初始化：
    for (int i = 1; i <= n; i ++ )
        for (int j = 1; j <= n; j ++ )
            if (i == j) d[i][j] = 0;
            else d[i][j] = INF;

// 算法结束后，d[a][b]表示a到b的最短距离
void floyd()
{
    for (int k = 1; k <= n; k ++ )
        for (int i = 1; i <= n; i ++ )
            for (int j = 1; j <= n; j ++ )
                d[i][j] = min(d[i][j], d[i][k] + d[k][j]);
}
```
## 6.5 最小生成树
### 朴素版prim算法 
**时间复杂度是 O(n^2+m), n 表示点数，m 表示边数**
```cpp
int n;      // n表示点数
int g[N][N];        // 邻接矩阵，存储所有边
int dist[N];        // 存储其他点到当前最小生成树的距离
bool st[N];     // 存储每个点是否已经在生成树中

// 如果图不连通，则返回INF(值是0x3f3f3f3f), 否则返回最小生成树的树边权重之和
int prim()
{
    memset(dist, 0x3f, sizeof dist);

    int res = 0;
    for (int i = 0; i < n; i ++ )
    {
        int t = -1;
        for (int j = 1; j <= n; j ++ )
            if (!st[j] && (t == -1 || dist[t] > dist[j]))
                t = j;

        if (i && dist[t] == INF) return INF;

        if (i) res += dist[t];
        st[t] = true;

        for (int j = 1; j <= n; j ++ ) dist[j] = min(dist[j], g[t][j]);
    }

    return res;
}
```
### Kruskal算法 
**时间复杂度是 O(mlogm), n 表示点数，m 表示边数**
```cpp
int n, m;       // n是点数，m是边数
int p[N];       // 并查集的父节点数组

struct Edge     // 存储边
{
    int a, b, w;

    bool operator< (const Edge &W)const
    {
        return w < W.w;
    }
}edges[M];

int find(int x)     // 并查集核心操作
{
    if (p[x] != x) p[x] = find(p[x]);
    return p[x];
}

int kruskal()
{
    sort(edges, edges + m);

    for (int i = 1; i <= n; i ++ ) p[i] = i;    // 初始化并查集

    int res = 0, cnt = 0;
    for (int i = 0; i < m; i ++ )
    {
        int a = edges[i].a, b = edges[i].b, w = edges[i].w;

        a = find(a), b = find(b);
        if (a != b)     // 如果两个连通块不连通，则将这两个连通块合并
        {
            p[a] = b;
            res += w;
            cnt ++ ;
        }
    }

    if (cnt < n - 1) return INF;
    return res;
}
```
## 6.6 染色法判别二分图
**时间复杂度是 O(n+m), n 表示点数，m 表示边数**
```cpp
int n;      // n表示点数
int h[N], e[M], ne[M], idx;     // 邻接表存储图
int color[N];       // 表示每个点的颜色，-1表示未染色，0表示白色，1表示黑色

// 参数：u表示当前节点，c表示当前点的颜色
bool dfs(int u, int c)
{
    color[u] = c;
    for (int i = h[u]; i != -1; i = ne[i])
    {
        int j = e[i];
        if (color[j] == -1)
        {
            if (!dfs(j, !c)) return false;
        }
        else if (color[j] == c) return false;
    }

    return true;
}

bool check()
{
    memset(color, -1, sizeof color);
    bool flag = true;
    for (int i = 1; i <= n; i ++ )
        if (color[i] == -1)
            if (!dfs(i, 0))
            {
                flag = false;
                break;
            }
    return flag;
}
```
## 6.7 二分图的最大匹配（匈牙利算法）
**时间复杂度是 O(nm), n 表示点数，m 表示边数**

```cpp
int n1, n2;     // n1表示第一个集合中的点数，n2表示第二个集合中的点数
int h[N], e[M], ne[M], idx;     // 邻接表存储所有边，匈牙利算法中只会用到从第一个集合指向第二个集合的边，所以这里只用存一个方向的边
int match[N];       // 存储第二个集合中的每个点当前匹配的第一个集合中的点是哪个
bool st[N];     // 表示第二个集合中的每个点是否已经被遍历过

bool find(int x)
{
    for (int i = h[x]; i != -1; i = ne[i])
    {
        int j = e[i];
        if (!st[j])
        {
            st[j] = true;
            if (match[j] == 0 || find(match[j]))
            {
                match[j] = x;
                return true;
            }
        }
    }

    return false;
}

// 求最大匹配数，依次枚举第一个集合中的每个点能否匹配第二个集合中的点
int res = 0;
for (int i = 1; i <= n1; i ++ )
{
    memset(st, false, sizeof st);
    if (find(i)) res ++ ;
}
```

## 6.8 树的直径

树上最长的路径

- **树形DP求树的直径**

```cpp
void dp(int x) {
    st[x] = 1;
    for(int i = h[x]; i != -1; i = ne[i]) {
        int j = e[i];
        if(st[j]) continue;
        dp(j);
        ans = max(ans, d[x] + d[j] + w[i]);
        d[x] = max(d[x], d[j] + w[i]);
    }
}
```

- **两次BFS求出树的直径（边权非负）**
（1）从任意一个节点出发，跑一遍BFS，找到最远的p
（2）再从p出发，跑一遍BFS，找到距离p最远的q
p, q即为两个端点。

## 6.9  欧拉回路与欧拉路径

存在欧拉回路与欧拉路径的充要条件：

- 无向图

  - 存在**欧拉路径**的充要条件 : 度数为奇数的点只能有0或2个
  - 存在**欧拉回路**的充要条件 : 度数为奇数的点只能有0个

- 有向图

  - 存在**欧拉路径**的充要条件 : 

    - 要么所有点的出度均==入度；

    - 要么除了两个点之外，其余所有点的出度==入度 剩余的两个点:一个满足**出度-入度==1**(起点) 一个满足**入度-出度**==1(终点)

  - 存在**欧拉回路**的充要条件 : 所有点的出度均等于入度

## 6.10 最近公共祖先（LCA）

### **祖孙询问**

```cpp
#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>

using namespace std;

const int N = 40010, M = N * 2;

int n, m;
int h[N], e[M], ne[M], idx;
int depth[N], fa[N][16];
int q[N];

void add(int a, int b)
{
    e[idx] = b, ne[idx] = h[a], h[a] = idx ++ ;
}

void bfs(int root)
{
    memset(depth, 0x3f, sizeof depth);
    depth[0] = 0, depth[root] = 1;
    int hh = 0, tt = 0;
    q[0] = root;
    while (hh <= tt)
    {
        int t = q[hh ++ ];
        for (int i = h[t]; ~i; i = ne[i])
        {
            int j = e[i];
            if (depth[j] > depth[t] + 1)
            {
                depth[j] = depth[t] + 1;
                q[ ++ tt] = j;
                fa[j][0] = t;
                for (int k = 1; k <= 15; k ++ )
                    fa[j][k] = fa[fa[j][k - 1]][k - 1];
            }
        }
    }
}

int lca(int a, int b)
{
    if (depth[a] < depth[b]) swap(a, b);
    for (int k = 15; k >= 0; k -- )
        if (depth[fa[a][k]] >= depth[b])
            a = fa[a][k];
    if (a == b) return a;
    for (int k = 15; k >= 0; k -- )
        if (fa[a][k] != fa[b][k])
        {
            a = fa[a][k];
            b = fa[b][k];
        }
    return fa[a][0];
}

int main()
{
    scanf("%d", &n);
    int root = 0;
    memset(h, -1, sizeof h);

    for (int i = 0; i < n; i ++ )
    {
        int a, b;
        scanf("%d%d", &a, &b);
        if (b == -1) root = a;
        else add(a, b), add(b, a);
    }

    bfs(root);

    scanf("%d", &m);
    while (m -- )
    {
        int a, b;
        scanf("%d%d", &a, &b);
        int p = lca(a, b);
        if (p == a) puts("1");
        else if (p == b) puts("2");
        else puts("0");
    }

    return 0;
}
```
### 次小生成树

```cpp
#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>

using namespace std;

typedef long long LL;

const int N = 100010, M = 300010, INF = 0x3f3f3f3f;

int n, m;
struct Edge
{
    int a, b, w;
    bool used;
    bool operator< (const Edge &t) const
    {
        return w < t.w;
    }
}edge[M];
int p[N];
int h[N], e[M], w[M], ne[M], idx;
int depth[N], fa[N][17], d1[N][17], d2[N][17];
int q[N];

void add(int a, int b, int c)
{
    e[idx] = b, w[idx] = c, ne[idx] = h[a], h[a] = idx ++ ;
}

int find(int x)
{
    if (p[x] != x) p[x] = find(p[x]);
    return p[x];
}

LL kruskal()
{
    for (int i = 1; i <= n; i ++ ) p[i] = i;
    sort(edge, edge + m);
    LL res = 0;
    for (int i = 0; i < m; i ++ )
    {
        int a = find(edge[i].a), b = find(edge[i].b), w = edge[i].w;
        if (a != b)
        {
            p[a] = b;
            res += w;
            edge[i].used = true;
        }
    }

    return res;
}

void build()
{
    memset(h, -1, sizeof h);
    for (int i = 0; i < m; i ++ )
        if (edge[i].used)
        {
            int a = edge[i].a, b = edge[i].b, w = edge[i].w;
            add(a, b, w), add(b, a, w);
        }
}

void bfs()
{
    memset(depth, 0x3f, sizeof depth);
    depth[0] = 0, depth[1] = 1;
    q[0] = 1;
    int hh = 0, tt = 0;
    while (hh <= tt)
    {
        int t = q[hh ++ ];
        for (int i = h[t]; ~i; i = ne[i])
        {
            int j = e[i];
            if (depth[j] > depth[t] + 1)
            {
                depth[j] = depth[t] + 1;
                q[ ++ tt] = j;
                fa[j][0] = t;
                d1[j][0] = w[i], d2[j][0] = -INF;
                for (int k = 1; k <= 16; k ++ )
                {
                    int anc = fa[j][k - 1];
                    fa[j][k] = fa[anc][k - 1];
                    int distance[4] = {d1[j][k - 1], d2[j][k - 1], d1[anc][k - 1], d2[anc][k - 1]};
                    d1[j][k] = d2[j][k] = -INF;
                    for (int u = 0; u < 4; u ++ )
                    {
                        int d = distance[u];
                        if (d > d1[j][k]) d2[j][k] = d1[j][k], d1[j][k] = d;
                        else if (d != d1[j][k] && d > d2[j][k]) d2[j][k] = d;
                    }
                }
            }
        }
    }
}

int lca(int a, int b, int w)
{
    static int distance[N * 2];
    int cnt = 0;
    if (depth[a] < depth[b]) swap(a, b);
    for (int k = 16; k >= 0; k -- )
        if (depth[fa[a][k]] >= depth[b])
        {
            distance[cnt ++ ] = d1[a][k];
            distance[cnt ++ ] = d2[a][k];
            a = fa[a][k];
        }
    if (a != b)
    {
        for (int k = 16; k >= 0; k -- )
            if (fa[a][k] != fa[b][k])
            {
                distance[cnt ++ ] = d1[a][k];
                distance[cnt ++ ] = d2[a][k];
                distance[cnt ++ ] = d1[b][k];
                distance[cnt ++ ] = d2[b][k];
                a = fa[a][k], b = fa[b][k];
            }
        distance[cnt ++ ] = d1[a][0];
        distance[cnt ++ ] = d1[b][0];
    }

    int dist1 = -INF, dist2 = -INF;
    for (int i = 0; i < cnt; i ++ )
    {
        int d = distance[i];
        if (d > dist1) dist2 = dist1, dist1 = d;
        else if (d != dist1 && d > dist2) dist2 = d;
    }

    if (w > dist1) return w - dist1;
    if (w > dist2) return w - dist2;
    return INF;
}

int main()
{
    scanf("%d%d", &n, &m);
    for (int i = 0; i < m; i ++ )
    {
        int a, b, c;
        scanf("%d%d%d", &a, &b, &c);
        edge[i] = {a, b, c};
    }

    LL sum = kruskal();
    build();
    bfs();

    LL res = 1e18;
    for (int i = 0; i < m; i ++ )
        if (!edge[i].used)
        {
            int a = edge[i].a, b = edge[i].b, w = edge[i].w;
            res = min(res, sum + lca(a, b, w));
        }
    printf("%lld\n", res);

    return 0;
}
```



## 6.11 树上两点距离

```cpp
#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

typedef pair<int, int> PII;

const int N = 10010, M = N * 2;

int n, m;
int h[N], e[M], w[M], ne[M], idx;
int dist[N];
int p[N];
int res[M];
int st[N];
vector<PII> query[N];   // first存查询的另外一个点，second存查询编号

void add(int a, int b, int c)
{
    e[idx] = b, w[idx] = c, ne[idx] = h[a], h[a] = idx ++ ;
}

void dfs(int u, int fa)
{
    for (int i = h[u]; ~i; i = ne[i])
    {
        int j = e[i];
        if (j == fa) continue;
        dist[j] = dist[u] + w[i];
        dfs(j, u);
    }
}

int find(int x)
{
    if (p[x] != x) p[x] = find(p[x]);
    return p[x];
}

void tarjan(int u)
{
    st[u] = 1;
    for (int i = h[u]; ~i; i = ne[i])
    {
        int j = e[i];
        if (!st[j])
        {
            tarjan(j);
            p[j] = u;
        }
    }

    for (auto item : query[u])
    {
        int y = item.first, id = item.second;
        if (st[y] == 2)
        {
            int anc = find(y);
            res[id] = dist[u] + dist[y] - dist[anc] * 2;
        }
    }

    st[u] = 2;
}

int main()
{
    scanf("%d%d", &n, &m);
    memset(h, -1, sizeof h);
    for (int i = 0; i < n - 1; i ++ )
    {
        int a, b, c;
        scanf("%d%d%d", &a, &b, &c);
        add(a, b, c), add(b, a, c);
    }

    for (int i = 0; i < m; i ++ )
    {
        int a, b;
        scanf("%d%d", &a, &b);
        if (a != b)
        {
            query[a].push_back({b, i});
            query[b].push_back({a, i});
        }
    }

    for (int i = 1; i <= n; i ++ ) p[i] = i;

    dfs(1, -1);
    tarjan(1);

    for (int i = 0; i < m; i ++ ) printf("%d\n", res[i]);

    return 0;
}
```

## 6.12 有向图的强联通分量

```cpp
#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>

using namespace std;

const int N = 10010, M = 50010;

int n, m;
int h[N], e[M], ne[M], idx;
int dfn[N], low[N], timestamp;
int stk[N], top;
bool in_stk[N];
int id[N], scc_cnt, Size[N];
int dout[N];

void add(int a, int b)
{
    e[idx] = b, ne[idx] = h[a], h[a] = idx ++ ;
}

void tarjan(int u)
{
    dfn[u] = low[u] = ++ timestamp;
    stk[ ++ top] = u, in_stk[u] = true;
    for (int i = h[u]; i != -1; i = ne[i])
    {
        int j = e[i];
        if (!dfn[j])
        {
            tarjan(j);
            low[u] = min(low[u], low[j]);
        }
        else if (in_stk[j]) low[u] = min(low[u], dfn[j]);
    }

    if (dfn[u] == low[u])
    {
        ++ scc_cnt;
        int y;
        do {
            y = stk[top -- ];
            in_stk[y] = false;
            id[y] = scc_cnt;
            Size[scc_cnt] ++ ;
        } while (y != u);
    }
}

int main()
{
    scanf("%d%d", &n, &m);
    memset(h, -1, sizeof h);
    while (m -- )
    {
        int a, b;
        scanf("%d%d", &a, &b);
        add(a, b);
    }

    for (int i = 1; i <= n; i ++ )
        if (!dfn[i])
            tarjan(i);

    for (int i = 1; i <= n; i ++ )
        for (int j = h[i]; ~j; j = ne[j])
        {
            int k = e[j];
            int a = id[i], b = id[k];
            if (a != b) dout[a] ++ ;
        }

    int zeros = 0, sum = 0;
    for (int i = 1; i <= scc_cnt; i ++ )
        if (!dout[i])
        {
            zeros ++ ;
            sum += Size[i];
            if (zeros > 1)
            {
                sum = 0;
                break;
            }
        }

    printf("%d\n", sum);

    return 0;
}
```

## 6.13 无向图的双联通分量

**冗余路径**

为了从 FF 个草场中的一个走到另一个，奶牛们有时不得不路过一些她们讨厌的可怕的树。

奶牛们已经厌倦了被迫走某一条路，所以她们想建一些新路，使每一对草场之间都会至少有两条相互分离的路径，这样她们就有多一些选择。

每对草场之间已经有至少一条路径。

给出所有 RR 条双向路的描述，每条路连接了两个不同的草场，请计算最少的新建道路的数量，路径由若干道路首尾相连而成。

两条路径相互分离，是指两条路径没有一条重合的道路。

但是，两条分离的路径上可以有一些相同的草场。

对于同一对草场之间，可能已经有两条不同的道路，你也可以在它们之间再建一条道路，作为另一条不同的道路。

```
#include <cstring>
#include <iostream>
#include <algorithm>

using namespace std;

const int N = 5010, M = 20010;

int n, m;
int h[N], e[M], ne[M], idx;
int dfn[N], low[N], timestamp;
int stk[N], top;
int id[N], dcc_cnt;
bool is_bridge[M];
int d[N];

void add(int a, int b)
{
    e[idx] = b, ne[idx] = h[a], h[a] = idx ++ ;
}

void tarjan(int u, int from)
{
    dfn[u] = low[u] = ++ timestamp;
    stk[ ++ top] = u;

    for (int i = h[u]; ~i; i = ne[i])
    {
        int j = e[i];
        if (!dfn[j])
        {
            tarjan(j, i);
            low[u] = min(low[u], low[j]);
            if (dfn[u] < low[j])
                is_bridge[i] = is_bridge[i ^ 1] = true;
        }
        else if (i != (from ^ 1))
            low[u] = min(low[u], dfn[j]);
    }

    if (dfn[u] == low[u])
    {
        ++ dcc_cnt;
        int y;
        do {
            y = stk[top -- ];
            id[y] = dcc_cnt;
        } while (y != u);
    }
}

int main()
{
    cin >> n >> m;
    memset(h, -1, sizeof h);
    while (m -- )
    {
        int a, b;
        cin >> a >> b;
        add(a, b), add(b, a);
    }

    tarjan(1, -1);

    for (int i = 0; i < idx; i ++ )
        if (is_bridge[i])
            d[id[e[i]]] ++ ;

    int cnt = 0;
    for (int i = 1; i <= dcc_cnt; i ++ )
        if (d[i] == 1)
            cnt ++ ;

    printf("%d\n", (cnt + 1) / 2);

    return 0;
}
```